#
# TABLE STRUCTURE FOR: accounts
#

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `balance` double(18,2) NOT NULL DEFAULT '0.00',
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: advance_salary
#

DROP TABLE IF EXISTS `advance_salary`;

CREATE TABLE `advance_salary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `deduct_month` varchar(20) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `reason` text CHARACTER SET utf32 COLLATE utf32_unicode_ci,
  `request_date` datetime DEFAULT NULL,
  `paid_date` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=pending,2=paid,3=rejected',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `issued_by` varchar(200) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: attachments
#

DROP TABLE IF EXISTS `attachments`;

CREATE TABLE `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `type_id` int(11) NOT NULL,
  `uploader_id` varchar(20) NOT NULL,
  `class_id` varchar(20) DEFAULT 'unfiltered',
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `subject_id` varchar(200) DEFAULT 'unfiltered',
  `session_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `attachments` (`id`, `title`, `remarks`, `type_id`, `uploader_id`, `class_id`, `file_name`, `enc_name`, `subject_id`, `session_id`, `date`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'Adnan Upload', '', 1, '1', 'unfiltered', 'acce-logo.png', 'c7fe7cd91783ab810e70b940bddafbd0.png', 'unfiltered', 3, '2020-07-15', 1, '2020-07-15 15:49:20', '2020-07-16 16:53:29');


#
# TABLE STRUCTURE FOR: attachments_type
#

DROP TABLE IF EXISTS `attachments_type`;

CREATE TABLE `attachments_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `attachments_type` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'PNG', 1, '2020-07-15 15:48:31', NULL);


#
# TABLE STRUCTURE FOR: award
#

DROP TABLE IF EXISTS `award`;

CREATE TABLE `award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `gift_item` varchar(255) NOT NULL,
  `award_amount` decimal(18,2) NOT NULL,
  `award_reason` text NOT NULL,
  `given_date` date NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: book
#

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `author` varchar(255) NOT NULL,
  `isbn_no` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `edition` varchar(255) NOT NULL,
  `purchase_date` date NOT NULL,
  `description` text NOT NULL,
  `price` decimal(18,2) NOT NULL,
  `total_stock` varchar(20) NOT NULL,
  `issued_copies` varchar(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `book` (`id`, `title`, `cover`, `author`, `isbn_no`, `category_id`, `publisher`, `edition`, `purchase_date`, `description`, `price`, `total_stock`, `issued_copies`, `created_at`, `updated_at`, `branch_id`) VALUES (1, 'The Audacity Of Hope - Barack Obama', NULL, '', '', 1, 'Barack Obama', '', '2020-07-18', '', '0.00', '1', '0', '2020-07-18 13:08:20', NULL, 1);


#
# TABLE STRUCTURE FOR: book_category
#

DROP TABLE IF EXISTS `book_category`;

CREATE TABLE `book_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `book_category` (`id`, `name`, `branch_id`) VALUES (1, 'Biography', 1);


#
# TABLE STRUCTURE FOR: book_issues
#

DROP TABLE IF EXISTS `book_issues`;

CREATE TABLE `book_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `date_of_issue` date DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `fine_amount` decimal(18,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = pending, 1 = accepted, 2 = rejected, 3 = returned',
  `issued_by` varchar(255) DEFAULT NULL,
  `return_by` int(11) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `book_issues` (`id`, `book_id`, `user_id`, `role_id`, `date_of_issue`, `date_of_expiry`, `return_date`, `fine_amount`, `status`, `issued_by`, `return_by`, `session_id`, `branch_id`, `created_at`) VALUES (1, 1, 4, 4, '2020-09-29', '2020-10-02', NULL, '0.00', 1, '1', NULL, 3, 1, '2020-09-29 14:25:05');


#
# TABLE STRUCTURE FOR: branch
#

DROP TABLE IF EXISTS `branch`;

CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `school_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `symbol` varchar(25) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `stu_generate` tinyint(3) DEFAULT '0',
  `stu_username_prefix` varchar(255) NOT NULL,
  `stu_default_password` varchar(255) NOT NULL,
  `grd_generate` tinyint(3) DEFAULT '0',
  `grd_username_prefix` varchar(255) NOT NULL,
  `grd_default_password` varchar(255) NOT NULL,
  `teacher_restricted` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `branch` (`id`, `name`, `school_name`, `email`, `mobileno`, `currency`, `symbol`, `city`, `state`, `address`, `stu_generate`, `stu_username_prefix`, `stu_default_password`, `grd_generate`, `grd_username_prefix`, `grd_default_password`, `teacher_restricted`, `created_at`, `updated_at`) VALUES (1, 'ACCE Abuja', 'ACCE Abuja', 'info@acce-abuja.com.ng', '+2348092406828', 'NGN', '₦', 'Abuja', 'Federal Capital Territory', '', 0, '', '', 0, '', '', 1, '2020-07-15 15:21:22', NULL);


#
# TABLE STRUCTURE FOR: bulk_msg_category
#

DROP TABLE IF EXISTS `bulk_msg_category`;

CREATE TABLE `bulk_msg_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT 'sms=1, email=2',
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `bulk_msg_category` (`id`, `name`, `body`, `type`, `branch_id`) VALUES (1, 'Test', ' This is a test  from {name}  {email} -  {mobile_no} ', 1, 1);
INSERT INTO `bulk_msg_category` (`id`, `name`, `body`, `type`, `branch_id`) VALUES (2, 'Test Mail', '<p>Testing from  {name} </p>', 2, 1);


#
# TABLE STRUCTURE FOR: bulk_sms_email
#

DROP TABLE IF EXISTS `bulk_sms_email`;

CREATE TABLE `bulk_sms_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) DEFAULT NULL,
  `sms_gateway` varchar(55) DEFAULT '0',
  `message` text,
  `email_subject` varchar(255) DEFAULT NULL,
  `message_type` tinyint(3) DEFAULT '0' COMMENT 'sms=1, email=2',
  `recipient_type` tinyint(3) NOT NULL COMMENT 'group=1, individual=2, class=3',
  `recipients_details` longtext,
  `additional` longtext,
  `schedule_time` datetime DEFAULT NULL,
  `posting_status` tinyint(3) NOT NULL COMMENT 'schedule=1,competed=2',
  `total_thread` int(11) NOT NULL,
  `successfully_sent` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `bulk_sms_email` (`id`, `campaign_name`, `sms_gateway`, `message`, `email_subject`, `message_type`, `recipient_type`, `recipients_details`, `additional`, `schedule_time`, `posting_status`, `total_thread`, `successfully_sent`, `branch_id`, `created_at`) VALUES (1, 'TEsting camp', '0', '<p>Testing from  {name} </p>', 'Acce sub test', 2, 2, '', '', '2020-07-16 15:01:28', 2, 1, 0, 1, '2020-07-16 15:01:28');
INSERT INTO `bulk_sms_email` (`id`, `campaign_name`, `sms_gateway`, `message`, `email_subject`, `message_type`, `recipient_type`, `recipients_details`, `additional`, `schedule_time`, `posting_status`, `total_thread`, `successfully_sent`, `branch_id`, `created_at`) VALUES (2, 'Test Campaign', '0', '<p> {mobile_no} Testing from  {name} x   {email} </p>', 'Tester Camp', 2, 2, '', '', '2020-09-29 14:15:14', 2, 1, 0, 1, '2020-09-29 14:15:14');
INSERT INTO `bulk_sms_email` (`id`, `campaign_name`, `sms_gateway`, `message`, `email_subject`, `message_type`, `recipient_type`, `recipients_details`, `additional`, `schedule_time`, `posting_status`, `total_thread`, `successfully_sent`, `branch_id`, `created_at`) VALUES (3, 'Test Campaign', '0', '<p> {name}  {email}  {mobile_no} <br></p>', 'tester', 2, 2, '', '', '2020-10-05 11:28:52', 2, 1, 0, 1, '2020-10-05 11:28:52');


#
# TABLE STRUCTURE FOR: card_templete
#

DROP TABLE IF EXISTS `card_templete`;

CREATE TABLE `card_templete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_type` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `background` varchar(355) DEFAULT NULL,
  `logo` varchar(355) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `layout_width` varchar(11) NOT NULL DEFAULT '54',
  `layout_height` varchar(11) NOT NULL DEFAULT '86',
  `photo_style` tinyint(1) NOT NULL,
  `photo_size` varchar(25) NOT NULL,
  `top_space` varchar(25) NOT NULL,
  `bottom_space` varchar(25) NOT NULL,
  `right_space` varchar(25) NOT NULL,
  `left_space` varchar(25) NOT NULL,
  `qr_code` varchar(25) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `card_templete` (`id`, `card_type`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `layout_width`, `layout_height`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (1, 1, 'Student ID', 1, 'acce-logo2.png', 'logo_1.jpg', '', '<p> {name}  {gender}  {father_name}  {mother_name}  {student_photo}  {register_no}  {roll}  {admission_date}  {class}  {section}  {category}  {caste}  {religion}  {blood_group}  {birthday}  {email}  {mobileno}  {present_address}  {permanent_address}  {logo}  {signature}  {qr_code}  {institute_name}  {institute_email}  {institute_address}  {institute_mobile_no}  {print_date}  {expiry_date} <br></p>', '85.60', '53.98', 1, '100', '15', '15', '15', '15', 'register_no', 1, '2020-10-05 10:58:27');
INSERT INTO `card_templete` (`id`, `card_type`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `layout_width`, `layout_height`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (2, 1, 'Staff ID', 2, 'acce-logo3.png', 'logo.jpg', '', '<p> {name}  {gender}  {staff_photo}  {joining_date}  {designation}  {department}  {qualification}  {total_experience}  {religion}  {blood_group}  {birthday}  {mobileno} </p><p><br></p><p><br></p><p><br></p><p> {logo}  {qr_code}  {institute_name}  {institute_email} <br></p>', '85.60', '53.98', 1, '100', '15', '15', '15', '15', 'staff_id', 1, '2020-10-05 11:23:32');


#
# TABLE STRUCTURE FOR: certificates_templete
#

DROP TABLE IF EXISTS `certificates_templete`;

CREATE TABLE `certificates_templete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `background` varchar(355) DEFAULT NULL,
  `logo` varchar(355) DEFAULT NULL,
  `signature` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `page_layout` tinyint(1) NOT NULL,
  `photo_style` tinyint(1) NOT NULL,
  `photo_size` varchar(25) NOT NULL,
  `top_space` varchar(25) NOT NULL,
  `bottom_space` varchar(25) NOT NULL,
  `right_space` varchar(25) NOT NULL,
  `left_space` varchar(25) NOT NULL,
  `qr_code` varchar(25) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `certificates_templete` (`id`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `page_layout`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (1, 'Test Cert', 1, 'acce-logo.png', 'acce-logo-removebg-preview.png', 'acce-logo-removebg-preview1.png', '<p> {name}  {gender}  {father_name}  {mother_name}  {student_photo}  {register_no}  {roll}  {admission_date}  {class}  {section}  {category}  {caste}  {religion}  {birthday}  {email}  {mobileno}  {present_address}  {logo}  {signature}  {institute_email}  {institute_address}  {institute_mobile_no}  {print_date} <br></p>', 1, 1, '100', '5', '5', '5', '5', 'register_no', 1, '2020-07-16 15:54:56');
INSERT INTO `certificates_templete` (`id`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `page_layout`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (2, 'Al-Ansar Foundation', 2, 'acce-logo1.png', 'logo.png', 'Signature.png', '<p>The name&nbsp; {name} of&nbsp; {department} and designation&nbsp; {designation},&nbsp; {department},&nbsp; {staff_photo},&nbsp; {staff_id}.</p><p><br></p><p> {qr_code} <br></p>', 2, 2, '100', '5', '5', '5', '5', 'staff_id', 1, '2020-10-05 10:46:29');


#
# TABLE STRUCTURE FOR: class
#

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_numeric` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (1, 'SS1 A', '1', '2020-07-15 15:35:11', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (2, 'SS1 B', '1', '2020-07-15 15:36:42', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (3, 'SS1 C', '1', '2020-07-15 15:37:03', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (4, 'SS2 A', '2', '2020-09-29 12:51:49', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (5, 'SS2 B', '2', '2020-09-29 12:52:04', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (6, 'SS2 C', '2', '2020-09-29 12:52:31', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (7, 'SS3 A', '3', '2020-09-29 12:52:57', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (8, 'SS3 B', '3', '2020-09-29 12:53:12', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (9, 'SS3 C', '3', '2020-09-29 12:53:29', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (10, 'JS1 A', '1', '2020-09-29 12:53:44', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (11, 'JS1 B', '1', '2020-09-29 12:54:14', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (12, 'JS1 C', '1', '2020-09-29 12:54:33', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (13, 'JS2 A', '2', '2020-09-29 12:54:52', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (14, 'JS2 B', '2', '2020-09-29 12:55:06', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (15, 'JS2 C', '2', '2020-09-29 12:55:24', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (16, 'JS3 A', '3', '2020-09-29 12:55:35', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (17, 'JS3 B', '3', '2020-09-29 12:55:47', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (18, 'JS3 C', '3', '2020-09-29 12:56:03', NULL, 1);


#
# TABLE STRUCTURE FOR: custom_field
#

DROP TABLE IF EXISTS `custom_field`;

CREATE TABLE `custom_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_to` varchar(50) DEFAULT NULL,
  `field_label` varchar(100) NOT NULL,
  `default_value` text,
  `field_type` enum('text','textarea','dropdown','date','checkbox','number','url','email') NOT NULL,
  `required` varchar(5) NOT NULL DEFAULT 'false',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `show_on_table` varchar(5) DEFAULT NULL,
  `field_order` int(11) NOT NULL,
  `bs_column` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_fields_values
#

DROP TABLE IF EXISTS `custom_fields_values`;

CREATE TABLE `custom_fields_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: email_config
#

DROP TABLE IF EXISTS `email_config`;

CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) NOT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_user` varchar(255) DEFAULT NULL,
  `smtp_pass` varchar(255) DEFAULT NULL,
  `smtp_port` varchar(100) DEFAULT NULL,
  `smtp_encryption` varchar(10) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `email_config` (`id`, `email`, `protocol`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `smtp_encryption`, `branch_id`) VALUES (1, 'it@acce-abuja.com.ng', 'smtp', 'smtp.gmail.com', 'admin@acce-abuja.com.ng', 'acceabuja2020', '587', 'tls', 1);


#
# TABLE STRUCTURE FOR: email_templates
#

DROP TABLE IF EXISTS `email_templates`;

CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (1, 'account_registered', '{institute_name}, {name}, {login_username}, {password}, {user_role}, {login_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (2, 'forgot_password', '{institute_name}, {username}, {email}, {reset_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (3, 'change_password', '{institute_name}, {username}, {email}, {password}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (4, 'new_message_received', '{institute_name}, {recipient}, {message}, {message_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (5, 'payslip_generated', '{institute_name}, {username}, {month_year}, {payslip_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (6, 'award', '{institute_name}, {winner_name}, {award_name}, {gift_item}, {award_reason}, {given_date}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (7, 'leave_approve', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (8, 'leave_reject', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (9, 'advance_salary_approve', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (10, 'advance_salary_reject', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');


#
# TABLE STRUCTURE FOR: email_templates_details
#

DROP TABLE IF EXISTS `email_templates_details`;

CREATE TABLE `email_templates_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `template_body` text NOT NULL,
  `notified` tinyint(1) NOT NULL DEFAULT '1',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `email_templates_details` (`id`, `template_id`, `subject`, `template_body`, `notified`, `branch_id`) VALUES (1, 1, 'Your Account Has Been Registered on {institute_name} Portal', '<p>Hello {name},</p><p><br></p><p>Your Login Details for {institute_name} are below</p><p>Username : {<span xss=removed>login_username</span>}</p><p>Password : {<span xss=removed>password</span>}</p><p>as a {<span xss=removed>user_role</span>}.</p><p><br></p><p>Login URL : {login_url}</p>', 1, 1);


#
# TABLE STRUCTURE FOR: enroll
#

DROP TABLE IF EXISTS `enroll`;

CREATE TABLE `enroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `roll` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` tinyint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `enroll` (`id`, `student_id`, `class_id`, `section_id`, `roll`, `session_id`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 1, 3, 3, 0, 3, 1, '2020-07-16 16:00:26', NULL);
INSERT INTO `enroll` (`id`, `student_id`, `class_id`, `section_id`, `roll`, `session_id`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 2, 1, 1, 0, 3, 1, '2020-09-28 14:25:11', NULL);


#
# TABLE STRUCTURE FOR: event
#

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remark` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` text NOT NULL,
  `audition` longtext NOT NULL,
  `selected_list` longtext NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `show_web` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `event` (`id`, `title`, `remark`, `status`, `type`, `audition`, `selected_list`, `start_date`, `end_date`, `image`, `created_by`, `created_at`, `updated_at`, `branch_id`, `show_web`) VALUES (1, 'Mathematics Midterm', '<p>Maths Midterms</p>', 1, '2', '1', 'null', '2020-09-29', '2020-10-01', 'AL-ANSAR_NEWS_BULLETIN-page-0.jpg', '1', '2020-09-29 14:18:11', NULL, 1, 0);


#
# TABLE STRUCTURE FOR: event_types
#

DROP TABLE IF EXISTS `event_types`;

CREATE TABLE `event_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `icon` varchar(200) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `event_types` (`id`, `name`, `icon`, `branch_id`) VALUES (1, 'PTA', 'users', 1);
INSERT INTO `event_types` (`id`, `name`, `icon`, `branch_id`) VALUES (2, 'Midterm Examination', 'concierge-bell', 1);


#
# TABLE STRUCTURE FOR: exam
#

DROP TABLE IF EXISTS `exam`;

CREATE TABLE `exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `term_id` int(11) DEFAULT NULL,
  `type_id` tinyint(4) NOT NULL COMMENT '1=mark,2=gpa,3=both',
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `remark` text NOT NULL,
  `mark_distribution` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: exam_attendance
#

DROP TABLE IF EXISTS `exam_attendance`;

CREATE TABLE `exam_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `status` varchar(4) DEFAULT NULL COMMENT 'P=Present, A=Absent, L=Late',
  `remark` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: exam_hall
#

DROP TABLE IF EXISTS `exam_hall`;

CREATE TABLE `exam_hall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hall_no` longtext NOT NULL,
  `seats` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (1, '2', 50, 1);
INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (2, '12', 38, 1);


#
# TABLE STRUCTURE FOR: exam_mark_distribution
#

DROP TABLE IF EXISTS `exam_mark_distribution`;

CREATE TABLE `exam_mark_distribution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: exam_term
#

DROP TABLE IF EXISTS `exam_term`;

CREATE TABLE `exam_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (1, 'Mid-Term', 1, 3);
INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (2, 'First Term', 1, 3);


#
# TABLE STRUCTURE FOR: fee_allocation
#

DROP TABLE IF EXISTS `fee_allocation`;

CREATE TABLE `fee_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fee_allocation` (`id`, `student_id`, `group_id`, `branch_id`, `session_id`, `created_at`) VALUES (1, 2, 1, 1, 3, '2020-09-29 12:41:56');


#
# TABLE STRUCTURE FOR: fee_fine
#

DROP TABLE IF EXISTS `fee_fine`;

CREATE TABLE `fee_fine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `fine_value` varchar(20) NOT NULL,
  `fine_type` varchar(20) NOT NULL,
  `fee_frequency` varchar(20) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fee_fine` (`id`, `group_id`, `type_id`, `fine_value`, `fine_type`, `fee_frequency`, `branch_id`, `session_id`) VALUES (1, 1, 1, '8000', '1', '0', 1, 3);


#
# TABLE STRUCTURE FOR: fee_groups
#

DROP TABLE IF EXISTS `fee_groups`;

CREATE TABLE `fee_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fee_groups` (`id`, `name`, `description`, `session_id`, `branch_id`, `created_at`) VALUES (1, 'Tuition Late', '', 3, 1, '2020-09-29 12:40:41');


#
# TABLE STRUCTURE FOR: fee_groups_details
#

DROP TABLE IF EXISTS `fee_groups_details`;

CREATE TABLE `fee_groups_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fee_groups_id` int(11) NOT NULL,
  `fee_type_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (1, 1, 1, '75000.00', '2020-11-04', '2020-09-29 12:40:41');


#
# TABLE STRUCTURE FOR: fee_payment_history
#

DROP TABLE IF EXISTS `fee_payment_history`;

CREATE TABLE `fee_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `allocation_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `collect_by` varchar(20) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL,
  `fine` decimal(18,2) NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `remarks` longtext NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (1, 1, 1, '1', '75000.00', '0.00', '0.00', '2', '', '2020-09-29');


#
# TABLE STRUCTURE FOR: fees_reminder
#

DROP TABLE IF EXISTS `fees_reminder`;

CREATE TABLE `fees_reminder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `frequency` varchar(255) NOT NULL,
  `days` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `student` tinyint(3) NOT NULL,
  `guardian` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fees_reminder` (`id`, `frequency`, `days`, `message`, `student`, `guardian`, `branch_id`, `created_at`) VALUES (1, 'before', '2', '{guardian_name} abeg test {child_name} on  {due_date} for  {due_amount} and  {fee_type}', 1, 1, 1, '2020-09-29 12:45:37');


#
# TABLE STRUCTURE FOR: fees_type
#

DROP TABLE IF EXISTS `fees_type`;

CREATE TABLE `fees_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `fee_code` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `created_at`) VALUES (1, 'Tuition Fees', 'tuition-fees', 'Terminal Tuition Fees', 1, '2020-09-29 12:21:26');


#
# TABLE STRUCTURE FOR: front_cms_about
#

DROP TABLE IF EXISTS `front_cms_about`;

CREATE TABLE `front_cms_about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `about_image` varchar(255) NOT NULL,
  `elements` mediumtext NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_about` (`id`, `title`, `subtitle`, `page_title`, `content`, `banner_image`, `about_image`, `elements`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Welcome to School', 'Best Education Mangment Systems', 'About Us', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut volutpat rutrum eros amet sollicitudin interdum. Suspendisse pulvinar, velit nec pharetra interdum, ante tellus ornare mi, et mollis tellus neque vitae elit. Mauris adipiscing mauris fringilla turpis interdum sed pulvinar nisi malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit.\r\n                        </p>\r\n                        <p>\r\n                            Donec sed odio dui. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula. Mauris sit amet neque nec nunc gravida. \r\n                        </p>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-sm-6 col-12\">\r\n                                <ul class=\"list-unstyled list-style-3\">\r\n                                    <li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n                                    <li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n                                    <li><a href=\"#\">Ophthalmology</a></li>\r\n                                    <li><a href=\"#\">Dermitology</a></li>\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"col-sm-6 col-12\">\r\n                                <ul class=\"list-unstyled list-style-3\">\r\n                                    <li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n                                    <li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n                                    <li><a href=\"#\">Ophthalmology</a></li>\r\n                                </ul>\r\n                            </div>\r\n                        </div>', 'about1.jpg', 'about1.png', '{\"cta_title\":\"Get in touch to join our community\",\"button_text\":\"Contact Our Office\",\"button_url\":\"contact\"}', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_admission
#

DROP TABLE IF EXISTS `front_cms_admission`;

CREATE TABLE `front_cms_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_admission` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Make An Admission', '<p>Lorem ipsum dolor sit amet, eum illum dolore concludaturque ex, ius latine adipisci no. Pro at nullam laboramus definitiones. Mandamusconceptam omittantur cu cum. Brute appetere it scriptorem ei eam, ne vim velit novum nominati. Causae volutpat percipitur at sed ne.</p>\r\n', 'Admission', 'admission1.jpg', 'Ramom - School Management System With CMS', 'Ramom  Admission Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_contact
#

DROP TABLE IF EXISTS `front_cms_contact`;

CREATE TABLE `front_cms_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `box_title` varchar(255) DEFAULT NULL,
  `box_description` varchar(500) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `form_title` varchar(355) DEFAULT NULL,
  `address` varchar(355) DEFAULT NULL,
  `phone` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `submit_text` varchar(355) NOT NULL,
  `map_iframe` text,
  `page_title` varchar(255) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_contact` (`id`, `box_title`, `box_description`, `box_image`, `form_title`, `address`, `phone`, `email`, `submit_text`, `map_iframe`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'WE\'D LOVE TO HEAR FROM YOU', 'Fusce convallis diam vitae velit tempus rutrum. Donec nisl nisl, vulputate eu sapien sed, adipiscing vehicula massa. Mauris eget commodo neque, id molestie enim.', 'contact-info-box1.png', 'Get in touch by filling the form below', '4896  Romrog Way, LOS ANGELES,\r\nCalifornia', '123-456-7890, \r\n123-456-7890', 'info@example.com\r\nsupport@example.com', 'Send', NULL, 'Contact Us', 'contact1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_events
#

DROP TABLE IF EXISTS `front_cms_events`;

CREATE TABLE `front_cms_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_events` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Upcoming Events', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p><p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.</p>', 'Events', 'events1.jpg', 'Ramom - School Management System With CMS', 'Ramom Events Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq
#

DROP TABLE IF EXISTS `front_cms_faq`;

CREATE TABLE `front_cms_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_faq` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Frequently Asked Questions', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p>\r\n\r\n<p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven&#39;t heard of them accusamus labore sustainable VHS.</p>', 'Faq', 'faq1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq_list
#

DROP TABLE IF EXISTS `front_cms_faq_list`;

CREATE TABLE `front_cms_faq_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (1, 'Any Information you provide on applications for disability, life or accidental insurance ?', '<p>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n</p>\r\n<ul>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Sed do eiusmod tempor incididunt ut labore et dolore magna aliq.</li>\r\n<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact.</li>\r\n<li>That a reader will be distracted by the readable content of a page when looking at its layout.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</li>\r\n<li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n<li>Readable content of a page when looking at its layout.</li>\r\n<li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n<li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n</ul>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (2, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (3, 'Opposed to using \'Content here, content here\', making it look like readable English ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (4, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (5, 'What types of documents are required to travel?', '<p><strong>Lorem ipsum</strong> dolor sit amet, an labores explicari qui, eu nostrum copiosae argumentum has. Latine propriae quo no, unum ridens expetenda id sit, at usu eius eligendi singulis. Sea ocurreret principes ne. At nonumy aperiri pri, nam quodsi copiosae intellegebat et, ex deserunt euripidis usu. Per ad ullum lobortis. Duo volutpat imperdiet ut, postea salutatus imperdiet ut per, ad utinam debitis invenire has.</p>\r\n\r\n<ol>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari quilabores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n</ol>', 1);


#
# TABLE STRUCTURE FOR: front_cms_home
#

DROP TABLE IF EXISTS `front_cms_home`;

CREATE TABLE `front_cms_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `item_type` varchar(20) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `elements` mediumtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `active` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (1, 'Welcome To Education', 'We will give you future', 'wellcome', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using content.\r\n\r\nMaking it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '{\"image\":\"wellcome1.png\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (2, 'Experience Teachers Team', NULL, 'teachers', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident.', '{\"teacher_start\":\"0\",\"image\":\"featured-parallax1.jpg\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (3, 'WHY CHOOSE US', NULL, 'services', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (4, 'Request for a free Education Class', NULL, 'cta', '', '{\"mobile_no\":\"+1-12345678\",\"button_text\":\"Request Now\",\"button_url\":\"#\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (5, 'Wellcome To <span>ACCE</span>', NULL, 'slider', 'Lorem Ipsum is simply dummy text printer took a galley of type and scrambled it to make a type specimen book.', '{\"position\":\"c-left\",\"button_text1\":\"View Services\",\"button_url1\":\"#\",\"button_text2\":\"Learn More\",\"button_url2\":\"#\",\"image\":\"home-slider-1592582779.jpg\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (6, 'Online  <span>Live Class</span> Facility', NULL, 'slider', 'Lorem Ipsum is simply dummy text printer took a galley of type and scrambled it to make a type specimen book.', '{\"position\":\"c-left\",\"button_text1\":\"Read More\",\"button_url1\":\"#\",\"button_text2\":\"Get Started\",\"button_url2\":\"#\",\"image\":\"home-slider-1592582805.jpg\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (8, 'Online Classes', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-video\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (9, 'Scholarship', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-graduation-cap\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (10, 'Books & Liberary', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-book-reader\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (11, 'Trending Courses', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fab fa-discourse\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (12, 'WHAT PEOPLE SAYS', NULL, 'testimonial', 'Fusce sem dolor, interdum in efficitur at, faucibus nec lorem. Sed nec molestie justo.', '', 1, 0);


#
# TABLE STRUCTURE FOR: front_cms_home_seo
#

DROP TABLE IF EXISTS `front_cms_home_seo`;

CREATE TABLE `front_cms_home_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_home_seo` (`id`, `page_title`, `meta_keyword`, `meta_description`, `branch_id`) VALUES (1, 'Home', 'School Home Page', 'Copyright Info', 1);


#
# TABLE STRUCTURE FOR: front_cms_menu
#

DROP TABLE IF EXISTS `front_cms_menu`;

CREATE TABLE `front_cms_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `ordering` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `open_new_tab` int(11) NOT NULL DEFAULT '0',
  `ext_url` tinyint(3) NOT NULL DEFAULT '0',
  `ext_url_address` text,
  `publish` tinyint(3) NOT NULL,
  `system` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (1, 'Home', 'index', 1, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (2, 'Events', 'events', 3, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (3, 'Teachers', 'teachers', 2, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (4, 'About Us', 'about', 4, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (5, 'FAQ', 'faq', 5, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (6, 'Online Admission', 'admission', 6, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (7, 'Contact Us', 'contact', 7, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');


#
# TABLE STRUCTURE FOR: front_cms_pages
#

DROP TABLE IF EXISTS `front_cms_pages`;

CREATE TABLE `front_cms_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: front_cms_services
#

DROP TABLE IF EXISTS `front_cms_services`;

CREATE TABLE `front_cms_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `parallax_image` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_services` (`id`, `title`, `subtitle`, `parallax_image`, `branch_id`) VALUES (1, 'Get Well Soon', 'Our Best <span>Services</span>', 'service_parallax1.jpg', 1);


#
# TABLE STRUCTURE FOR: front_cms_services_list
#

DROP TABLE IF EXISTS `front_cms_services_list`;

CREATE TABLE `front_cms_services_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (1, 'Online Course Facilities', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text.', 'fas fa-headphones', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (2, 'Modern Book Library', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover.', 'fas fa-book-open', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (3, 'Be Industrial Leader', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model.', 'fas fa-industry', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (4, 'Programming Courses', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will.', 'fas fa-code', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (5, 'Foreign Languages', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover.', 'fas fa-language', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (6, 'Alumni Directory', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a for \'lorem ipsum\' will uncover.', 'fas fa-user-graduate', 1);


#
# TABLE STRUCTURE FOR: front_cms_setting
#

DROP TABLE IF EXISTS `front_cms_setting`;

CREATE TABLE `front_cms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_title` varchar(255) NOT NULL,
  `url_alias` varchar(255) DEFAULT NULL,
  `cms_active` tinyint(4) NOT NULL DEFAULT '0',
  `online_admission` tinyint(4) NOT NULL DEFAULT '0',
  `theme` varchar(255) NOT NULL,
  `captcha_status` varchar(20) NOT NULL,
  `recaptcha_site_key` varchar(255) NOT NULL,
  `recaptcha_secret_key` varchar(255) NOT NULL,
  `address` varchar(350) NOT NULL,
  `mobile_no` varchar(60) NOT NULL,
  `fax` varchar(60) NOT NULL,
  `receive_contact_email` varchar(255) NOT NULL,
  `email` varchar(60) NOT NULL,
  `copyright_text` varchar(255) NOT NULL,
  `fav_icon` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `footer_about_text` varchar(300) NOT NULL,
  `working_hours` varchar(300) NOT NULL,
  `facebook_url` varchar(100) NOT NULL,
  `twitter_url` varchar(100) NOT NULL,
  `youtube_url` varchar(100) NOT NULL,
  `google_plus` varchar(100) NOT NULL,
  `linkedin_url` varchar(100) NOT NULL,
  `pinterest_url` varchar(100) NOT NULL,
  `instagram_url` varchar(100) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_setting` (`id`, `application_title`, `url_alias`, `cms_active`, `online_admission`, `theme`, `captcha_status`, `recaptcha_site_key`, `recaptcha_secret_key`, `address`, `mobile_no`, `fax`, `receive_contact_email`, `email`, `copyright_text`, `fav_icon`, `logo`, `footer_about_text`, `working_hours`, `facebook_url`, `twitter_url`, `youtube_url`, `google_plus`, `linkedin_url`, `pinterest_url`, `instagram_url`, `branch_id`) VALUES (1, 'School Management System With CMS', 'example', 0, 1, 'red', 'disable', '', '', 'Your Address', '+12345678', '12345678', 'info@example.com', 'info@demo.com', 'Copyright © 2020 <span>Ramom</span>. All Rights Reserved.', 'fav_icon1.png', 'logo1.png', 'If you are going to use a passage LorIsum, you anythirassing hidden in the middle of text. Lators on the Internet tend to.', '<span>Hours : </span>  Mon To Fri - 10AM - 04PM,  Sunday Closed', 'https://facebook.com', 'https://twitter.com', 'https://youtube.com', 'https://google.com', 'https://linkedin.com', 'https://pinterest.com', 'https://instagram.com', 1);


#
# TABLE STRUCTURE FOR: front_cms_teachers
#

DROP TABLE IF EXISTS `front_cms_teachers`;

CREATE TABLE `front_cms_teachers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_teachers` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Teachers', 'teachers1.jpg', 'ACCE PORTAL', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_testimonial
#

DROP TABLE IF EXISTS `front_cms_testimonial`;

CREATE TABLE `front_cms_testimonial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `surname` varchar(355) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rank` int(5) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (1, 'Gartrell Wright', 'Los Angeles', 'user-1582830398.jpg', 'Intexure have done an excellent job presenting the analysis & insights. I am confident in saying  have helped encounter  is to be welcomed and every pain avoided”.', 1, 1, 1, '2019-08-23 13:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (2, 'Clifton Hyde', 'Newyork City', 'defualt.png', '“Owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted always holds”.', 4, 1, 1, '2019-08-23 13:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (3, 'Emily Lemus', 'Los Angeles', 'defualt.png', '“Intexure have done an excellent job presenting the analysis & insights. I am confident in saying  have helped encounter  is to be welcomed and every pain avoided”.', 5, 1, 1, '2019-08-23 13:26:42');


#
# TABLE STRUCTURE FOR: global_settings
#

DROP TABLE IF EXISTS `global_settings`;

CREATE TABLE `global_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institute_name` varchar(255) NOT NULL,
  `institution_code` varchar(255) NOT NULL,
  `reg_prefix` varchar(255) NOT NULL,
  `institute_email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `currency_symbol` varchar(100) NOT NULL,
  `sms_service_provider` varchar(100) NOT NULL,
  `session_id` int(11) NOT NULL,
  `translation` varchar(100) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `animations` varchar(100) NOT NULL,
  `timezone` varchar(100) NOT NULL,
  `date_format` varchar(100) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `linkedin_url` varchar(255) NOT NULL,
  `youtube_url` varchar(255) NOT NULL,
  `cron_secret_key` varchar(255) DEFAULT NULL,
  `cms_default_branch` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `global_settings` (`id`, `institute_name`, `institution_code`, `reg_prefix`, `institute_email`, `address`, `mobileno`, `currency`, `currency_symbol`, `sms_service_provider`, `session_id`, `translation`, `footer_text`, `animations`, `timezone`, `date_format`, `facebook_url`, `twitter_url`, `linkedin_url`, `youtube_url`, `cron_secret_key`, `cms_default_branch`, `created_at`, `updated_at`) VALUES (1, 'ACCE Abuja', 'ACCE-', 'on', 'ramom@example.com', 'Plot 8 Kafe, Opposite Maija Plaza near Saraha Estate, after Charly Boy\'s House, Gwarimpa Abuja.', '(+234) 804-568-90', 'NGN', '₦', 'disabled', 3, 'english', 'All Rights Reserved © Copyright 2020 ACCE-Abuja', 'fadeInUp', 'Africa/Lagos', 'd.M.Y', '', '', '', '', '17559316581c4cfb0177ace91753246a', 1, '2018-10-22 10:07:49', '2020-05-01 22:37:06');


#
# TABLE STRUCTURE FOR: grade
#

DROP TABLE IF EXISTS `grade`;

CREATE TABLE `grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `grade_point` varchar(255) NOT NULL,
  `lower_mark` int(11) NOT NULL,
  `upper_mark` int(11) NOT NULL,
  `remark` text NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: hall_allocation
#

DROP TABLE IF EXISTS `hall_allocation`;

CREATE TABLE `hall_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `hall_no` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: homework
#

DROP TABLE IF EXISTS `homework`;

CREATE TABLE `homework` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `date_of_homework` date NOT NULL,
  `date_of_submission` date NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `sms_notification` tinyint(2) NOT NULL,
  `schedule_date` date DEFAULT NULL,
  `document` varchar(255) NOT NULL,
  `evaluation_date` date DEFAULT NULL,
  `evaluated_by` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: homework_evaluation
#

DROP TABLE IF EXISTS `homework_evaluation`;

CREATE TABLE `homework_evaluation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homework_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `remark` text NOT NULL,
  `rank` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: hostel
#

DROP TABLE IF EXISTS `hostel`;

CREATE TABLE `hostel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `category_id` int(11) NOT NULL,
  `address` longtext NOT NULL,
  `watchman` longtext NOT NULL,
  `remarks` longtext,
  `branch_id` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `hostel` (`id`, `name`, `category_id`, `address`, `watchman`, `remarks`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'Red Hostel', 1, 'Apo', 'Bashir Ahmed', 'Near Gudu', 1, '2020-09-30 13:16:59', NULL);
INSERT INTO `hostel` (`id`, `name`, `category_id`, `address`, `watchman`, `remarks`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'Barau Dikko House', 2, 'Katampe', 'Dawisu', 'Near Guzape Ext', 1, '2020-09-30 13:17:50', NULL);


#
# TABLE STRUCTURE FOR: hostel_category
#

DROP TABLE IF EXISTS `hostel_category`;

CREATE TABLE `hostel_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `description` longtext,
  `branch_id` int(11) DEFAULT NULL,
  `type` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `hostel_category` (`id`, `name`, `description`, `branch_id`, `type`, `created_at`, `updated_at`) VALUES (1, 'Junior', '', 1, 'hostel', '2020-09-30 13:14:20', NULL);
INSERT INTO `hostel_category` (`id`, `name`, `description`, `branch_id`, `type`, `created_at`, `updated_at`) VALUES (2, 'Senior', '', 1, 'hostel', '2020-09-30 13:14:29', NULL);
INSERT INTO `hostel_category` (`id`, `name`, `description`, `branch_id`, `type`, `created_at`, `updated_at`) VALUES (3, 'JS1', '', 1, 'room', '2020-09-30 13:14:55', NULL);
INSERT INTO `hostel_category` (`id`, `name`, `description`, `branch_id`, `type`, `created_at`, `updated_at`) VALUES (4, 'SS1', '', 1, 'room', '2020-09-30 13:15:07', NULL);


#
# TABLE STRUCTURE FOR: hostel_room
#

DROP TABLE IF EXISTS `hostel_room`;

CREATE TABLE `hostel_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `no_beds` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `bed_fee` decimal(18,2) NOT NULL,
  `remarks` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `hostel_room` (`id`, `name`, `hostel_id`, `no_beds`, `category_id`, `bed_fee`, `remarks`, `branch_id`) VALUES (1, 'Room 512', 1, 15, 4, '4500.00', '', 1);
INSERT INTO `hostel_room` (`id`, `name`, `hostel_id`, `no_beds`, `category_id`, `bed_fee`, `remarks`, `branch_id`) VALUES (2, 'Room 979', 1, 45, 3, '15000.00', '', 1);


#
# TABLE STRUCTURE FOR: language_list
#

DROP TABLE IF EXISTS `language_list`;

CREATE TABLE `language_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `lang_field` varchar(600) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (1, 'English', 'english', 1, '2018-11-15 12:36:31', '2020-04-18 20:05:12');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (3, 'Arabic', 'arabic', 1, '2018-11-15 12:36:31', '2019-01-20 03:04:53');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (32, 'Hausa', 'lang_32', 1, '2020-10-06 11:26:09', NULL);


#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `english` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `arabic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lang_32` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1123 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1, 'language', 'Language', 'لغة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (2, 'attendance_overview', 'Attendance Overview', 'نظرة عامة على الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (3, 'annual_fee_summary', 'Annual Fee Summary', 'ملخص الرسوم السنوية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (4, 'my_annual_attendance_overview', 'My Annual Attendance Overview', 'حضري السنوي نظرة عامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (5, 'schedule', 'Schedule', 'جداول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (6, 'student_admission', 'Student Admission', 'قبول الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (7, 'returned', 'Returned', 'عاد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (8, 'user_name', 'User Name', 'اسم المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (9, 'rejected', 'Rejected', 'مرفوض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (10, 'route_name', 'Route Name', 'اسم المسار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (11, 'route_fare', 'Route Fare', 'الطريق الأجرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (12, 'edit_route', 'Edit Route', 'تحرير المسار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (13, 'this_value_is_required', 'This value is required.', 'هذه القيمة مطلوبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (14, 'vehicle_no', 'Vehicle No', 'السيارة لا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (15, 'insurance_renewal_date', 'Insurance Renewal Date', 'تاريخ تجديد التأمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (16, 'driver_name', 'Driver Name', 'اسم السائق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (17, 'driver_license', 'Driver License', 'رخصة قيادة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (18, 'select_route', 'Select Route', 'حدد الطريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (19, 'edit_vehicle', 'Edit Vehicle', 'تحرير السيارة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (20, 'add_students', 'Add Students', ' إضافة الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (21, 'vehicle_number', 'Vehicle Number', 'عدد المركبات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (22, 'select_route_first', 'Select Route First', 'حدد الطريق أولا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (23, 'transport_fee', 'Transport Fee', 'مصاريف الشحن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (24, 'control', 'Control', 'مراقبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (25, 'set_students', 'Set Students', 'تعيين الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (26, 'hostel_list', 'Hostel List', 'قائمة نزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (27, 'watchman_name', 'Watchman Name', 'اسم الحارس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (28, 'hostel_address', 'Hostel Address', 'عنوان الفندق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (29, 'edit_hostel', 'Edit Hostel', 'تحرير نزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (30, 'room_name', 'Room Name', 'اسم الغرفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (31, 'no_of_beds', 'No Of Beds', 'عدد الأسرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (32, 'select_hostel_first', 'Select Hostel First', 'حدد نزل أولا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (33, 'remaining', 'Remaining', 'متبق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (34, 'hostel_fee', 'Hostel Fee', 'رسوم النزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (35, 'accountant_list', 'Accountant List', 'قائمة المحاسبين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (36, 'students_fees', 'Students Fees', 'رسوم الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (37, 'fees_status', 'Fees Status', 'حالة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (38, 'books', 'Books', 'الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (39, 'home_page', 'Home Page', 'الصفحة الرئيسية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (40, 'collected', 'Collected', 'جمع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (41, 'student_mark', 'Student Mark', 'علامة الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (42, 'select_exam_first', 'Select Exam First', 'حدد الامتحان أولا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (43, 'transport_details', 'Transport Details', 'تفاصيل النقل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (44, 'no_of_teacher', 'No of Teacher', 'لا المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (45, 'basic_details', 'Basic Details', 'تفاصيل أساسية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (46, 'fee_progress', 'Fee Progress', 'رسوم التقدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (47, 'word', 'Word', 'كلمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (48, 'book_category', 'Book Category', 'فئة الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (49, 'driver_phone', 'Driver Phone', 'سائق الهاتف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (50, 'invalid_csv_file', 'Invalid / Corrupted CSV File', 'ملف كسف غير صالح / معطل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (51, 'requested_book_list', 'Requested Book List', 'طلب قائمة الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (52, 'request_status', 'Request Status', 'حالة الطلب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (53, 'book_request', 'Book Request', 'طلب الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (54, 'logout', 'Logout', 'الخروج', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (55, 'select_payment_method', 'Select Payment Method', 'اختار طريقة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (56, 'select_method', 'Select Method', 'حدد الطريقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (57, 'payment', 'Payment', 'دفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (58, 'filter', 'Filter', 'منقي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (59, 'status', 'Status', 'الحالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (60, 'paid', 'Paid', 'دفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (61, 'unpaid', 'Unpaid', 'غير مدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (62, 'method', 'Method', 'طريقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (63, 'cash', 'Cash', 'السيولة النقدية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (64, 'check', 'Check', 'الاختيار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (65, 'card', 'Card', 'بطاقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (66, 'payment_history', 'Payment History', 'تاريخ الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (67, 'category', 'Category', 'فئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (68, 'book_list', 'Book List', 'قائمة الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (69, 'author', 'Author', 'مؤلف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (70, 'price', 'Price', 'السعر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (71, 'available', 'Available', 'متاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (72, 'unavailable', 'Unavailable', 'غير متوفره', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (73, 'transport_list', 'Transport List', 'قائمة النقل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (74, 'edit_transport', 'Edit Transport', 'تحرير النقل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (75, 'hostel_name', 'Hostel Name', 'اسم المهجع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (76, 'number_of_room', 'Hostel Of Room', 'عدد الغرف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (77, 'yes', 'Yes', 'نعم فعلا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (78, 'no', 'No', 'لا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (79, 'messages', 'Messages', 'رسائل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (80, 'compose', 'Compose', 'إرسال رسالة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (81, 'recipient', 'Recipient', 'مستلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (82, 'select_a_user', 'Select A User', 'تحديد مستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (83, 'send', 'Send', 'إرسال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (84, 'global_settings', 'Global Settings', 'اعدادات النظام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (85, 'currency', 'Currency', 'عملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (86, 'system_email', 'System Email', 'نظام البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (87, 'create', 'Create', 'خلق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (88, 'save', 'Save', 'حفظ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (89, 'file', 'File', 'ملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (90, 'theme_settings', 'Theme Settings', 'إعدادات موضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (91, 'default', 'Default', 'افتراضي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (92, 'select_theme', 'Select Theme', 'اختر الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (93, 'upload_logo', 'Upload Logo', 'تحميل الشعار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (94, 'upload', 'Upload', 'تحميل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (95, 'remember', 'Remember', 'تذكر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (96, 'not_selected', 'Not Selected', 'لم يتم اختياره', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (97, 'disabled', 'Disabled', 'معاق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (98, 'inactive_account', 'Inactive Account', 'حساب غير نشط', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (99, 'update_translations', 'Update Translations', 'تحديث الترجمات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (100, 'language_list', 'Language List', 'قائمة لغة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (101, 'option', 'Option', 'خيار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (102, 'edit_word', 'Edit Word', 'تحرير الكلمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (103, 'update_profile', 'Update Profile', 'تحديث الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (104, 'current_password', 'Current Password', 'كلمة السر الحالية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (105, 'new_password', 'New Password', 'كلمة السر الجديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (106, 'login', 'Login', 'تسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (107, 'reset_password', 'Reset Password', 'اعادة تعيين كلمة السر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (108, 'present', 'Present', 'حاضر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (109, 'absent', 'Absent', 'غائب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (110, 'update_attendance', 'Update Attendance', 'تحديث الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (111, 'undefined', 'Undefined', 'غير محدد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (112, 'back', 'Back', 'الى الخلف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (113, 'save_changes', 'Save Changes', 'حفظ التغيرات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (114, 'uploader', 'Uploader', 'رافع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (115, 'download', 'Download', 'تحميل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (116, 'remove', 'Remove', 'إزالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (117, 'print', 'Print', 'طباعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (118, 'select_file_type', 'Select File Type', 'حدد نوع الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (119, 'excel', 'Excel', 'تفوق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (120, 'other', 'Other', 'آخر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (121, 'students_of_class', 'Students Of Class', 'طلبة الدرجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (122, 'marks_obtained', 'Marks Obtained', 'العلامات التي يحصل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (123, 'attendance_for_class', 'Attendance For Class', 'الحضور لفئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (124, 'receiver', 'Receiver', 'المتلقي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (125, 'please_select_receiver', 'Please Select Receiver', 'الرجاء الإختيار استقبال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (126, 'session_changed', 'Session Changed', 'جلسة تغيير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (127, 'exam_marks', 'Exam Marks', 'علامات الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (128, 'total_mark', 'Total Mark', 'عدد الأقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (129, 'mark_obtained', 'Mark Obtained', 'علامة حصل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (130, 'invoice/payment_list', 'Invoice / Payment List', 'فاتورة / قائمة دفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (131, 'obtained_marks', 'Obtained Marks', 'العلامات التي تم الحصول عليها', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (132, 'highest_mark', 'Highest Mark', 'أعلى الأقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (133, 'grade', 'Grade (GPA)', 'درجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (134, 'dashboard', 'Dashboard', 'لوحة القيادة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (135, 'student', 'Student', 'طالب علم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (136, 'rename', 'Rename', 'إعادة تسمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (137, 'class', 'Class', 'صف مدرسي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (138, 'teacher', 'Teacher', 'مدرس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (139, 'parents', 'Parents', 'الآباء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (140, 'subject', 'Subject', 'موضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (141, 'student_attendance', 'Student Attendance', 'حضور الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (142, 'exam_list', 'Exam List', 'قائمة الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (143, 'grades_range', 'Grades Range', 'مجموعة الدرجات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (144, 'loading', 'Loading', 'جار التحميل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (145, 'library', 'Library', 'مكتبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (146, 'hostel', 'Hostel', 'المهجع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (147, 'events', 'Events', 'اللافتة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (148, 'message', 'Message', 'الرسالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (149, 'translations', 'Translations', 'ترجمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (150, 'account', 'Account', 'حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (151, 'selected_session', 'Selected Session', 'جلسة مختارة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (152, 'change_password', 'Change Password', 'تغيير كلمة السر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (153, 'section', 'Section', 'قسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (154, 'edit', 'Edit', 'تحرير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (155, 'delete', 'Delete', 'حذف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (156, 'cancel', 'Cancel', 'إلغاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (157, 'parent', 'Parent', 'أصل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (158, 'attendance', 'Attendance', 'الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (159, 'addmission_form', 'Admission Form', 'شكل القبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (160, 'name', 'Name', 'اسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (161, 'select', 'Select', 'اختار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (162, 'roll', 'Roll', 'لفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (163, 'birthday', 'Date Of Birth', 'تاريخ الميلاد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (164, 'gender', 'Gender', 'جنس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (165, 'male', 'Male', 'ذكر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (166, 'female', 'Female', 'أنثى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (167, 'address', 'Address', 'عنوان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (168, 'phone', 'Phone', 'هاتف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (169, 'email', 'Email', 'البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (170, 'password', 'Password', 'كلمه السر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (171, 'transport_route', 'Transport Route', 'النقل الطريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (172, 'photo', 'Photo', 'صورة فوتوغرافية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (173, 'select_class', 'Select Class', 'حدد فئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (174, 'username_password_incorrect', 'Username Or Password Is Incorrect', 'اسم المستخدم أو كلمة المرور غير صحيحة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (175, 'select_section', 'Select Section', 'حدد القسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (176, 'options', 'Options', 'خيارات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (177, 'mark_sheet', 'Mark Sheet', 'ورقة علامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (178, 'profile', 'Profile', 'الملف الشخصي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (179, 'select_all', 'Select All', 'اختر الكل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (180, 'select_none', 'Select None', 'حدد بلا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (181, 'average', 'Average', 'متوسط', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (182, 'transfer', 'Transfer', 'تحويل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (183, 'edit_teacher', 'Edit Teacher', 'تحرير المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (184, 'sex', 'Sex', 'جنس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (185, 'marksheet_for', 'Marksheet For', 'ورقة علامة ل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (186, 'total_marks', 'Total Marks', 'مجموع الدرجات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (187, 'parent_phone', 'Parent Phone', 'الأم الهاتف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (188, 'subject_author', 'Subject Author', 'الموضوع المؤلف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (189, 'update', 'Update', 'تحديث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (190, 'class_list', 'Class List', 'قائمة الطبقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (191, 'class_name', 'Class Name', 'اسم الطبقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (192, 'name_numeric', 'Name Numeric', 'اسم الرقمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (193, 'select_teacher', 'Select Teacher', 'حدد المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (194, 'edit_class', 'Edit Class', 'تحرير الفئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (195, 'section_name', 'Section Name', 'اسم القسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (196, 'add_section', 'Add Section', 'إضافة مقطع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (197, 'subject_list', 'Subject List', 'قائمة الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (198, 'subject_name', 'Subject Name', 'اسم الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (199, 'edit_subject', 'Edit Subject', 'تحرير الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (200, 'day', 'Day', 'يوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (201, 'starting_time', 'Starting Time', 'ابتداء من الوقت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (202, 'hour', 'Hour', 'ساعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (203, 'minutes', 'Minutes', 'دقيقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (204, 'ending_time', 'Ending Time', 'إنهاء الوقت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (205, 'select_subject', 'Select Subject', 'حدد الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (206, 'select_date', 'Select Date', 'حدد التاريخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (207, 'select_month', 'Select Month', 'اختر الشهر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (208, 'select_year', 'Select Year', 'اختر السنة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (209, 'add_language', 'Add Language', 'إضافة لغة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (210, 'exam_name', 'Exam Name', 'اسم الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (211, 'date', 'Date', 'تاريخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (212, 'comment', 'Comment', 'التعليق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (213, 'edit_exam', 'Edit Exam', 'تحرير امتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (214, 'grade_list', 'Grade List', 'قائمة الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (215, 'grade_name', 'Grade Name', 'اسم الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (216, 'grade_point', 'Grade Point', 'الصف نقطة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (217, 'select_exam', 'Select Exam', 'حدد الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (218, 'students', 'Students', 'الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (219, 'subjects', 'Subjects', 'المواضيع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (220, 'total', 'Total', 'مجموع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (221, 'select_academic_session', 'Select Academic Session', 'حدد الدورة الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (222, 'invoice_informations', 'Invoice Informations', 'معلومات الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (223, 'title', 'Title', 'عنوان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (224, 'description', 'Description', 'وصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (225, 'payment_informations', 'Payment Informations', 'معلومات الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (226, 'view_invoice', 'View Invoice', 'عرض الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (227, 'payment_to', 'Payment To', 'دفع ل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (228, 'bill_to', 'Bill To', 'فاتورة الى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (229, 'total_amount', 'Total Amount', 'المبلغ الإجمالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (230, 'paid_amount', 'Paid Amount', 'المبلغ المدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (231, 'due', 'Due', 'بسبب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (232, 'amount_paid', 'Amount Paid', 'المبلغ المدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (233, 'payment_successfull', 'Payment has been successful', 'دفع النجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (234, 'add_invoice/payment', 'Add Invoice/payment', 'إضافة فاتورة / دفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (235, 'invoices', 'Invoices', 'الفواتير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (236, 'action', 'Action', 'عمل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (237, 'required', 'Required', 'مطلوب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (238, 'info', 'Info', 'معلومات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (239, 'month', 'Month', '\r\nشهر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (240, 'details', 'Details', 'تفاصيل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (241, 'new', 'New', 'الجديد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (242, 'reply_message', 'Reply Message', 'رسالة الرد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (243, 'message_sent', 'Message Sent', 'تم الارسال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (244, 'search', 'Search', 'بحث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (245, 'religion', 'Religion', 'دين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (246, 'blood_group', 'Blood group', 'فصيلة الدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (247, 'database_backup', 'Database Backup', 'قاعدة بيانات النسخ الاحتياطي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (248, 'search', 'Search', 'بحث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (249, 'payments_history', 'Fees Pay / Invoice', 'رسوم الدفع / الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (250, 'message_restore', 'Message Restore', 'استعادة الرسائل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (251, 'write_new_message', 'Write New Message', 'إرسال رسالة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (252, 'attendance_sheet', 'Attendance Sheet', 'ورقة الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (253, 'holiday', 'Holiday', 'يوم الاجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (254, 'exam', 'Exam', 'امتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (255, 'successfully', 'Successfully', 'بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (256, 'admin', 'Admin', 'مشرف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (257, 'inbox', 'Inbox', 'صندوق الوارد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (258, 'sent', 'Sent', 'أرسلت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (259, 'important', 'Important', 'مهم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (260, 'trash', 'Trash', 'قمامة، يدمر، يهدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (261, 'error', 'Unsuccessful', 'غير ناجحة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (262, 'sessions_list', 'Sessions List', 'قائمة الجلسات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (263, 'session_settings', 'Session Settings', 'إعدادات الجلسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (264, 'add_designation', 'Add Designation', 'إضافة تسمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (265, 'users', 'Users', 'المستخدمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (266, 'librarian', 'Librarian', 'أمين المكتبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (267, 'accountant', 'Accountant', 'محاسب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (268, 'academics', 'Academics', 'مؤسسيا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (269, 'employees_attendance', 'Employees Attendance', 'حضور الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (270, 'set_exam_term', 'Set Exam Term', 'تعيين مدة الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (271, 'set_attendance', 'Set Attendance', 'تعيين الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (272, 'marks', 'Marks', 'علامات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (273, 'books_category', 'Books Category', 'فئة الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (274, 'transport', 'Transport', 'المواصلات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (275, 'fees', 'Fees', 'رسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (276, 'fees_allocation', 'Fees Allocation', 'توزيع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (277, 'fee_category', 'Fee Category', 'فئة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (278, 'report', 'Report', 'أبلغ عن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (279, 'employee', 'Employee', 'الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (280, 'invoice', 'Invoice', 'فاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (281, 'event_catalogue', 'Event Catalogue', 'كتالوج الأحداث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (282, 'total_paid', 'Total Paid', 'مجموع المبالغ المدفوعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (283, 'total_due', 'Total Due', 'الاجمالي المستحق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (284, 'fees_collect', 'Fees Collect', 'تحصيل الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (285, 'total_school_students_attendance', 'Total School Students Attendance', 'مجموع طلاب المدارس الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (286, 'overview', 'Overview', 'نظرة عامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (287, 'currency_symbol', 'Currency Symbol', 'رمز العملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (288, 'enable', 'Enable', 'مكن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (289, 'disable', 'Disable', 'تعطيل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (290, 'payment_settings', 'Payment Settings', 'إعدادات الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (291, 'student_attendance_report', 'Student Attendance Report', 'تقرير حضور الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (292, 'attendance_type', 'Attendance Type', 'نوع الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (293, 'late', 'Late', 'متأخر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (294, 'employees_attendance_report', 'Employees Attendance Report', 'الموظفين تقرير الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (295, 'attendance_report_of', 'Attendance Report Of', 'تقرير الحضور من', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (296, 'fee_paid_report', 'Fee Paid Report', 'الرسوم المدفوعة التقرير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (297, 'invoice_no', 'Invoice No', 'رقم الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (298, 'payment_mode', 'Payment Mode', 'طريقة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (299, 'payment_type', 'Payment Type', 'نوع الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (300, 'done', 'Done', 'فعله', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (301, 'select_fee_category', 'Select Fee Category', 'حدد فئة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (302, 'discount', 'Discount', 'خصم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (303, 'enter_discount_amount', 'Enter Discount Amount', 'أدخل مبلغ الخصم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (304, 'online_payment', 'Online Payment', 'الدفع عن بعد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (305, 'student_name', 'Student Name', 'أسم الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (306, 'invoice_history', 'Invoice History', 'تاريخ الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (307, 'discount_amount', 'Discount Amount', 'مقدار الخصم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (308, 'invoice_list', 'Invoice List', 'قائمة الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (309, 'partly_paid', 'Partly Paid', 'تدفع جزئيا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (310, 'fees_list', 'Fees List', 'قائمة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (311, 'voucher_id', 'Voucher ID', 'معرف القسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (312, 'transaction_date', 'Transaction Date', 'تاريخ الصفقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (313, 'admission_date', 'Admission Date', 'تاريخ القبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (314, 'user_status', 'User Status', 'حالة المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (315, 'nationality', 'Nationality', 'جنسية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (316, 'register_no', 'Register No', 'سجل رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (317, 'first_name', 'First Name', 'الاسم الاول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (318, 'last_name', 'Last Name', 'الكنية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (319, 'state', 'State', 'حالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (320, 'transport_vehicle_no', 'Transport Vehicle No', 'رقم مركبة النقل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (321, 'percent', 'Percent', 'نسبه مئويه', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (322, 'average_result', 'Average Result', 'متوسط ​​النتيجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (323, 'student_category', 'Student Category', 'طالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (324, 'category_name', 'Category Name', 'اسم التصنيف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (325, 'category_list', 'Category List', 'قائمة الفئات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (326, 'please_select_student_first', 'Please Select Students First', 'يرجى اختيار الطلاب أولا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (327, 'designation', 'Designation', 'تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (328, 'qualification', 'Qualification', 'المؤهل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (329, 'account_deactivated', 'Account Deactivated', 'تم إلغاء تنشيط الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (330, 'account_activated', 'Account Activated', 'تم تنشيط الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (331, 'designation_list', 'Designation List', 'قائمة التعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (332, 'joining_date', 'Joining Date', 'تاريخ الانضمام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (333, 'relation', 'Relation', 'علاقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (334, 'father_name', 'Father Name', 'اسم الأب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (335, 'librarian_list', 'Librarian List', 'قائمة أمين المكتبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (336, 'class_numeric', 'Class Numeric', 'فئة رقمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (337, 'maximum_students', 'Maximum Students', 'الحد الأقصى للطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (338, 'class_room', 'Class Room', 'قاعة الدراسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (339, 'pass_mark', 'Pass Mark', 'علامة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (340, 'exam_time', 'Exam Time (Min)', 'وقت الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (341, 'time', 'Time', 'زمن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (342, 'subject_code', 'Subject Code', 'رمز الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (343, 'full_mark', 'Full Mark', 'درجة كاملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (344, 'subject_type', 'Subject Type', 'نوع الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (345, 'date_of_publish', 'Date Of Publish', 'تاريخ النشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (346, 'file_name', 'File Name', 'اسم الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (347, 'students_list', 'Students List', 'قائمة الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (348, 'start_date', 'Start Date', 'تاريخ البدء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (349, 'end_date', 'End Date', 'تاريخ الانتهاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (350, 'term_name', 'Term Name', 'اسم المدى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (351, 'grand_total', 'Grand Total', 'المبلغ الإجمالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (352, 'result', 'Result', 'نتيجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (353, 'books_list', 'Books List', 'قائمة الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (354, 'book_isbn_no', 'Book ISBN No', 'كتاب رقم إيسبن رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (355, 'total_stock', 'Total Stock', 'إجمالي الأسهم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (356, 'issued_copies', 'Issued Copies', 'تم إصدار نسخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (357, 'publisher', 'Publisher', 'الناشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (358, 'books_issue', 'Books Issue', 'كتاب المسألة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (359, 'user', 'User', 'المستعمل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (360, 'fine', 'Fine', 'غرامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (361, 'pending', 'Pending', 'قيد الانتظار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (362, 'return_date', 'Return Date', 'تاريخ العودة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (363, 'accept', 'Accept', 'قبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (364, 'reject', 'Reject', 'رفض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (365, 'issued', 'Issued', 'نشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (366, 'return', 'Return', 'إرجاع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (367, 'renewal', 'Renewal', 'تجديد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (368, 'fine_amount', 'Fine Amount', 'كمية غرامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (369, 'password_mismatch', 'Password Mismatch', 'عدم تطابق كلمة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (370, 'settings_updated', 'Settings Update', 'تحديث الإعدادات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (371, 'pass', 'Pass', 'البشري', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (372, 'event_to', 'Event To', 'الحدث ل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (373, 'all_users', 'All Users', 'جميع المستخدمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (374, 'employees_list', 'Employees List', 'قائمة الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (375, 'on', 'On', 'على', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (376, 'timezone', 'Timezone', 'وحدة زمنية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (377, 'get_result', 'Get Result', 'الحصول على نتيجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (378, 'apply', 'Apply', 'تطبيق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (379, 'hrm', 'Human Resource', 'الموارد البشرية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (380, 'payroll', 'Payroll', 'كشف رواتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (381, 'salary_assign', 'Salary Assign', 'مراقبة الرواتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (382, 'employee_salary', 'Payment Salary', 'دفع الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (383, 'application', 'Application', 'الوضعية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (384, 'award', 'Award', 'جائزة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (385, 'basic_salary', 'Basic Salary', 'راتب اساسي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (386, 'employee_name', 'Employee Name', 'اسم الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (387, 'name_of_allowance', 'Name Of Allowance', 'اسم البدل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (388, 'name_of_deductions', 'Name Of Deductions', 'اسم الاستقطاعات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (389, 'all_employees', 'All Employees', 'كل الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (390, 'total_allowance', 'Total Allowance', 'مجموع المخصصات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (391, 'total_deduction', 'Total Deductions', 'مجموع الخصومات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (392, 'net_salary', 'Net Salary', 'صافي الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (393, 'payslip', 'Payslip', 'قسيمة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (394, 'days', 'Days', 'أيام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (395, 'category_name_already_used', 'Category Name Already Used', 'اسم الفئة المستخدمة من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (396, 'leave_list', 'Leave List', 'قائمة الإجازات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (397, 'leave_category', 'Leave Category', 'ترك الفئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (398, 'applied_on', 'Applied On', 'تطبيق على', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (399, 'accepted', 'Accepted', 'قبلت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (400, 'leave_statistics', 'Leave Statistics', 'وترك الإحصاءات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (401, 'leave_type', 'Leave Type', 'نوع الإجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (402, 'reason', 'Reason', 'السبب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (403, 'close', 'Close', 'أغلق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (404, 'give_award', 'Give Award', 'إعطاء الجائزة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (405, 'list', 'List', 'قائمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (406, 'award_name', 'Award Name', 'اسم الجائزة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (407, 'gift_item', 'Gift Item', 'هدية البند', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (408, 'cash_price', 'Cash Price', 'سعر الصرف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (409, 'award_reason', 'Award Reason', 'جائزة السبب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (410, 'given_date', 'Given Date', 'تاريخ معين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (411, 'apply_leave', 'Apply Leave', 'تطبيق الإجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (412, 'leave_application', 'Leave Application', 'اترك التطبيق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (413, 'allowances', 'Allowances', 'البدلات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (414, 'add_more', 'Add More', 'أضف المزيد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (415, 'deductions', 'Deductions', 'الخصومات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (416, 'salary_details', 'Salary Details', 'تفاصيل الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (417, 'salary_month', 'Salary Month', 'راتب شهر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (418, 'leave_data_update_successfully', 'Leave Data Updated Successfully', 'ترك البيانات تحديثها بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (419, 'fees_history', 'Fees History', 'تاريخ الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (420, 'bank_name', 'Bank Name', 'اسم البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (421, 'branch', 'Branch', 'فرع شجرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (422, 'bank_address', 'Bank Address', 'عنوان البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (423, 'ifsc_code', 'IFSC Code', 'رمز إفسك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (424, 'account_no', 'Account No', 'رقم الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (425, 'add_bank', 'Add Bank', 'إضافة بنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (426, 'account_name', 'Account Holder', 'أسم الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (427, 'database_backup_completed', 'Database Backup Completed', 'اكتمل قاعدة بيانات النسخ الاحتياطي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (428, 'restore_database', 'Restore Database', 'استعادة قاعدة البيانات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (429, 'template', 'Template', 'قالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (430, 'time_and_date', 'Time And Date', 'الوقت و التاريخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (431, 'everyone', 'Everyone', 'كل واحد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (432, 'invalid_amount', 'Invalid Amount', 'مبلغ غير صحيح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (433, 'leaving_date_is_not_available_for_you', 'Leaving Date Is Not Available For You', 'ترك التاريخ غير متاح لك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (434, 'animations', 'Animations', 'الرسوم المتحركة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (435, 'email_settings', 'Email Settings', 'إعدادات البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (436, 'deduct_month', 'Deduct Month', 'خصم الشهر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (437, 'no_employee_available', 'No Employee Available', 'لا يتوفر موظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (438, 'advance_salary_application_submitted', 'Advance Salary Application Submitted', 'تم تقديم طلب الراتب المتقدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (439, 'date_format', 'Date Format', 'صيغة التاريخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (440, 'id_card_generate', 'ID Card Generate', 'بطاقة الهوية تولد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (441, 'issue_salary', 'Issue Salary', 'إصدار الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (442, 'advance_salary', 'Advance Salary', 'راتب مقدما', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (443, 'logo', 'Logo', 'شعار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (444, 'book_request', 'Book Request', 'طلب الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (445, 'reporting', 'Reporting', 'التقارير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (446, 'paid_salary', 'Paid Salary', 'الراتب المدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (447, 'due_salary', 'Due Salary', 'الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (448, 'route', 'Route', 'طريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (449, 'academic_details', 'Academic Details', 'التفاصيل الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (450, 'guardian_details', 'Guardian Details', 'التفاصيل الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (451, 'due_amount', 'Due Amount', 'مبلغ مستحق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (452, 'fee_due_report', 'Fee Due Report', 'تقرير الرسوم المستحقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (453, 'other_details', 'Other Details', 'تفاصيل أخرى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (454, 'last_exam_report', 'Last Exam Report', 'تقرير الاختبار الأخير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (455, 'book_issued', 'Book Issued', ' كتاب صدر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (456, 'interval_month', 'Interval 30 Days', 'الفاصل الزمني 30 يومًا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (457, 'attachments', 'Attachments', 'مرفقات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (458, 'fees_payment', 'Fees Payment', 'دفع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (459, 'fees_summary', 'Fees Summary', 'ملخص الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (460, 'total_fees', 'Total Fees', 'الرسوم الكلية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (461, 'weekend_attendance_inspection', 'Weekend Attendance Inspection', 'فحص الحضور في عطلة نهاية الاسبوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (462, 'book_issued_list', 'Book Issued List', 'كتاب صدر قائمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (463, 'lose_your_password', 'Lose Your Password?', '?تفقد كلمة المرور الخاصة بك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (464, 'all_branch_dashboard', 'All Branch Dashboard', 'كل لوحة فرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (465, 'academic_session', 'Academic Session', 'الدورة الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (466, 'all_branches', 'All Branches', 'كل الفروع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (467, 'admission', 'Admission', 'قبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (468, 'create_admission', 'Create Admission', 'إنشاء القبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (469, 'multiple_import', 'Multiple Import', 'استيراد متعدد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (470, 'student_details', 'Student Details', 'تفاصيل الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (471, 'student_list', 'Student List', 'قائمة الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (472, 'login_deactivate', 'Login Deactivate', 'تسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (473, 'parents_list', 'Parents List', 'قائمة الوالدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (474, 'add_parent', 'Add Parent', 'أضف الوالد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (475, 'employee_list', 'Employee List', 'قائمة موظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (476, 'add_department', 'Add Department', 'أضف قسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (477, 'add_employee', 'Add Employee', 'إضافة موظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (478, 'salary_template', 'Salary Template', 'قالب الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (479, 'salary_payment', 'Salary Payment', 'دفع المرتبات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (480, 'payroll_summary', 'Payroll Summary', 'ملخص الرواتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (481, 'academic', 'Academic', 'أكاديمي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (482, 'control_classes', 'Control Classes', 'فئات التحكم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (483, 'assign_class_teacher', 'Assign Class Teacher', 'تعيين معلم الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (484, 'class_assign', 'Class Assign', 'تعيين فئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (485, 'assign', 'Assign', 'تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (486, 'promotion', 'Promotion', 'ترقية وظيفية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (487, 'attachments_book', 'Attachments Book', 'كتاب المرفقات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (488, 'upload_content', 'Upload Content', 'تحميل المحتوى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (489, 'attachment_type', 'Attachment Type', 'نوع المرفق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (490, 'exam_master', 'Exam Master', 'الامتحان ماجستير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (491, 'exam_hall', 'Exam Hall', 'قاعة الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (492, 'mark_entries', 'Mark Entries', 'إدخالات مارك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (493, 'tabulation_sheet', 'Tabulation Sheet', 'ورقة الجدولة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (494, 'supervision', 'Supervision', 'إشراف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (495, 'hostel_master', 'Hostel Master', 'نزل ماستر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (496, 'hostel_room', 'Hostel Room', 'غرفة نزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (497, 'allocation_report', 'Allocation Report', 'تقرير التخصيص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (498, 'route_master', 'Route Master', 'سيد الطريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (499, 'vehicle_master', 'Vehicle Master', 'سيد السيارة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (500, 'stoppage', 'Stoppage', 'إضراب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (501, 'assign_vehicle', 'Assign Vehicle', 'تخصيص مركبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (502, 'reports', 'Reports', 'تقارير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (503, 'books_entry', 'Books Entry', 'دخول الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (504, 'event_type', 'Event Type', 'نوع الحدث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (505, 'add_events', 'Add Events', 'إضافة أحداث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (506, 'student_accounting', 'Student Accounting', 'محاسبة الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (507, 'create_single_invoice', 'Create Single Invoice', 'إنشاء فاتورة واحدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (508, 'create_multi_invoice', 'Create Multi Invoice', 'إنشاء متعدد الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (509, 'summary_report', 'Summary Report', 'تقرير ملخص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (510, 'office_accounting', 'Office Accounting', 'محاسبة المكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (511, 'under_group', 'Under Group', 'تحت المجموعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (512, 'bank_account', 'Bank Account', 'حساب البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (513, 'ledger_account', 'Ledger Account', 'حساب دفتر الأستاذ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (514, 'create_voucher', 'Create Voucher', 'إنشاء قسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (515, 'day_book', 'Day Book', 'كتاب اليوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (516, 'cash_book', 'Cash Book', 'كتاب النقدية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (517, 'bank_book', 'Bank Book', 'كتاب البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (518, 'ledger_book', 'Ledger Book', 'دفتر الأستاذ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (519, 'trial_balance', 'Trial Balance', 'ميزان المراجعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (520, 'settings', 'Settings', 'الإعدادات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (521, 'sms_settings', 'Sms Settings', 'إعدادات الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (522, 'cash_book_of', 'Cash Book Of', 'كتاب النقدية من', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (523, 'by_cash', 'By Cash', 'نقدا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (524, 'by_bank', 'By Bank', 'عن طريق البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (525, 'total_strength', 'Total Strength', 'القوة الكلية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (526, 'teachers', 'Teachers', 'معلمون', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (527, 'student_quantity', 'Student Quantity', 'كمية الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (528, 'voucher', 'Voucher', 'قسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (529, 'total_number', 'Total Number', 'মোট সংখ্যা', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (530, 'total_route', 'Total Route', 'الطريق الإجمالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (531, 'total_room', 'Total Room', 'مجموع الغرفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (532, 'amount', 'Amount', 'كمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (533, 'branch_dashboard', 'Branch Dashboard', 'لوحة تحكم الفرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (534, 'branch_list', 'Branch List', 'قائمة الفرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (535, 'create_branch', 'Create Branch', 'إنشاء فرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (536, 'branch_name', 'Branch Name', 'اسم الفرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (537, 'school_name', 'School Name', 'اسم المدرسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (538, 'mobile_no', 'Mobile No', 'رقم الموبايل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (539, 'symbol', 'Symbol', 'رمز', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (540, 'city', 'City', 'مدينة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (541, 'academic_year', 'Academic Year', 'السنة الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (542, 'select_branch_first', 'First Select The Branch', 'أولا اختر الفرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (543, 'select_class_first', 'Select Class First', 'اختر الفئة الأولى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (544, 'select_country', 'Select Country', 'حدد الدولة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (545, 'mother_tongue', 'Mother Tongue', 'اللغة الأم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (546, 'caste', 'Caste', 'الطائفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (547, 'present_address', 'Present Address', 'العنوان الحالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (548, 'permanent_address', 'Permanent Address', 'العنوان الثابت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (549, 'profile_picture', 'Profile Picture', 'الصوره الشخصيه', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (550, 'login_details', 'Login Details', 'تفاصيل تسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (551, 'retype_password', 'Retype Password', 'أعد إدخال كلمة السر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (552, 'occupation', 'Occupation', 'الاحتلال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (553, 'income', 'Income', 'الإيرادات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (554, 'education', 'Education', 'التعليم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (555, 'first_select_the_route', 'First Select The Route', 'أولا اختر الطريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (556, 'hostel_details', 'Hostel Details', 'تفاصيل النزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (557, 'first_select_the_hostel', 'First Select The Hostel', 'প্রথম ছাত্রাবাস নির্বাচন', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (558, 'previous_school_details', 'Previous School Details', 'تفاصيل المدرسة السابقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (559, 'book_name', 'Book Name', 'اسم الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (560, 'select_ground', 'Select Ground', 'اختر الأرض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (561, 'import', 'Import', 'استيراد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (562, 'add_student_category', 'Add Student Category', 'إضافة فئة الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (563, 'id', 'Id', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (564, 'edit_category', 'Edit Category', 'تحرير الفئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (565, 'deactivate_account', 'Deactivate Account', 'تعطيل الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (566, 'all_sections', 'All Sections', 'كل الأقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (567, 'authentication_activate', 'Authentication Activate', 'تفعيل المصادقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (568, 'department', 'Department', ' قسم، أقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (569, 'salary_grades', 'Salary Grades', 'راتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (570, 'overtime', 'Overtime Rate (Per Hour)', 'معدل العمل الإضافي (لكل ساعة)', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (571, 'salary_grade', 'Salary Grade', 'راتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (572, 'payable_type', 'Payable Type', 'نوع الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (573, 'edit_type', 'Edit Type', 'تحرير النوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (574, 'role', 'Role', 'وظيفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (575, 'remuneration_info_for', 'Remuneration Info For', 'الأجور معلومات عن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (576, 'salary_paid', 'Salary Paid', 'الراتب المدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (577, 'salary_unpaid', 'Salary Unpaid', 'الراتب غير مدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (578, 'pay_now', 'Pay Now', 'ادفع الآن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (579, 'employee_role', 'Employee Role', 'دور الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (580, 'create_at', 'Create At', 'خلق في', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (581, 'select_employee', 'Select Employee', 'اختر الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (582, 'review', 'Review', 'إعادة النظر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (583, 'reviewed_by', 'Reviewed By', 'تمت مراجعته من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (584, 'submitted_by', 'Submitted By', 'المقدمة من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (585, 'employee_type', 'Employee Type', 'نوع موظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (586, 'approved', 'Approved', 'وافق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (587, 'unreviewed', 'Unreviewed', 'غير مراجع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (588, 'creation_date', 'Creation Date', 'تاريخ الإنشاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (589, 'no_information_available', 'No Information Available', 'لا توجد معلومات متاحة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (590, 'continue_to_payment', 'Continue To Payment', 'مواصلة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (591, 'overtime_total_hour', 'Overtime Total Hour', 'الساعة الاجمالية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (592, 'overtime_amount', 'Overtime Amount', 'مبلغ العمل الإضافي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (593, 'remarks', 'Remarks', 'تعليق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (594, 'view', 'View', 'رأي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (595, 'leave_appeal', 'Leave Appeal', 'اترك الاستئناف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (596, 'create_leave', 'Create Leave', 'خلق إجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (597, 'user_role', 'User Role', 'دور المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (598, 'date_of_start', 'Date Of Start', 'تاريخ البدء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (599, 'date_of_end', 'Date Of End', 'تاريخ النهاية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (600, 'winner', 'Winner', 'الفائز', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (601, 'select_user', 'Select User', 'اختر المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (602, 'create_class', 'Create Class', 'إنشاء فصل دراسي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (603, 'class_teacher_allocation', 'Class Teacher Allocation', 'تخصيص معلم الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (604, 'class_teacher', 'Class Teacher', 'معلم الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (605, 'create_subject', 'Create Subject', 'إنشاء موضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (606, 'select_multiple_subject', 'Select Multiple Subject', 'حدد موضوعًا متعددًا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (607, 'teacher_assign', 'Teacher Assign', 'تعيين المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (608, 'teacher_assign_list', 'Teacher Assign List', 'قائمة تعيين المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (609, 'select_department_first', 'Select Department First', 'حدد القسم أولاً', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (610, 'create_book', 'Create Book', 'إنشاء كتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (611, 'book_title', 'Book Title', 'عنوان كتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (612, 'cover', 'Cover', 'التغطية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (613, 'edition', 'Edition', 'الإصدار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (614, 'isbn_no', 'ISBN No', 'رقم ISBN', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (615, 'purchase_date', 'Purchase Date', 'تاريخ الشراء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (616, 'cover_image', 'Cover Image', 'صورة الغلاف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (617, 'book_issue', 'Book Issue', 'إصدار الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (618, 'date_of_issue', 'Date Of Issue', 'تاريخ المسألة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (619, 'date_of_expiry', 'Date Of Expiry', 'تاريخ الانتهاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (620, 'select_category_first', 'Select Category First', 'حدد الفئة الأولى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (621, 'type_name', 'Type Name', 'أكتب اسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (622, 'type_list', 'Type List', 'قائمة الأنواع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (623, 'icon', 'Icon', 'أيقونة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (624, 'event_list', 'Event List', 'قائمة الأحداث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (625, 'create_event', 'Create Event', 'انشاء حدث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (626, 'type', 'Type', 'نوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (627, 'audience', 'Audience', 'الجمهور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (628, 'created_by', 'Created By', 'انشأ من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (629, 'publish', 'Publish', 'ينشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (630, 'everybody', 'Everybody', 'الجميع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (631, 'selected_class', 'Selected Class', 'فئة مختارة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (632, 'selected_section', 'Selected Section', 'القسم المختار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (633, 'information_has_been_updated_successfully', 'Information Has Been Updated Successfully', 'تم تحديث المعلومات بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (634, 'create_invoice', 'Create Invoice', 'إنشاء فاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (635, 'invoice_entry', 'Invoice Entry', 'إدخال الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (636, 'quick_payment', 'Quick Payment', 'دفع سريع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (637, 'write_your_remarks', 'Write Your Remarks', 'اكتب ملاحظاتك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (638, 'reset', 'Reset', 'إعادة تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (639, 'fees_payment_history', 'Fees Payment History', 'تاريخ دفع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (640, 'fees_summary_report', 'Fees Summary Report', 'تقرير ملخص الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (641, 'add_account_group', 'Add Account Group', 'إضافة مجموعة حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (642, 'account_group', 'Account Group', 'جماعة حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (643, 'account_group_list', 'Account Group List', 'قائمة مجموعة الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (644, 'mailbox', 'Mailbox', 'صندوق بريد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (645, 'refresh_mail', 'Refresh Mail', 'تحديث البريد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (646, 'sender', 'Sender', 'مرسل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (647, 'general_settings', 'General Settings', 'الاعدادات العامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (648, 'institute_name', 'Institute Name', 'اسم المعهد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (649, 'institution_code', 'Institution Code', 'رمز المؤسسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (650, 'sms_service_provider', 'Sms Service Provider', 'مزود خدمة الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (651, 'footer_text', 'Footer Text', 'نص التذييل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (652, 'payment_control', 'Payment Control', 'مراقبة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (653, 'sms_config', 'Sms Config', 'تكوين الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (654, 'sms_triggers', 'Sms Triggers', 'مشغلات الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (655, 'authentication_token', 'Authentication Token', 'رمز المصادقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (656, 'sender_number', 'Sender Number', 'رقم المرسل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (657, 'username', 'Username', 'اسم المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (658, 'api_key', 'Api Key', 'مفتاح API', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (659, 'authkey', 'Authkey', 'Authkey', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (660, 'sender_id', 'Sender Id', 'معرف الإرسال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (661, 'sender_name', 'Sender Name', 'اسم المرسل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (662, 'hash_key', 'Hash Key', 'مفتاح التجزئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (663, 'notify_enable', 'Notify Enable', 'إعلام تمكين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (664, 'exam_attendance', 'Exam Attendance', 'حضور الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (665, 'exam_results', 'Exam Results', 'نتائج الامتحانات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (666, 'email_config', 'Email Config', 'تكوين البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (667, 'email_triggers', 'Email Triggers', 'مشغلات البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (668, 'account_registered', 'Account Registered', 'تم تسجيل الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (669, 'forgot_password', 'Forgot Password', 'هل نسيت كلمة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (670, 'new_message_received', 'New Message Received', 'تم تلقي رسالة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (671, 'payslip_generated', 'Payslip Generated', 'تم إنشاء Payslip', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (672, 'leave_approve', 'Leave Approve', 'اترك الموافقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (673, 'leave_reject', 'Leave Reject', 'اترك رفض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (674, 'advance_salary_approve', 'Leave Reject', 'اترك رفض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (675, 'advance_salary_reject', 'Advance Salary Reject', 'رفض الراتب المسبق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (676, 'add_session', 'Add Session', 'إضافة جلسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (677, 'session', 'Session', 'جلسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (678, 'created_at', 'Created At', 'أنشئت في', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (679, 'sessions', 'Sessions', 'الجلسات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (680, 'flag', 'Flag', 'العلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (681, 'stats', 'Stats', 'احصائيات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (682, 'updated_at', 'Updated At', 'تم التحديث في', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (683, 'flag_icon', 'Flag Icon', 'رمز العلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (684, 'password_restoration', 'Password Restoration', 'استعادة كلمة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (685, 'forgot', 'Forgot', 'نسيت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (686, 'back_to_login', 'Back To Login', 'العودة لتسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (687, 'database_list', 'Database List', 'قائمة قاعدة البيانات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (688, 'create_backup', 'Create Backup', 'انشئ نسخة احتياطية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (689, 'backup', 'Backup', 'دعم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (690, 'backup_size', 'Backup Size', 'حجم النسخ الاحتياطي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (691, 'file_upload', 'File Upload', 'تحميل الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (692, 'parents_details', 'Parents Details', 'تفاصيل الوالدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (693, 'social_links', 'Social Links', 'روابط اجتماعية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (694, 'create_hostel', 'Create Hostel', 'إنشاء نزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (695, 'allocation_list', 'Allocation List', 'قائمة التخصيص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (696, 'payslip_history', 'Payslip History', 'سجل الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (697, 'my_attendance_overview', 'My Attendance Overview', 'نظرة عامة على الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (698, 'total_present', 'Total Present', 'المجموع الحالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (699, 'total_absent', 'Total Absent', 'المجموع الكلي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (700, 'total_late', 'Total Late', 'المجموع المتأخر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (701, 'class_teacher_list', 'Class Teacher List', 'قائمة مدرس الفصل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (702, 'section_control', 'Section Control', 'التحكم بالقسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (703, 'capacity ', 'Capacity', 'سعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (704, 'request', 'Request', 'طلب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (705, 'salary_year', 'Salary Year', 'سنة الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (706, 'create_attachments', 'Create Attachments', 'إنشاء المرفقات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (707, 'publish_date', 'Publish Date', 'تاريخ النشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (708, 'attachment_file', 'Attachment File', 'ملف المرفق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (709, 'age', 'Age', 'عمر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (710, 'student_profile', 'Student Profile', 'الملف الشخصي للطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (711, 'authentication', 'Authentication', 'المصادقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (712, 'parent_information', 'Parent Information', 'معلومات الوالدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (713, 'full_marks', 'Full Marks', 'علامات كاملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (714, 'passing_marks', 'Passing Marks', 'علامات النجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (715, 'highest_marks', 'Highest Marks', 'أعلى العلامات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (716, 'unknown', 'Unknown', 'مجهول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (717, 'unpublish', 'Unpublish', 'غير منشور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (718, 'login_authentication_deactivate', 'Login Authentication Deactivate', 'إلغاء تنشيط مصادقة تسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (719, 'employee_profile', 'Employee Profile', 'ملف تعريف الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (720, 'employee_details', 'Employee Details', 'تفاصيل الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (721, 'salary_transaction', 'Salary Transaction', 'معاملة الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (722, 'documents', 'Documents', 'مستندات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (723, 'actions', 'Actions', 'أجراءات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (724, 'activity', 'Activity', 'نشاط', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (725, 'department_list', 'Department List', 'قائمة الأقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (726, 'manage_employee_salary', 'Manage Employee Salary', 'إدارة راتب الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (727, 'the_configuration_has_been_updated', 'The Configuration Has Been Updated', 'تم تحديث التكوين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (728, 'add', 'Add', 'أضف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (729, 'create_exam', 'Create Exam', 'إنشاء امتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (730, 'term', 'Term', 'مصطلح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (731, 'add_term', 'Add Term', 'إضافة مصطلح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (732, 'create_grade', 'Create Grade', 'إنشاء تقدير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (733, 'mark_starting', 'Mark Starting', 'علامة البداية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (734, 'mark_until', 'Mark Until', 'ضع علامة حتى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (735, 'room_list', 'Room List', 'قائمة غرفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (736, 'room', 'Room', 'غرفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (737, 'route_list', 'Route List', 'قائمة المسار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (738, 'create_route', 'Create Route', 'إنشاء طريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (739, 'vehicle_list', 'Vehicle List', 'قائمة المركبات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (740, 'create_vehicle', 'Create Vehicle', 'إنشاء مركبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (741, 'stoppage_list', 'Stoppage List', 'قائمة التوقف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (742, 'create_stoppage', 'Create Stoppage', 'إنشاء توقف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (743, 'stop_time', 'Stop Time', 'وقت التوقف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (744, 'employee_attendance', 'Employee Attendance', 'حضور الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (745, 'attendance_report', 'Employee Attendance', 'حضور الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (746, 'opening_balance', 'Opening Balance', 'الرصيد الافتتاحي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (747, 'add_opening_balance', 'Add Opening Balance', 'إضافة رصيد افتتاحي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (748, 'credit', 'Credit', 'ائتمان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (749, 'debit', 'Debit', 'مدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (750, 'opening_balance_list', 'Opening Balance List', 'قائمة الرصيد الافتتاحي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (751, 'voucher_list', 'Voucher List', 'قائمة القسائم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (752, 'voucher_head', 'Voucher Head', 'رئيس قسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (753, 'payment_method', 'Payment Method', 'طريقة الدفع او السداد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (754, 'credit_ledger_account', 'Credit Ledger Account', 'حساب دفتر الأستاذ الائتماني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (755, 'debit_ledger_account', 'Debit Ledger Account', 'حساب دفتر الأستاذ المدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (756, 'voucher_no', 'Voucher No', 'رقم القسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (757, 'balance', 'Balance', 'توازن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (758, 'event_details', 'Event Details', 'تفاصيل الحدث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (759, 'welcome_to', 'Welcome To', 'مرحبا بك في', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (760, 'report_card', 'Report Card', 'بطاقة تقرير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (761, 'online_pay', 'Online Pay', 'الدفع عبر الإنترنت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (762, 'annual_fees_summary', 'Annual Fees Summary', 'ملخص الرسوم السنوية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (763, 'my_children', 'My Children', 'أطفالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (764, 'assigned', 'Assigned', 'تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (765, 'confirm_password', 'Confirm Password', 'تأكيد كلمة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (766, 'searching_results', 'Searching Results', 'نتائج البحث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (767, 'information_has_been_saved_successfully', 'Information Has Been Saved Successfully', 'تم حفظ المعلومات بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (768, 'information_deleted', 'The information has been successfully deleted', 'تم حذف المعلومات بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (769, 'deleted_note', '*Note : This data will be permanently deleted', '* ملاحظة: سيتم حذف هذه البيانات نهائيًا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (770, 'are_you_sure', 'Are You Sure?', 'هل أنت واثق؟', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (771, 'delete_this_information', 'Do You Want To Delete This Information?', 'هل تريد حذف هذه المعلومات؟', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (772, 'yes_continue', 'Yes, Continue', 'نعم ، استمر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (773, 'deleted', 'Deleted', 'تم الحذف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (774, 'collect', 'Collect', 'تجميع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (775, 'school_setting', 'School Setting', 'إعداد المدرسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (776, 'set', 'Set', 'جلس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (777, 'quick_view', 'Quick View', 'نظرة سريعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (778, 'due_fees_invoice', 'Due Fees Invoice', 'فاتورة رسوم مستحقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (779, 'my_application', 'My Application', 'طلبي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (780, 'manage_application', 'Manage Application', 'إدارة الطلب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (781, 'leave', 'Leave', 'غادر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (782, 'live_class_rooms', 'Live Class Rooms', 'غرف الصف المباشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (783, 'homework', 'Homework', 'واجب منزلي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (784, 'evaluation_report', 'Evaluation Report', 'تقرير التقييم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (785, 'exam_term', 'Exam Term', 'مصطلح الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (786, 'distribution', 'Distribution', 'توزيع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (787, 'exam_setup', 'Exam Setup', 'إعداد الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (788, 'sms', 'Sms', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (789, 'fees_type', 'Fees Type', 'نوع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (790, 'fees_group', 'Fees Group', 'مجموعة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (791, 'fine_setup', 'Fine Setup', 'الإعداد الجيد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (792, 'fees_reminder', 'Fees Reminder', 'تذكير بالرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (793, 'new_deposit', 'New Deposit', 'وديعة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (794, 'new_expense', 'New Expense', 'نفقة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (795, 'all_transactions', 'All Transactions', 'كل الحركات المالية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (796, 'head', 'Head', 'رئيس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (797, 'fees_reports', 'Fees Reports', 'تقارير الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (798, 'fees_report', 'Fees Report', 'تقرير الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (799, 'receipts_report', 'Receipts Report', 'تقرير الإيصالات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (800, 'due_fees_report', 'Due Fees Report', 'تقرير الرسوم المستحقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (801, 'fine_report', 'Fine Report', 'تقرير جيد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (802, 'financial_reports', 'Financial Reports', 'تقارير مالية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (803, 'statement', 'Statement', 'بيان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (804, 'repots', 'Repots', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (805, 'expense', 'Expense', 'مصروف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (806, 'transitions', 'Transitions', 'الانتقالات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (807, 'sheet', 'Sheet', 'ورقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (808, 'income_vs_expense', 'Income Vs Expense', 'الدخل مقابل المصاريف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (809, 'attendance_reports', 'Attendance Reports', 'تقارير الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (810, 'examination', 'Examination', 'فحص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (811, 'school_settings', 'School Settings', 'إعدادات المدرسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (812, 'role_permission', 'Role Permission', 'إذن الدور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (813, 'cron_job', 'Cron Job', 'وظيفة كرون', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (814, 'custom_field', 'Custom Field', 'حقل مخصص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (815, 'enter_valid_email', 'Enter Valid Email', 'أدخل بريدًا إلكترونيًا صالحًا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (816, 'lessons', 'Lessons', 'الدروس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (817, 'live_class', 'Live Class', 'فئة حية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (818, 'sl', 'Sl', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (819, 'meeting_id', 'Live Class', 'فئة حية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (820, 'start_time', 'Start Time', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (821, 'end_time', 'End Time', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (822, 'zoom_meeting_id', 'Zoom Meeting Id', 'تكبير / تصغير معرف الاجتماع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (823, 'zoom_meeting_password', 'Zoom Meeting Password', 'تكبير كلمة مرور الاجتماع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (824, 'time_slot', 'Time Slot', 'فسحة زمنية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (825, 'send_notification_sms', 'Send Notification Sms', 'إرسال رسالة إعلام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (826, 'host', 'Host', 'مضيف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (827, 'school', 'School', 'مدرسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (828, 'accounting_links', 'Accounting Links', 'روابط المحاسبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (829, 'applicant', 'Applicant', 'طالب وظيفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (830, 'apply_date', 'Apply Date', 'تاريخ تطبيق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (831, 'add_leave', 'Add Leave', 'أضف إجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (832, 'leave_date', 'Leave Date', 'تاريخ مغادرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (833, 'attachment', 'Attachment', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (834, 'comments', 'Comments', 'تعليقات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (835, 'staff_id', 'Staff Id', 'معرف الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (836, 'income_vs_expense_of', 'Income Vs Expense Of', 'دخل مقابل حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (837, 'designation_name', 'Designation Name', 'اسم التعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (838, 'already_taken', 'This %s already exists.', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (839, 'department_name', 'Department Name', 'اسم القسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (840, 'date_of_birth', 'Date Of Birth', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (841, 'bulk_delete', 'Bulk Delete', 'حذف مجمّع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (842, 'guardian_name', 'Guardian Name', 'اسم الوصي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (843, 'fees_progress', 'Fees Progress', 'رسوم التقدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (844, 'evaluate', 'Evaluate', 'تقييم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (845, 'date_of_homework', 'Date Of Homework', 'تاريخ الواجب المنزلي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (846, 'date_of_submission', 'Date Of Submission', 'تاريخ التقديم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (847, 'student_fees_report', 'Student Fees Report', 'تقرير رسوم الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (848, 'student_fees_reports', 'Student Fees Reports', 'تقارير رسوم الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (849, 'due_date', 'Due Date', 'تاريخ الاستحقاق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (850, 'payment_date', 'Payment Date', 'موعد الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (851, 'payment_via', 'Payment Via', 'الدفع عن طريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (852, 'generate', 'Generate', 'انشاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (853, 'print_date', 'Print Date', 'تاريخ الطباعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (854, 'bulk_sms_and_email', 'Bulk Sms And Email', 'الرسائل القصيرة والبريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (855, 'campaign_type', 'Campaign Type', 'نوع الحملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (856, 'both', 'Both', 'على حد سواء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (857, 'regular', 'Regular', 'منتظم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (858, 'Scheduled', 'Scheduled', 'المقرر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (859, 'campaign', 'Campaign', 'حملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (860, 'campaign_name', 'Campaign Name', 'اسم الحملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (861, 'sms_gateway', 'Sms Gateway', 'بوابة الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (862, 'recipients_type', 'Recipients Type', 'نوع المستلمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (863, 'recipients_count', 'Recipients Count', 'عدد المستلمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (864, 'body', 'Body', 'الجسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (865, 'guardian_already_exist', 'Guardian Already Exist', 'الوصي موجود بالفعل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (866, 'guardian', 'Guardian', 'وصي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (867, 'mother_name', 'Mother Name', 'اسم الأم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (868, 'bank_details', 'Bank Details', 'التفاصيل المصرفية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (869, 'skipped_bank_details', 'Skipped Bank Details', 'تخطي تفاصيل البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (870, 'bank', 'Bank', 'مصرف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (871, 'holder_name', 'Holder Name', 'اسم صاحب التسجيل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (872, 'bank_branch', 'Bank Branch', 'فرع بنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (873, 'custom_field_for', 'Custom Field For', 'حقل مخصص لـ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (874, 'label', 'Label', 'ضع الكلمة المناسبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (875, 'order', 'Order', 'طلب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (876, 'online_admission', 'Online Admission', 'القبول عبر الإنترنت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (877, 'field_label', 'Field Label', 'تسمية الميدان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (878, 'field_type', 'Field Label', 'تسمية الميدان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (879, 'default_value', 'Default Value', 'القيمة الافتراضية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (880, 'checked', 'Checked', 'التحقق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (881, 'unchecked', 'Unchecked', 'غير محدد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (882, 'roll_number', 'Roll Number', 'رقم اللفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (883, 'add_rows', 'Add Rows', 'إضافة صفوف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (884, 'salary', 'Salary', 'راتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (885, 'basic', 'Basic', 'الأساسي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (886, 'allowance', 'Allowance', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (887, 'deduction', 'Deduction', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (888, 'net', 'Net', 'Net', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (889, 'activated_sms_gateway', 'Activated Sms Gateway', 'بوابة الرسائل القصيرة المنشّطة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (890, 'account_sid', 'Account Sid', 'حساب Sid', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (891, 'roles', 'Roles', 'الأدوار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (892, 'system_role', 'System Role', 'دور النظام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (893, 'permission', 'Permission', 'الإذن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (894, 'edit_session', 'Edit Session', 'تحرير الجلسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (895, 'transactions', 'Transactions', 'المعاملات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (896, 'default_account', 'Default Account', 'الحساب الافتراضي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (897, 'deposit', 'Deposit', 'الوديعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (898, 'acccount', 'Acccount', 'حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (899, 'role_permission_for', 'Role Permission For', 'إذن دور لـ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (900, 'feature', 'Feature', 'خاصية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (901, 'access_denied', 'Access Denied', 'تم الرفض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (902, 'time_start', 'Time Start', 'وقت البدء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (903, 'time_end', 'Time End', 'انتهى الوقت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (904, 'month_of_salary', 'Month Of Salary', 'شهر الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (905, 'add_documents', 'Add Documents', 'أضف وثائق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (906, 'document_type', 'Document Type', 'نوع الوثيقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (907, 'document', 'Document', 'المستند', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (908, 'document_title', 'Document Title', 'عنوان الوثيقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (909, 'document_category', 'Document Category', 'فئة الوثيقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (910, 'exam_result', 'Exam Result', 'نتيجة الإمتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (911, 'my_annual_fee_summary', 'My Annual Fee Summary', 'ملخص رسومي السنوي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (912, 'book_manage', 'Book Manage', 'إدارة الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (913, 'add_leave_category', 'Add Leave Category', 'إضافة فئة إجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (914, 'edit_leave_category', 'Edit Leave Category', 'تحرير فئة الإجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (915, 'staff_role', 'Staff Role', 'دور الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (916, 'edit_assign', 'Edit Assign', 'تحرير تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (917, 'view_report', 'View Report', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (918, 'rank_out_of_5', 'Rank Out Of 5', 'مرتبة من 5', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (919, 'hall_no', 'Hall No', 'القاعة رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (920, 'no_of_seats', 'No Of Seats', 'عدد المقاعد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (921, 'mark_distribution', 'Mark Distribution', 'توزيع مارك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (922, 'exam_type', 'Exam Type', 'نوع الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (923, 'marks_and_grade', 'Marks And Grade', 'العلامات والدرجات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (924, 'min_percentage', 'Min Percentage', 'النسبة المئوية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (925, 'max_percentage', 'Max Percentage', 'النسبة المئوية القصوى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (926, 'cost_per_bed', 'Cost Per Bed', 'تكلفة السرير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (927, 'add_category', 'Add Category', 'إضافة فئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (928, 'category_for', 'Category For', 'التصنيف لـ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (929, 'start_place', 'Start Place', 'ابدأ مكان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (930, 'stop_place', 'Stop Place', 'مكان التوقف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (931, 'vehicle', 'Vehicle', 'مركبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (932, 'select_multiple_vehicle', 'Select Multiple Vehicle', 'حدد مركبة متعددة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (933, 'book_details', 'Book Details', 'تفاصيل الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (934, 'issued_by', 'Issued By', 'أصدرت من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (935, 'return_by', 'Return By', 'العودة بواسطة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (936, 'group', 'Group', 'مجموعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (937, 'individual', 'Individual', 'فرد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (938, 'recipients', 'Recipients', 'المستلمون', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (939, 'group_name', 'Group Name', 'أسم المجموعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (940, 'fee_code', 'Fee Code', 'كود الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (941, 'fine_type', 'Fine Type', 'نوع جيد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (942, 'fine_value', 'Fine Value', 'قيمة جيدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (943, 'late_fee_frequency', 'Late Fee Frequency', 'تردد الرسوم المتأخرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (944, 'fixed_amount', 'Fixed Amount', 'مبلغ ثابت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (945, 'fixed', 'Fixed', 'ثابت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (946, 'daily', 'Daily', 'اليومي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (947, 'weekly', 'Weekly', 'أسبوعي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (948, 'monthly', 'Monthly', 'شهريا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (949, 'annually', 'Annually', 'سنويا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (950, 'first_select_the_group', 'First Select The Group', 'أولا حدد المجموعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (951, 'percentage', 'Percentage', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (952, 'value', 'Value', 'القيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (953, 'fee_group', 'Fee Group', 'مجموعة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (954, 'due_invoice', 'Due Invoice', 'فاتورة مستحقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (955, 'reminder', 'Reminder', 'تذكير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (956, 'frequency', 'Frequency', 'تكرر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (957, 'notify', 'Notify', 'أبلغ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (958, 'before', 'Before', 'قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (959, 'after', 'After', 'بعد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (960, 'number', 'Number', 'رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (961, 'ref_no', 'Ref No', 'مصدر رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (962, 'pay_via', 'Pay Via', 'ادفع عن طريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (963, 'ref', 'Ref', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (964, 'dr', 'Dr', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (965, 'cr', 'Cr', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (966, 'edit_book', 'Edit Book', 'تحرير كتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (967, 'leaves', 'Leaves', 'اوراق اشجار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (968, 'leave_request', 'Leave Request', 'طلب إجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (969, 'this_file_type_is_not_allowed', 'This File Type Is Not Allowed', 'نوع الملف هذا غير مسموح به', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (970, 'error_reading_the_file', 'Error Reading The File', 'خطأ في قراءة الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (971, 'staff', 'Staff', 'العاملين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (972, 'waiting', 'Waiting', 'انتظار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (973, 'live', 'Live', 'حي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (974, 'by', 'By', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (975, 'host_live_class', 'Host Live Class', 'استضافة فئة مباشرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (976, 'join_live_class', 'Join Live Class', 'انضم إلى Live Class', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (977, 'system_logo', 'System Logo', 'شعار النظام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (978, 'text_logo', 'Text Logo', 'شعار النص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (979, 'printing_logo', 'Printing Logo', 'شعار الطباعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (980, 'expired', 'Expired', 'منتهية الصلاحية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (981, 'collect_fees', 'Collect Fees', 'تحصيل الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (982, 'fees_code', 'Fees Code', 'كود الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (983, 'collect_by', 'Collect By', 'اجمع بواسطة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (984, 'fee_payment', 'Fee Payment', 'دفع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (985, 'write_message', 'Write Message', 'اكتب رسالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (986, 'discard', 'Discard', 'تجاهل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (987, 'message_sent_successfully', 'Message Sent Successfully', 'تم إرسال الرسالة بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (988, 'not_found_anything', 'Not Found Anything', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (989, 'email_subject', 'Email Subject', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (990, 'certificate', 'Certificate', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (991, 'templete', 'Templete', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (992, 'advance_salary_request', 'Advance Salary Request', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (993, 'system_update', 'System Update', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (994, 'visit_home_page', 'Visit Home Page', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (995, 'frontend', 'Frontend', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (996, 'setting', 'Setting', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (997, 'menu', 'Menu', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (998, 'page', 'Page', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (999, 'manage', 'Manage', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1000, 'slider', 'Slider', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1001, 'features', 'Features', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1002, 'testimonial', 'Testimonial', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1003, 'service', 'Service', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1004, 'faq', 'Faq', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1005, 'card_management', 'Card Management', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1006, 'id_card', 'Id Card', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1007, 'admit_card', 'Admit Card', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1008, 'update_now', 'Update Now', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1009, 'usename', 'Usename', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1010, 'website_page', 'Website Page', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1011, 'welcome', 'Welcome', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1012, 'services', 'Services', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1013, 'call_to_action_section', 'Call To Action Section', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1014, 'subtitle', 'Subtitle', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1015, 'cta', 'Cta', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1016, 'button_text', 'Button Text', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1017, 'button_url', 'Button Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1018, '_title', ' Title', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1019, 'meta', 'Meta', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1020, 'keyword', 'Keyword', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1021, 'position', 'Position', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1022, 'target_new_window', 'Target New Window', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1023, 'external_url', 'External Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1024, 'external_link', 'External Link', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1025, 'submit', 'Submit', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1026, 'appointment', 'Appointment', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1027, 'banner_photo', 'Banner Photo', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1028, 'contact', 'Contact', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1029, 'box_title', 'Box Title', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1030, 'box_description', 'Box Description', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1031, 'box_photo', 'Box Photo', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1032, 'form_title', 'Form Title', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1033, 'submit_button_text', 'Submit Button Text', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1034, 'map_iframe', 'Map Iframe', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1035, 'guardian_relation', 'Guardian Relation', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1036, 'button_text_1', 'Button Text 1', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1037, 'button_url_1', 'Button Url 1', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1038, 'button_text_2', 'Button Text 2', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1039, 'button_url_2', 'Button Url 2', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1040, 'left', 'Left', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1041, 'center', 'Center', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1042, 'right', 'Right', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1043, 'about', 'About', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1044, 'content', 'Content', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1045, 'about_photo', 'About Photo', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1046, 'parallax_photo', 'Parallax Photo', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1047, 'audition', 'Audition', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1048, 'show_website', 'Show Website', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1049, 'image', 'Image', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1050, 'experience_details', 'Experience Details', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1051, 'total_experience', 'Total Experience', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1052, 'class_schedule', 'Class Schedule', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1053, 'play', 'Play', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1054, 'video', 'Video', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1055, 'website', 'Website', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1056, 'cms', 'Cms', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1057, 'url_alias', 'Url Alias', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1058, 'cms_frontend', 'Cms Frontend', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1059, 'enabled', 'Enabled', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1060, 'receive_email_to', 'Receive Email To', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1061, 'captcha_status', 'Captcha Status', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1062, 'recaptcha_site_key', 'Recaptcha Site Key', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1063, 'recaptcha_secret_key', 'Recaptcha Secret Key', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1064, 'working_hours', 'Working Hours', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1065, 'fav_icon', 'Fav Icon', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1066, 'theme', 'Theme', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1067, 'fax', 'Fax', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1068, 'footer_about_text', 'Footer About Text', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1069, 'copyright_text', 'Copyright Text', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1070, 'facebook_url', 'Facebook Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1071, 'twitter_url', 'Twitter Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1072, 'youtube_url', 'Youtube Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1073, 'google_plus', 'Google Plus', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1074, 'linkedin_url', 'Linkedin Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1075, 'pinterest_url', 'Pinterest Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1076, 'instagram_url', 'Instagram Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1077, 'edit_attachments', 'Edit Attachments', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1078, 'cms_default_branch', 'Cms Default Branch', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1079, 'prefix', 'Prefix', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1080, 'url', 'Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1081, 'language_unpublished', 'Language Unpublished', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1082, 'you_are_now_using_the_latest_version', 'You Are Now Using The Latest Version', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1083, 'applicable_user', 'Applicable User', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1084, 'page_layout', 'Page Layout', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1085, 'background', 'Background', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1086, 'signature', 'Signature', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1087, 'edit_branch', 'Edit Branch', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1088, 'create_section', 'Create Section', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1089, 'section_list', 'Section List', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1090, 'edit_section', 'Edit Section', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1091, 'teacher_restricted', 'Teacher Restricted', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1092, 'no_sms_gateway_available', 'No Sms Gateway Available', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1093, 'SMS configuration not found', 'SMS Configuration Not Found', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1094, 'username_has_already_been_used', 'Username Has Already Been Used', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1095, 'certificate_name', 'Certificate Name', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1096, 'no_fees_have_been_allocated', 'No Fees Have Been Allocated', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1097, 'teachers_list', 'Teachers List', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1098, 'my_child', 'My Child', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1099, 'surname', 'Surname', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1100, 'rank', 'Rank', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1101, 'unpublished_on_website', 'Unpublished On Website', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1102, 'published_on_website', 'Published On Website', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1103, 'language_published', 'Language Published', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1104, 'select_for_everyone', 'Select For Everyone', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1105, 'parents_profile', 'Parents Profile', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1106, 'childs', 'Childs', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1107, 'fee_collection', 'Fee Collection', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1108, 'room_category', 'Room Category', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1109, 'hostels_room_edit', 'Hostels Room Edit', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1110, 'edit_room', 'Edit Room', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1111, 'student_promotion', 'Student Promotion', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1112, 'the_next_session_was_transferred_to_the_students', 'The Next Session Was Transferred To The Students', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1113, 'promote_to_session', 'Promote To Session', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1114, 'promote_to_class', 'Promote To Class', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1115, 'promote_to_section', 'Promote To Section', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1116, 'mark_summary', 'Mark Summary', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1117, 'layout_width', 'Layout Width', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1118, 'layout_height', 'Layout Height', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1119, 'width', 'Width', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1120, 'height', 'Height', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1121, 'expiry_date', 'Expiry Date', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1122, 'translation_update', 'Translation Update', '', NULL);


#
# TABLE STRUCTURE FOR: leave_application
#

DROP TABLE IF EXISTS `leave_application`;

CREATE TABLE `leave_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `category_id` int(2) NOT NULL,
  `reason` longtext CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `leave_days` varchar(20) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '1' COMMENT '1=pending,2=accepted 3=rejected',
  `apply_date` date DEFAULT NULL,
  `approved_by` int(11) NOT NULL,
  `orig_file_name` varchar(255) NOT NULL,
  `enc_file_name` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `session_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: leave_category
#

DROP TABLE IF EXISTS `leave_category`;

CREATE TABLE `leave_category` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `role_id` tinyint(1) NOT NULL,
  `days` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: live_class
#

DROP TABLE IF EXISTS `live_class`;

CREATE TABLE `live_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `meeting_id` varchar(255) NOT NULL,
  `meeting_password` varchar(255) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` varchar(11) NOT NULL,
  `remarks` text NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `live_class` (`id`, `title`, `meeting_id`, `meeting_password`, `class_id`, `section_id`, `remarks`, `date`, `start_time`, `end_time`, `created_by`, `created_at`, `branch_id`) VALUES (1, 'Live Class tester', '5501540696', 'booty', 1, '[\"1\"]', 'Revision', '2020-10-02', '13:30:00', '13:30:00', 1, '2020-09-29 13:34:23', 1);


#
# TABLE STRUCTURE FOR: live_class_config
#

DROP TABLE IF EXISTS `live_class_config`;

CREATE TABLE `live_class_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zoom_api_key` varchar(255) DEFAULT NULL,
  `zoom_api_secret` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `live_class_config` (`id`, `zoom_api_key`, `zoom_api_secret`, `branch_id`) VALUES (1, 'G-W8fkvLQpmFh0sETSEe2g', 'JC0wDJFlnKAcwx3o3kzB8bL5YyVwSGq6pSeP', 1);


#
# TABLE STRUCTURE FOR: login_credential
#

DROP TABLE IF EXISTS `login_credential`;

CREATE TABLE `login_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` tinyint(2) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1(active) 0(deactivate)',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (1, 1, 'babaahmedadnan@gmail.com', '$2y$10$E//IhTVVxR0nDINcsGqP3uO6a5zC7dRXkfn2iK2AUqeI7DK.GEhSu', 1, 1, '2020-10-06 10:38:15', '2020-07-15 13:44:05', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (2, 2, 'alfaky', '$2y$10$UJ68GGj9OOL2SLF.6/luF.u1SgUPKaLC1C0q4Pf7h0/dHRWhBlaku', 3, 1, '2020-09-26 10:31:32', '2020-07-15 15:44:50', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (3, 3, 'adnanu', '$2y$10$rfQQmJ/aHTP7pQT.HpLrDOg5fIA.Q0P22tl4Yjb0oeR4HIfED/Khm', 2, 1, '2020-07-16 15:02:02', '2020-07-16 11:40:31', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (4, 4, 'abba', '$2y$10$rUFwqfQ6LJm2uXZ0EGYnzuNmxYKl5B1XJTD5Q1nrMNSQ63eaSt4lG', 4, 1, '2020-09-29 14:21:13', '2020-07-16 15:10:10', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (5, 5, 'umar', '$2y$10$iGfb6R07ui34rn.vk/M5C..oFEY04UyKzb7nHOGnd0r/UNg3aO3RS', 5, 1, '2020-07-16 17:31:59', '2020-07-16 15:17:31', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (6, 1, 'abdul', '$2y$10$ujFcZf7JfcP9C3Tb4XmL9eYGeyFqG7IH27FN65fzP9ZsSW0t5g64C', 6, 1, '2020-09-15 14:17:05', '2020-07-16 16:00:26', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (7, 1, 'marsh', '$2y$10$4BCb4fE4WIAPvbO3oM3E..j3iEDr20zFmvm5KS1gwIFqhf2ZjnwZ6', 7, 1, '2020-07-16 16:01:49', '2020-07-16 16:00:26', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (8, 2, 'mbabdoul@gmail.com', '$2y$10$IqNaosXhfJb5uoAFHJyKKODEa3ZLgDyzWZSpmZTx6Pck0dpR09d2.', 7, 1, '2020-09-28 14:27:02', '2020-09-28 14:25:11', NULL);


#
# TABLE STRUCTURE FOR: mark
#

DROP TABLE IF EXISTS `mark`;

CREATE TABLE `mark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `mark` text,
  `absent` varchar(4) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: message
#

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `subject` varchar(255) NOT NULL,
  `file_name` text,
  `enc_name` text,
  `trash_sent` tinyint(1) NOT NULL,
  `trash_inbox` int(11) NOT NULL,
  `fav_inbox` tinyint(1) NOT NULL,
  `fav_sent` tinyint(1) NOT NULL,
  `reciever` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 unread 1 read',
  `reply_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 unread 1 read',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (1, '<p>Hello</p>', 'GSuite integration and main domain not responding', 'acce-logo.png', '461e4c607b649f0d58f00d4264aac78d.png', 0, 0, 0, 0, '3-2', '1-1', 1, 0, '2020-07-16 16:58:46', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (2, '<p>Hello Login</p>', 'Login Problems', NULL, NULL, 0, 0, 0, 0, '2-3', '7-2', 0, 0, '2020-09-28 14:28:22', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (3, '<p>Send users prices</p>', 'How much for the users?', NULL, NULL, 0, 0, 0, 1, '4-4', '1-1', 1, 0, '2020-09-29 14:20:25', NULL);


#
# TABLE STRUCTURE FOR: message_reply
#

DROP TABLE IF EXISTS `message_reply`;

CREATE TABLE `message_reply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `file_name` text NOT NULL,
  `enc_name` text NOT NULL,
  `identity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`version`) VALUES ('301');


#
# TABLE STRUCTURE FOR: online_admission
#

DROP TABLE IF EXISTS `online_admission`;

CREATE TABLE `online_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `birthday` date NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `guardian_name` varchar(255) NOT NULL,
  `guardian_relation` varchar(50) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `mother_name` varchar(255) NOT NULL,
  `grd_occupation` varchar(255) NOT NULL,
  `grd_income` varchar(25) NOT NULL,
  `grd_education` varchar(255) NOT NULL,
  `grd_email` varchar(255) NOT NULL,
  `grd_mobile_no` varchar(50) NOT NULL,
  `grd_address` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '1',
  `branch_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `apply_date` datetime NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: parent
#

DROP TABLE IF EXISTS `parent`;

CREATE TABLE `parent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `relation` varchar(255) NOT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `occupation` varchar(100) NOT NULL,
  `income` varchar(100) NOT NULL,
  `education` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) NOT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `active` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0(active) 1(deactivate)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `parent` (`id`, `name`, `relation`, `father_name`, `mother_name`, `occupation`, `income`, `education`, `email`, `mobileno`, `address`, `city`, `state`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`, `active`) VALUES (1, 'Abdulmalik Kyari', 'Father', '', '', 'Philanthropist', '', '', '', '8080832770', '', '', '', 1, 'defualt.png', NULL, NULL, NULL, '2020-07-16 16:00:26', NULL, 0);


#
# TABLE STRUCTURE FOR: payment_config
#

DROP TABLE IF EXISTS `payment_config`;

CREATE TABLE `payment_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paypal_username` varchar(255) DEFAULT NULL,
  `paypal_password` varchar(255) DEFAULT NULL,
  `paypal_signature` varchar(255) DEFAULT NULL,
  `paypal_email` varchar(255) DEFAULT NULL,
  `paypal_sandbox` tinyint(4) DEFAULT NULL,
  `paypal_status` tinyint(4) DEFAULT NULL,
  `stripe_secret` varchar(255) DEFAULT NULL,
  `stripe_demo` varchar(255) DEFAULT NULL,
  `stripe_status` tinyint(4) DEFAULT NULL,
  `payumoney_key` varchar(255) DEFAULT NULL,
  `payumoney_salt` varchar(255) DEFAULT NULL,
  `payumoney_demo` tinyint(4) DEFAULT NULL,
  `payumoney_status` tinyint(4) DEFAULT NULL,
  `paystack_secret_key` varchar(255) NOT NULL,
  `paystack_status` tinyint(4) NOT NULL,
  `razorpay_key_id` varchar(255) NOT NULL,
  `razorpay_key_secret` varchar(255) NOT NULL,
  `razorpay_demo` tinyint(4) NOT NULL,
  `razorpay_status` tinyint(4) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `payment_config` (`id`, `paypal_username`, `paypal_password`, `paypal_signature`, `paypal_email`, `paypal_sandbox`, `paypal_status`, `stripe_secret`, `stripe_demo`, `stripe_status`, `payumoney_key`, `payumoney_salt`, `payumoney_demo`, `payumoney_status`, `paystack_secret_key`, `paystack_status`, `razorpay_key_id`, `razorpay_key_secret`, `razorpay_demo`, `razorpay_status`, `branch_id`, `created_at`, `updated_at`) VALUES (1, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 2, NULL, NULL, NULL, 2, '', 1, '', '', 0, 2, 1, '2020-07-16 15:35:35', NULL);


#
# TABLE STRUCTURE FOR: payment_salary_stipend
#

DROP TABLE IF EXISTS `payment_salary_stipend`;

CREATE TABLE `payment_salary_stipend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: payment_types
#

DROP TABLE IF EXISTS `payment_types`;

CREATE TABLE `payment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (1, 'Cash', 0, '2019-07-27 18:12:21');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (2, 'Card', 0, '2019-07-27 18:12:31');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (3, 'Cheque', 0, '2019-12-21 10:07:59');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (4, 'Bank Transfer', 0, '2019-12-21 10:08:36');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (5, 'Other', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (6, 'Paypal', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (7, 'Stripe', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (8, 'PayUmoney', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (9, 'Paystack', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (10, 'Razorpay', 0, '2019-12-21 10:08:45');


#
# TABLE STRUCTURE FOR: payslip
#

DROP TABLE IF EXISTS `payslip`;

CREATE TABLE `payslip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `month` varchar(200) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL,
  `total_allowance` decimal(18,2) NOT NULL,
  `total_deduction` decimal(18,2) NOT NULL,
  `net_salary` decimal(18,2) NOT NULL,
  `bill_no` varchar(25) NOT NULL,
  `remarks` text NOT NULL,
  `pay_via` tinyint(1) NOT NULL,
  `hash` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paid_by` varchar(200) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: payslip_details
#

DROP TABLE IF EXISTS `payslip_details`;

CREATE TABLE `payslip_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: permission
#

DROP TABLE IF EXISTS `permission`;

CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prefix` varchar(100) NOT NULL,
  `show_view` tinyint(1) DEFAULT '1',
  `show_add` tinyint(1) DEFAULT '1',
  `show_edit` tinyint(1) DEFAULT '1',
  `show_delete` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;

INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (1, 2, 'Student', 'student', 1, 1, 1, 1, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (2, 2, 'Multiple Import', 'multiple_import', 0, 1, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (3, 2, 'Student Category', 'student_category', 1, 1, 1, 1, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (4, 2, 'Student Id Card', 'student_id_card', 1, 0, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (5, 2, 'Disable Authentication', 'student_disable_authentication', 1, 1, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (6, 4, 'Employee', 'employee', 1, 1, 1, 1, '2020-01-22 12:55:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (7, 3, 'Parent', 'parent', 1, 1, 1, 1, '2020-01-22 14:24:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (8, 3, 'Disable Authentication', 'parent_disable_authentication', 1, 1, 0, 0, '2020-01-22 15:22:21');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (9, 4, 'Department', 'department', 1, 1, 1, 1, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (10, 4, 'Designation', 'designation', 1, 1, 1, 1, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (11, 4, 'Disable Authentication', 'employee_disable_authentication', 1, 1, 0, 0, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (12, 5, 'Salary Template', 'salary_template', 1, 1, 1, 1, '2020-01-23 06:13:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (13, 5, 'Salary Assign', 'salary_assign', 1, 1, 0, 0, '2020-01-23 06:14:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (14, 5, 'Salary Payment', 'salary_payment', 1, 1, 0, 0, '2020-01-24 07:45:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (15, 5, 'Salary Summary Report', 'salary_summary_report', 1, 0, 0, 0, '2020-03-14 18:09:17');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (16, 5, 'Advance Salary', 'advance_salary', 1, 1, 1, 1, '2020-01-28 19:23:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (17, 5, 'Advance Salary Manage', 'advance_salary_manage', 1, 1, 1, 1, '2020-01-25 05:57:12');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (18, 5, 'Advance Salary Request', 'advance_salary_request', 1, 1, 0, 1, '2020-01-28 18:49:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (19, 5, 'Leave Category', 'leave_category', 1, 1, 1, 1, '2020-01-29 03:46:23');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (20, 5, 'Leave Request', 'leave_request', 1, 1, 1, 1, '2020-01-30 13:06:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (21, 5, 'Leave Manage', 'leave_manage', 1, 1, 1, 1, '2020-01-29 08:27:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (22, 5, 'Award', 'award', 1, 1, 1, 1, '2020-01-31 19:49:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (23, 6, 'Classes', 'classes', 1, 1, 1, 1, '2020-02-01 19:10:00');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (24, 6, 'Section', 'section', 1, 1, 1, 1, '2020-02-01 22:06:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (25, 6, 'Assign Class Teacher', 'assign_class_teacher', 1, 1, 1, 1, '2020-02-02 08:09:22');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (26, 6, 'Subject', 'subject', 1, 1, 1, 1, '2020-02-03 05:32:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (27, 6, 'Subject Class Assign ', 'subject_class_assign', 1, 1, 1, 1, '2020-02-03 18:43:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (28, 6, 'Subject Teacher Assign', 'subject_teacher_assign', 1, 1, 0, 1, '2020-02-03 20:05:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (29, 6, 'Class Timetable', 'class_timetable', 1, 1, 1, 1, '2020-02-04 06:50:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (30, 2, 'Student Promotion', 'student_promotion', 1, 1, 0, 0, '2020-02-05 19:20:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (31, 8, 'Attachments', 'attachments', 1, 1, 1, 1, '2020-02-06 18:59:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (32, 7, 'Homework', 'homework', 1, 1, 1, 1, '2020-02-07 06:40:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (33, 8, 'Attachment Type', 'attachment_type', 1, 1, 1, 1, '2020-02-07 08:16:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (34, 9, 'Exam', 'exam', 1, 1, 1, 1, '2020-02-07 10:59:29');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (35, 9, 'Exam Term', 'exam_term', 1, 1, 1, 1, '2020-02-07 13:09:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (36, 9, 'Exam Hall', 'exam_hall', 1, 1, 1, 1, '2020-02-07 15:31:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (37, 9, 'Exam Timetable', 'exam_timetable', 1, 1, 0, 1, '2020-02-08 18:04:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (38, 9, 'Exam Mark', 'exam_mark', 1, 1, 1, 1, '2020-02-10 13:53:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (39, 9, 'Exam Grade', 'exam_grade', 1, 1, 1, 1, '2020-02-10 18:29:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (40, 10, 'Hostel', 'hostel', 1, 1, 1, 1, '2020-02-11 05:41:36');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (41, 10, 'Hostel Category', 'hostel_category', 1, 1, 1, 1, '2020-02-11 08:52:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (42, 10, 'Hostel Room', 'hostel_room', 1, 1, 1, 1, '2020-02-11 12:50:09');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (43, 10, 'Hostel Allocation', 'hostel_allocation', 1, 0, 0, 1, '2020-02-11 14:06:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (44, 11, 'Transport Route', 'transport_route', 1, 1, 1, 1, '2020-02-12 06:26:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (45, 11, 'Transport Vehicle', 'transport_vehicle', 1, 1, 1, 1, '2020-02-12 06:57:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (46, 11, 'Transport Stoppage', 'transport_stoppage', 1, 1, 1, 1, '2020-02-12 07:49:20');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (47, 11, 'Transport Assign', 'transport_assign', 1, 1, 1, 1, '2020-02-12 10:55:21');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (48, 11, 'Transport Allocation', 'transport_allocation', 1, 0, 0, 1, '2020-02-12 20:33:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (49, 12, 'Student Attendance', 'student_attendance', 0, 1, 0, 0, '2020-02-13 06:25:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (50, 12, 'Employee Attendance', 'employee_attendance', 0, 1, 0, 0, '2020-02-13 11:04:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (51, 12, 'Exam Attendance', 'exam_attendance', 0, 1, 0, 0, '2020-02-13 12:08:14');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (52, 12, 'Student Attendance Report', 'student_attendance_report', 1, 0, 0, 0, '2020-02-13 20:20:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (53, 12, 'Employee Attendance Report', 'employee_attendance_report', 1, 0, 0, 0, '2020-02-14 07:08:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (54, 12, 'Exam Attendance Report', 'exam_attendance_report', 1, 0, 0, 0, '2020-02-14 07:21:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (55, 13, 'Book', 'book', 1, 1, 1, 1, '2020-02-14 07:40:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (56, 13, 'Book Category', 'book_category', 1, 1, 1, 1, '2020-02-15 05:11:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (57, 13, 'Book Manage', 'book_manage', 1, 1, 0, 1, '2020-02-15 12:13:24');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (58, 13, 'Book Request', 'book_request', 1, 1, 0, 1, '2020-02-17 07:45:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (59, 14, 'Event', 'event', 1, 1, 1, 1, '2020-02-17 19:02:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (60, 14, 'Event Type', 'event_type', 1, 1, 1, 1, '2020-02-18 05:40:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (61, 15, 'Sendsmsmail', 'sendsmsmail', 1, 1, 0, 1, '2020-02-22 08:19:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (62, 15, 'Sendsmsmail Template', 'sendsmsmail_template', 1, 1, 1, 1, '2020-02-22 11:14:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (63, 17, 'Account', 'account', 1, 1, 1, 1, '2020-02-25 10:34:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (64, 17, 'Deposit', 'deposit', 1, 1, 1, 1, '2020-02-25 13:56:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (65, 17, 'Expense', 'expense', 1, 1, 1, 1, '2020-02-26 07:35:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (66, 17, 'All Transactions', 'all_transactions', 1, 0, 0, 0, '2020-02-26 14:35:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (67, 17, 'Voucher Head', 'voucher_head', 1, 1, 1, 1, '2020-02-25 11:50:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (68, 17, 'Accounting Reports', 'accounting_reports', 1, 1, 1, 1, '2020-02-25 14:36:24');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (69, 16, 'Fees Type', 'fees_type', 1, 1, 1, 1, '2020-02-27 11:11:03');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (70, 16, 'Fees Group', 'fees_group', 1, 1, 1, 1, '2020-02-26 06:49:09');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (71, 16, 'Fees Fine Setup', 'fees_fine_setup', 1, 1, 1, 1, '2020-03-05 03:59:27');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (72, 16, 'Fees Allocation', 'fees_allocation', 1, 1, 1, 1, '2020-03-01 14:47:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (73, 16, 'Collect Fees', 'collect_fees', 0, 1, 0, 0, '2020-03-15 05:23:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (74, 16, 'Fees Reminder', 'fees_reminder', 1, 1, 1, 1, '2020-03-15 05:29:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (75, 16, 'Due Invoice', 'due_invoice', 1, 0, 0, 0, '2020-03-15 05:33:36');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (76, 16, 'Invoice', 'invoice', 1, 0, 0, 1, '2020-03-15 05:38:06');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (77, 9, 'Mark Distribution', 'mark_distribution', 1, 1, 1, 1, '2020-03-19 14:02:54');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (78, 9, 'Report Card', 'report_card', 1, 0, 0, 0, '2020-03-20 13:20:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (79, 9, 'Tabulation Sheet', 'tabulation_sheet', 1, 0, 0, 0, '2020-03-21 08:12:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (80, 15, 'Sendsmsmail Reports', 'sendsmsmail_reports', 1, 0, 0, 0, '2020-03-21 18:02:02');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (81, 18, 'Global Settings', 'global_settings', 1, 0, 1, 0, '2020-03-22 06:05:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (82, 18, 'Payment Settings', 'payment_settings', 1, 1, 0, 0, '2020-03-22 06:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (83, 18, 'Sms Settings', 'sms_settings', 1, 1, 1, 1, '2020-03-22 06:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (84, 18, 'Email Settings', 'email_settings', 1, 1, 1, 1, '2020-03-22 06:10:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (85, 18, 'Translations', 'translations', 1, 1, 1, 1, '2020-03-22 06:18:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (86, 18, 'Backup', 'backup', 1, 1, 1, 1, '2020-03-22 08:09:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (87, 18, 'Backup Restore', 'backup_restore', 0, 1, 0, 0, '2020-03-22 08:09:34');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (88, 7, 'Homework Evaluate', 'homework_evaluate', 1, 1, 0, 0, '2020-03-28 05:20:29');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (89, 7, 'Evaluation Report', 'evaluation_report', 1, 0, 0, 0, '2020-03-28 10:56:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (90, 18, 'School Settings', 'school_settings', 1, 0, 1, 0, '2020-03-30 18:36:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (91, 1, 'Monthly Income Vs Expense Pie Chart', 'monthly_income_vs_expense_chart', 1, 0, 0, 0, '2020-03-31 07:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (92, 1, 'Annual Student Fees Summary Chart', 'annual_student_fees_summary_chart', 1, 0, 0, 0, '2020-03-31 07:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (93, 1, 'Employee Count Widget', 'employee_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (94, 1, 'Student Count Widget', 'student_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (95, 1, 'Parent Count Widget', 'parent_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (96, 1, 'Teacher Count Widget', 'teacher_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (97, 1, 'Student Quantity Pie Chart', 'student_quantity_pie_chart', 1, 0, 0, 0, '2020-03-31 08:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (98, 1, 'Weekend Attendance Inspection Chart', 'weekend_attendance_inspection_chart', 1, 0, 0, 0, '2020-03-31 08:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (99, 1, 'Admission Count Widget', 'admission_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (100, 1, 'Voucher Count Widget', 'voucher_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (101, 1, 'Transport Count Widget', 'transport_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (102, 1, 'Hostel Count Widget', 'hostel_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (103, 18, 'Accounting Links', 'accounting_links', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (104, 16, 'Fees Reports', 'fees_reports', 1, 0, 0, 0, '2020-04-01 16:52:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (105, 18, 'Cron Job', 'cron_job', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (106, 18, 'Custom Field', 'custom_field', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (107, 5, 'Leave Reports', 'leave_reports', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (108, 18, 'Live Class Config', 'live_class_config', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (109, 19, 'Live Class', 'live_class', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (110, 20, 'Certificate Templete', 'certificate_templete', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (111, 20, 'Generate Student Certificate', 'generate_student_certificate', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (112, 20, 'Generate Employee Certificate', 'generate_employee_certificate', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (113, 21, 'ID Card Templete', 'id_card_templete', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (114, 21, 'Generate Student ID Card', 'generate_student_idcard', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (115, 21, 'Generate Employee ID Card', 'generate_employee_idcard', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (116, 21, 'Admit Card Templete', 'admit_card_templete', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (117, 21, 'Generate Admit card', 'generate_admit_card', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (118, 22, 'Frontend Setting', 'frontend_setting', 1, 1, 0, 0, '2019-09-11 04:24:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (119, 22, 'Frontend Menu', 'frontend_menu', 1, 1, 1, 1, '2019-09-11 05:03:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (120, 22, 'Frontend Section', 'frontend_section', 1, 1, 0, 0, '2019-09-11 05:26:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (121, 22, 'Manage Page', 'manage_page', 1, 1, 1, 1, '2019-09-11 06:54:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (122, 22, 'Frontend Slider', 'frontend_slider', 1, 1, 1, 1, '2019-09-11 07:12:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (123, 22, 'Frontend Features', 'frontend_features', 1, 1, 1, 1, '2019-09-11 07:47:51');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (124, 22, 'Frontend Testimonial', 'frontend_testimonial', 1, 1, 1, 1, '2019-09-11 07:54:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (125, 22, 'Frontend Services', 'frontend_services', 1, 1, 1, 1, '2019-09-11 08:01:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (126, 22, 'Frontend Faq', 'frontend_faq', 1, 1, 1, 1, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (127, 2, 'Online Admission', 'online_admission', 1, 1, 0, 1, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (128, 18, 'System Update', 'system_update', 0, 1, 0, 0, '2019-09-11 08:06:16');


#
# TABLE STRUCTURE FOR: permission_modules
#

DROP TABLE IF EXISTS `permission_modules`;

CREATE TABLE `permission_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) NOT NULL,
  `system` tinyint(1) NOT NULL,
  `sorted` tinyint(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (1, 'Dashboard', 'dashboard', 1, 1, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (2, 'Student', 'student', 1, 3, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (3, 'Parents', 'parents', 1, 4, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (4, 'Employee', 'employee', 1, 5, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (5, 'Human Resource', 'human_resource', 1, 8, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (6, 'Academic', 'academic', 1, 9, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (7, 'Homework', 'homework', 1, 12, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (8, 'Attachments Book', 'attachments_book', 1, 11, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (9, 'Exam Master', 'exam_master', 1, 13, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (10, 'Hostel', 'hostel', 1, 14, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (11, 'Transport', 'transport', 1, 15, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (12, 'Attendance', 'attendance', 1, 16, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (13, 'Library', 'library', 1, 17, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (14, 'Events', 'events', 1, 18, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (15, 'Bulk Sms And Email', 'bulk_sms_and_email', 1, 19, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (16, 'Student Accounting', 'student_accounting', 1, 20, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (17, 'Office Accounting', 'office_accounting', 1, 21, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (18, 'Settings', 'settings', 1, 22, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (19, 'Live Class', 'live_class', 1, 10, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (20, 'Certificate', 'certificate', 1, 7, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (21, 'Card Management', 'card_management', 1, 6, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (22, 'Website', 'website', 1, 2, '2019-05-26 23:23:00');


#
# TABLE STRUCTURE FOR: reset_password
#

DROP TABLE IF EXISTS `reset_password`;

CREATE TABLE `reset_password` (
  `key` longtext NOT NULL,
  `username` varchar(100) NOT NULL,
  `login_credential_id` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `reset_password` (`key`, `username`, `login_credential_id`, `created_at`) VALUES ('22521db32fdeec373c138ff50125cf2927c78ea17972c73bfcd57b2a0aebb27e6e4e7ee63e441929dc4f9ed7a6e7ad65e487e3aa6c1e2fa764372ff3231359e4', 'alfaky', '2', '2020-07-15 16:11:15');


#
# TABLE STRUCTURE FOR: rm_sessions
#

DROP TABLE IF EXISTS `rm_sessions`;

CREATE TABLE `rm_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0fvsq90cd5ji9cnliidigmg38md0dh28', '41.190.14.129', 1594894494, '__ci_last_regenerate|i:1594894494;redirect_url|s:57:\"https://www.admin.acce-abuja.com.ng/portal/classes/edit/3\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0n975k6bsf3ssfiqhj1n19vp07gb9jrr', '41.73.1.76', 1596036526, '__ci_last_regenerate|i:1596036504;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0o95a6gmkov8grqo124i7tg1prieuk5j', '41.190.12.66', 1595375959, '__ci_last_regenerate|i:1595375690;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0rtdson5qj2f83ajpq2g7sgkj9jgbl92', '41.190.12.66', 1595376793, '__ci_last_regenerate|i:1595376517;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0s5m1libed683jk54g2djoses3uursec', '41.190.12.93', 1594824629, '__ci_last_regenerate|i:1594824498;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10bajr6dqadljk2bamlfj2hau4187s2p', '41.73.1.75', 1601977946, '__ci_last_regenerate|i:1601977718;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('16ecd476q54tgfrq87e16e172gh2d63e', '41.73.1.71', 1601372270, '__ci_last_regenerate|i:1601372161;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1a2tfbi6ll6p7k78fmd6sp3lqu16c82l', '41.73.1.71', 1601386064, '__ci_last_regenerate|i:1601386018;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b2kdoj5reamva3q1ojrg2baei56q4jd', '41.73.1.71', 1601385063, '__ci_last_regenerate|i:1601384811;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1u690se00snbektr447jehb6u4gil4s3', '41.73.1.71', 1601373304, '__ci_last_regenerate|i:1601373121;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('205d61jdssosms1pll9rj2emt17tq144', '41.73.1.68', 1594915449, '__ci_last_regenerate|i:1594915174;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23ssbrs4usc86uk55ro8hpfsrq1r6l9i', '41.73.1.75', 1595860099, '__ci_last_regenerate|i:1595860098;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23vlq02fea65qp6r3dtd8agi83lhb119', '41.73.1.76', 1596032806, '__ci_last_regenerate|i:1596032804;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('24vbrd4ilpt2c8vseegd8n4dgr5pobj2', '41.73.1.75', 1595427260, '__ci_last_regenerate|i:1595427248;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('29lv96g2skd1g5k6bngvo0srfad5sud3', '41.73.1.75', 1601893808, '__ci_last_regenerate|i:1601893678;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2do0km16derf57qp3sqrje2gr8vcek48', '197.210.53.36', 1595514892, '__ci_last_regenerate|i:1595514826;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2njtkpr1a2l05gnh8m69hbn6lu2i0r7j', '41.73.1.75', 1601126606, '__ci_last_regenerate|i:1601126485;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2sij9mafsc1qqbk8ieo2f4oftfi70e7o', '41.190.12.220', 1594817530, '__ci_last_regenerate|i:1594817317;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2vqhrm515eik6gatct665eq001rev86n', '41.73.1.75', 1601978891, '__ci_last_regenerate|i:1601978119;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30b8pgnn9r9j5ep7l0udpvhdp35rkiff', '105.112.117.208', 1601298523, '__ci_last_regenerate|i:1601298510;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32c52itqlbjvnpusfcdcugb6tins819g', '193.51.224.134', 1601369898, '__ci_last_regenerate|i:1601369896;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32nmr7u3pt20tp7o10752rpfc4pk0j6l', '41.190.12.93', 1594825865, '__ci_last_regenerate|i:1594825565;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('35u2mrorjc15keqige882d4g755vkple', '41.73.1.75', 1601895878, '__ci_last_regenerate|i:1601895856;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39o8jnc234kh23176oh9i117gej5oq9c', '41.190.14.104', 1600238731, '__ci_last_regenerate|i:1600238730;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3gbv9b3g2rsdjki8s8q81qph2uh6786s', '105.112.114.93', 1600180768, '__ci_last_regenerate|i:1600180767;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3i6rnj6o12pa7mjtul704spgt3dt38qj', '41.190.14.7', 1599411146, '__ci_last_regenerate|i:1599410982;redirect_url|s:50:\"http://admin.acce-abuja.com.ng/portal/parents/view\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('40hlsj11uj18tj3egpf32pi8c9os73q3', '41.190.14.129', 1594896561, '__ci_last_regenerate|i:1594896472;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4567nlh7ripj443tfhgt4dcue7lt1c18', '41.73.1.76', 1596032663, '__ci_last_regenerate|i:1596032476;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46c6n17gusmn0oqt3a5npk17ap0refhf', '41.190.12.33', 1596227917, '__ci_last_regenerate|i:1596227916;redirect_url|s:59:\"https://www.admin.acce-abuja.com.ng/portal/student/category\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c9dlrucqtdql28jcolgo7req63e61u6', '154.73.81.5', 1600286479, '__ci_last_regenerate|i:1600286479;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ngi1kalah53mpk5obk518d2qgobh9ch', '41.190.14.129', 1594895053, '__ci_last_regenerate|i:1594895048;redirect_url|s:48:\"http://admin.acce-abuja.com.ng/portal/live_class\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('55vigdthl6jo6k62d4cpc4gs21m1vbq7', '41.73.1.75', 1595863217, '__ci_last_regenerate|i:1595862908;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57ha4vf7nv2908cmorrf9ej03dat5i4m', '41.190.12.220', 1594819659, '__ci_last_regenerate|i:1594819657;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5aisfpphnhm52b428abqr44c4c7ogunv', '202.208.170.70', 1595853839, '__ci_last_regenerate|i:1595853837;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5gfqh84p0qhuavf8ou7mbjnsp0nqd5ck', '41.190.12.93', 1594825398, '__ci_last_regenerate|i:1594825188;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5mpte36e9tnn30u0kvm1j9g069v52kgc', '41.73.1.76', 1596033452, '__ci_last_regenerate|i:1596033162;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5sgkpmug2u85h3g5onsh2lf4hu6bt5ip', '41.73.1.75', 1595853755, '__ci_last_regenerate|i:1595853735;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5te1ncs73vicr9nefjmjc5lsblqg59qg', '41.190.12.66', 1595377381, '__ci_last_regenerate|i:1595377380;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64mihken5bf2a0cr2es73ot9b9hs9jt0', '41.73.1.75', 1601895855, '__ci_last_regenerate|i:1601895855;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('65ko1qgbdrcufkmu5c1or623mg7o1nqh', '41.73.1.68', 1594910790, '__ci_last_regenerate|i:1594910641;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6h62q39qksgbu8cp6hcaoqq8r2lv4te5', '41.73.1.71', 1601385551, '__ci_last_regenerate|i:1601385225;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6h7n75k9s1b5cbpq315n28s7f4trrfb6', '41.190.12.66', 1595377973, '__ci_last_regenerate|i:1595377972;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6h9tpo2hsccs28cr0iineq23pb8n6f5i', '41.190.14.26', 1595074100, '__ci_last_regenerate|i:1595073762;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6sipblds38blea459r69q261vfum0j15', '41.73.1.71', 1601379641, '__ci_last_regenerate|i:1601378455;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6ufq3hus02410ed0gk1ak9ctjbbkcbg6', '41.73.1.68', 1601468219, '__ci_last_regenerate|i:1601467919;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('774o2hltfgbsa0rnugbb8tr1osi4k5e9', '105.112.114.38', 1600175477, '__ci_last_regenerate|i:1600175348;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('78d6r6fpd9j5f2l0nsqj3v6245ke6dc5', '105.112.114.180', 1598558760, '__ci_last_regenerate|i:1598558703;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/event/types\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7kcac70ua07crv4nphng1p1o1kmert9h', '195.121.71.71', 1595853836, '__ci_last_regenerate|i:1595853836;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7klup6b9405o0ssj966r2kgl4mcbkl5f', '41.73.1.68', 1594907409, '__ci_last_regenerate|i:1594907219;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7lmhov3m1jdbcsdbug0mul5ek4gka3qh', '41.73.1.76', 1596036127, '__ci_last_regenerate|i:1596036127;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7oqncihrcigqpsk075j1t8gv69o89au9', '41.190.14.129', 1594895798, '__ci_last_regenerate|i:1594895497;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7pi4h7314d5minfoa8q1cpfcprs5p389', '41.190.12.106', 1597058310, '__ci_last_regenerate|i:1597058274;redirect_url|s:70:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7rneicsiga8b3ipiic69q5l9i1f4hsv2', '41.190.12.93', 1594823771, '__ci_last_regenerate|i:1594823469;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8097ar4pertn021i2sbae6pd5qqok9gk', '41.73.1.68', 1594913886, '__ci_last_regenerate|i:1594913700;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80g7pvc4k9v4itq05mgc0k6h3deiltio', '41.190.14.70', 1594931998, '__ci_last_regenerate|i:1594931998;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81b625g6hk8qa0nhqb3fhiod9hnogge9', '95.159.73.132', 1601369931, '__ci_last_regenerate|i:1601369919;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81ju5rdt5h77s9tctrvs2mld827r9qee', '41.73.1.68', 1594914269, '__ci_last_regenerate|i:1594914269;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88au573oq5hr5bc2qj4q88as5ieuj3dp', '41.73.1.76', 1596036137, '__ci_last_regenerate|i:1596036127;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8el1ds7a55s9q9392aki7e23lc251bbm', '41.73.1.71', 1601377622, '__ci_last_regenerate|i:1601377617;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8gh5ob0gu4j94rm4pbecqgq6kbj8ltij', '105.112.117.197', 1601289549, '__ci_last_regenerate|i:1601289397;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8lqlq820plo29hb1f3b315asri93a373', '41.73.1.68', 1594905314, '__ci_last_regenerate|i:1594905214;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8n7oahds2at04vjon0i278gunims9t9f', '41.73.1.75', 1595425258, '__ci_last_regenerate|i:1595425023;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8u3s8puv87f7im9o2tnn200r5h7jlju5', '41.73.1.72', 1601111886, '__ci_last_regenerate|i:1601111882;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90imqtro7dj2fs502plq1ngnbjn8sqqo', '41.190.12.230', 1599058733, '__ci_last_regenerate|i:1599058524;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93s2hnkghe2prcmd35ii2295nmo980lg', '41.73.1.68', 1594908715, '__ci_last_regenerate|i:1594908452;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('94fn7prquqniajcgf57vlkla1bhp4pni', '41.73.1.68', 1601469772, '__ci_last_regenerate|i:1601469686;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('98lhabidqqu8ptft5mrmi9inpaupg1n1', '41.73.1.75', 1595427905, '__ci_last_regenerate|i:1595427744;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bfd6hn0aqj7png83lo4jq2tst47dq0i', '105.112.117.197', 1601289198, '__ci_last_regenerate|i:1601289076;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9cmaukigm4vmnomckeasa01c4qh7mp4j', '41.190.14.129', 1594844896, '__ci_last_regenerate|i:1594844895;redirect_url|s:53:\"http://admin.acce-abuja.com.ng/portal/employee/view/3\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9fo7rd2ge53f5mudnvlcig50h4avp3ll', '41.73.1.75', 1595856007, '__ci_last_regenerate|i:1595856005;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9po8o9g3p0h6mf0j166r09lj10u4psuv', '41.73.1.68', 1594916944, '__ci_last_regenerate|i:1594916944;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9qe0j49802jta6cnq9v0rsti99lrvnte', '41.73.1.71', 1601372360, '__ci_last_regenerate|i:1601369634;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9qmmkklbvurqlohq2j7p4k3p64klsj1b', '41.190.12.220', 1594818875, '__ci_last_regenerate|i:1594818841;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9rbas17s7ssq4f17s6k9331394pu6ono', '41.73.1.72', 1601112758, '__ci_last_regenerate|i:1601112757;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9sd00s5i1comlai7im4p821ad6icsnbt', '41.73.1.68', 1594915653, '__ci_last_regenerate|i:1594915567;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0ql3rii7rrm63aq36m1sr4aaqonvvvu', '129.56.31.36', 1601596054, '__ci_last_regenerate|i:1601596022;redirect_url|s:45:\"http://admin.acce-abuja.com.ng/portal/payroll\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a26g05u8cr50d47863tncm5os099o548', '41.73.1.75', 1601894215, '__ci_last_regenerate|i:1601894214;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a28uk38stb3umjbpp232dpbjlqohagtt', '41.73.1.75', 1595856005, '__ci_last_regenerate|i:1595855634;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a5m9cfbqmkhfia1tk2p9avnb2joaak4f', '41.73.1.75', 1595427058, '__ci_last_regenerate|i:1595426914;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aairlsgheb7mobio83vte9g8jlomb2ga', '41.190.12.66', 1595374987, '__ci_last_regenerate|i:1595374738;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ab2rmne247jttnhp65ohr67h0qen8u0b', '41.73.1.75', 1595854550, '__ci_last_regenerate|i:1595854550;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('adu03775luo60vm2j97gtpbuck9epclu', '41.73.1.71', 1601379938, '__ci_last_regenerate|i:1601379641;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('afon6jnvui7fpna5lshhg3macva0d918', '41.73.1.68', 1594908347, '__ci_last_regenerate|i:1594908113;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ao9upef8s8fb019ffl8ckhsrvnscv40s', '105.112.114.38', 1600176011, '__ci_last_regenerate|i:1600175804;name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"1\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('asbfq5fa5ju1d0ro05prnhpoknf0dbah', '41.73.1.75', 1601114858, '__ci_last_regenerate|i:1601114597;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('av3dm6ha1l1dahbes5591lmc4on62iga', '41.190.12.222', 1600282938, '__ci_last_regenerate|i:1600282938;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('avbu41dq9i8g8h727kvsquce6ootoi1d', '41.73.1.75', 1595424832, '__ci_last_regenerate|i:1595424555;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b79ml7mg80o0jbglgaonprculf2u9kvi', '154.120.125.216', 1601452325, '__ci_last_regenerate|i:1601452325;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b8flh8dinssvdooc656gbnk2i597eb6l', '197.242.124.130', 1594855582, '__ci_last_regenerate|i:1594855582;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b91bu9hgf8ir4hv50am7fval10gi9ija', '41.190.12.66', 1595374691, '__ci_last_regenerate|i:1595374405;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba9d5vu3sh4q6lhi41brmmn5pudqc8q8', '41.73.1.76', 1599140274, '__ci_last_regenerate|i:1599140048;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bg0j8h70tqqcnn5d75m75ci6npkdlhjg', '41.73.1.75', 1601893317, '__ci_last_regenerate|i:1601892282;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bh3362nbctv3brgier46bfv261496fnt', '41.190.14.26', 1595074177, '__ci_last_regenerate|i:1595074101;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bp9lb5fqh8lvv107uqvsjckon2huhtp0', '41.73.1.75', 1595857512, '__ci_last_regenerate|i:1595857510;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bsr3gq9b36ks2spdgn359khiuhpitric', '197.149.127.197', 1601596027, '__ci_last_regenerate|i:1601596027;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c3gb3nqs3sqi7n84j6tseuvm8ggc31pp', '41.190.14.72', 1597054903, '__ci_last_regenerate|i:1597054839;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cda7irjeb47m36lml9qfr3av5fqvu6el', '41.190.14.129', 1594896103, '__ci_last_regenerate|i:1594896061;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cesc50lomep2bk9pd1ovpitmp7i439p2', '41.73.1.75', 1597492052, '__ci_last_regenerate|i:1597492051;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d66hqk9lb3e5f95lld2ae7k0s55kl005', '41.73.1.68', 1594906106, '__ci_last_regenerate|i:1594906104;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da7ortobc26l4k2sv7cu3htmu6srfaoj', '41.73.1.68', 1594914880, '__ci_last_regenerate|i:1594914613;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('daef39h2ehme5hoc2pv70gqa42nn1uit', '154.120.125.216', 1601452332, '__ci_last_regenerate|i:1601452325;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dbdmbs7mgbbmq673orfc1arscvltlg88', '41.73.1.76', 1596035419, '__ci_last_regenerate|i:1596035162;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dkcbam9ba5c1tbaahl4e24nai9aevsgo', '41.190.12.220', 1594819660, '__ci_last_regenerate|i:1594819658;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dm2meankpcbm36r9ut6nnv0q94ltfpff', '41.73.1.75', 1595863426, '__ci_last_regenerate|i:1595863221;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dpdvvc2765dgefi56fms3t8kl1b39u4h', '41.73.1.75', 1595426740, '__ci_last_regenerate|i:1595426567;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dquchmh9hm4r1bi12dhcf797gd2hjmc9', '105.112.114.38', 1600177331, '__ci_last_regenerate|i:1600177107;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('drfa879lnhnmi3stn66nnimp99gphrat', '41.73.1.71', 1601381079, '__ci_last_regenerate|i:1601380905;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dvf318njjontksi2c70l6pjrlgaqifth', '41.73.1.75', 1601891907, '__ci_last_regenerate|i:1601891190;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e21clg9tit1n4bu4j17hersm1n17r9li', '105.112.113.10', 1600779170, '__ci_last_regenerate|i:1600779146;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e2svsbv8060ncn3a4unranehuho9m1pv', '41.73.1.71', 1601375694, '__ci_last_regenerate|i:1601375694;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e69e7ab6mg3a4fgi67hol97c0hk8l7jh', '41.73.1.75', 1601124360, '__ci_last_regenerate|i:1601124285;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebkc17ubd7athq7mef1c6ie2h5df0oth', '41.73.1.71', 1601378454, '__ci_last_regenerate|i:1601378453;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebmj4e3275tmh6vrvcg60dvlfll7p0kj', '192.99.100.98', 1595514591, '__ci_last_regenerate|i:1595514590;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ec3tvseo8tpojbmj1ip09ji1qlcnbl6c', '41.190.12.86', 1599070531, '__ci_last_regenerate|i:1599070472;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/event/types\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('egn3nn1vogbu32k5gk0eqhlfre9i42q3', '41.73.1.68', 1594913262, '__ci_last_regenerate|i:1594913196;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eh1u28odmnn53rs7k2emmdg6p4ra19fu', '41.190.12.220', 1594818042, '__ci_last_regenerate|i:1594817749;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eq9p03hp98qaof3v1q1hcmv23jgm2gs2', '37.170.83.176', 1597171097, '__ci_last_regenerate|i:1597171097;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eqgh1e4sangs9i4nor2dd5mr9ats709a', '41.190.12.66', 1595375689, '__ci_last_regenerate|i:1595375389;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f85fq2lmbhovol9fnvuga1tl8pd1on6r', '105.112.116.25', 1600270538, '__ci_last_regenerate|i:1600270376;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fb35972nh9jtd1a3629lnqhfqkv2uuj1', '41.190.14.129', 1594894494, '__ci_last_regenerate|i:1594894494;redirect_url|s:58:\"https://www.admin.acce-abuja.com.ng/portal/dashboard/index\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbh2ddrqgh58id5usr3avd6mlhak0a84', '94.20.252.68', 1601369917, '__ci_last_regenerate|i:1601369900;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fk5s4g76rvq4iu8vhhupi77caatc8pfj', '41.73.1.71', 1601385906, '__ci_last_regenerate|i:1601385651;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fr2filfaqjaf06fblhjj6fn4b9ncu2ua', '41.190.14.129', 1594897481, '__ci_last_regenerate|i:1594897479;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('frms6t4foud4erru365m9t2mk5jbc7pp', '41.190.14.178', 1597163820, '__ci_last_regenerate|i:1597163819;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fsq6jh8khttep8baj4ctifmuv1nqhjk0', '105.112.117.208', 1601299748, '__ci_last_regenerate|i:1601299719;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g6ji0psrbftrpqgvsvbhi2mlll7mqj2v', '41.73.1.71', 1601384797, '__ci_last_regenerate|i:1601382863;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gfl2h9ffivn2if5e5n2mo5j47utg26l4', '41.73.1.71', 1601378455, '__ci_last_regenerate|i:1601378453;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ghfkhkne2nefm2hq064eu3bodbm9uiq7', '41.73.1.75', 1595860958, '__ci_last_regenerate|i:1595860955;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gla9grt2u4vqo8r0pa9mtinkcip0htm0', '41.190.14.51', 1595188737, '__ci_last_regenerate|i:1595188650;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gmol1vhr390r5tutcsj5kqv2v6fgvbaf', '41.190.12.93', 1594822623, '__ci_last_regenerate|i:1594822622;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('go4cj5hdo45296gqsg6cm1lfo6vaarbb', '129.56.37.209', 1599123968, '__ci_last_regenerate|i:1599123967;redirect_url|s:50:\"http://admin.acce-abuja.com.ng/portal/homework/add\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h07inbe01otmajru1jopqanlo2a8osge', '41.73.1.68', 1594909153, '__ci_last_regenerate|i:1594908984;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h0nrti5jbf717qkhc1ge9sh87d5khlor', '193.212.4.37', 1601370719, '__ci_last_regenerate|i:1601370716;redirect_url|s:53:\"https://www.admin.acce-abuja.com.ng/portal/accounting\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h253rms3d9t5urkdkbri14doaiqia45j', '41.73.1.75', 1595854976, '__ci_last_regenerate|i:1595854974;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h82h4tjj77kf0ibv03cds1ucipoqavda', '41.190.14.129', 1594894570, '__ci_last_regenerate|i:1594894494;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hbbelsq5irdqsbusjii133glfct1c005', '41.73.1.68', 1594911387, '__ci_last_regenerate|i:1594911086;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('he0c1e14ago5npuh9rtacquoctgsptme', '35.203.245.180', 1601688884, '__ci_last_regenerate|i:1601688884;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('he2r2j8nljlsgepmh5mhd9d3da1vjpli', '105.112.114.93', 1600185556, '__ci_last_regenerate|i:1600185287;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hedchcmnofm4jc5mtvbrnnkn8h2evhtv', '41.190.14.149', 1599057730, '__ci_last_regenerate|i:1599057730;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('heme8j2gmcm97cfkvr1lphee08jfrl7a', '41.190.14.105', 1594838325, '__ci_last_regenerate|i:1594838325;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hev3r3sjijlcoimda21ri1qbeblidrgc', '41.73.1.75', 1601123559, '__ci_last_regenerate|i:1601123404;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hkkv35t33qvrfpgaqt9la6rn50nkbp4f', '41.190.14.129', 1594895483, '__ci_last_regenerate|i:1594895191;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hq3d2e7gu3rq9erdkfe2lcpta8nf81ss', '41.73.1.75', 1601891189, '__ci_last_regenerate|i:1601890811;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hq6ldvhv57b5894v99rr5k0pilkq7mqc', '197.210.52.172', 1595514363, '__ci_last_regenerate|i:1595514259;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hq6ppo7fe8etgkjrs37tflp9pvdv1a0t', '129.56.61.207', 1597220531, '__ci_last_regenerate|i:1597220233;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hv1qhpi50uje7e15en78eot18ggf6ef8', '59.179.18.6', 1601369761, '__ci_last_regenerate|i:1601369757;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i07cg26im5hm3313lbqp1nrho20mr93t', '66.102.9.83', 1601378574, '__ci_last_regenerate|i:1601378566;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i2vas3mgiet6q5u3jn5raeutdikqhas8', '41.190.12.66', 1595378804, '__ci_last_regenerate|i:1595378780;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ie0qv0c84jqtv5ogouldm4rgupkog0rc', '41.190.14.129', 1594893119, '__ci_last_regenerate|i:1594893092;redirect_url|s:58:\"https://www.admin.acce-abuja.com.ng/portal/dashboard/index\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ikiqtsvophh0r79sfob9i1c86lg3v5d3', '66.102.9.79', 1601378582, '__ci_last_regenerate|i:1601378575;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iu24ejiteekfuauu9mfpapig0e9vcgd9', '41.73.1.65', 1601217048, '__ci_last_regenerate|i:1601217048;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j02l1t3k79l736vo907nr374d47ci56k', '105.112.113.10', 1600779635, '__ci_last_regenerate|i:1600779635;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jbpjg3hd7ig7du7ua4dv2gqc31f7nv2f', '41.73.1.71', 1601382079, '__ci_last_regenerate|i:1601381893;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jbs46q30179gtkcgugb1t3bb5bi3jckn', '41.190.14.129', 1594895165, '__ci_last_regenerate|i:1594894882;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jc3jd8fta0hu2dad4c3b7onj6q2ajjuk', '41.73.1.71', 1601378454, '__ci_last_regenerate|i:1601378452;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jd0i6kt96bnpq5eios4fnhu7n1efchgn', '41.73.1.71', 1601376203, '__ci_last_regenerate|i:1601376197;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jdg9fjb0h8qn29i6igsb11n436vi9oet', '41.190.14.117', 1599059682, '__ci_last_regenerate|i:1599059682;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jhqc4vkqci00ovg7ct5m532ojrvfci9n', '41.73.1.76', 1595946759, '__ci_last_regenerate|i:1595946759;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ji582ff15dle9ui377f3s2hrfu7haamb', '41.73.1.71', 1601370715, '__ci_last_regenerate|i:1601370689;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k24ms0nrmea597cm4vl2tiqhuoglvcqs', '41.73.1.68', 1594907218, '__ci_last_regenerate|i:1594906871;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k51mbi71gti748b8lk0u7o2cq8vgg205', '41.73.1.71', 1601382863, '__ci_last_regenerate|i:1601382256;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k9jpshjbiog3s7319a09qmjoebsn3rq0', '41.73.1.68', 1601467919, '__ci_last_regenerate|i:1601466178;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k9meqdscjcfbgp79di0e009m1mjlgdba', '41.73.1.71', 1601380904, '__ci_last_regenerate|i:1601380573;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kp5qn2e6jpbvm6s5hfo19l0aa7629u5d', '35.203.245.180', 1601688885, '__ci_last_regenerate|i:1601688885;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l02badn1495odt6fmtvtorpeq8tabrr2', '41.73.1.75', 1595857506, '__ci_last_regenerate|i:1595857144;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l04q928tcm6e3aa5tocapmvm50u4vi35', '91.106.51.5', 1595853832, '__ci_last_regenerate|i:1595853828;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l0k1h0rj23043to5qi0ee5oslqc3a3ns', '197.149.127.197', 1601980112, '__ci_last_regenerate|i:1601980110;redirect_url|s:61:\"https://www.admin.acce-abuja.com.ng/portal/settings/universal\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l12cpb32dpfo76lg6e4je70jghbtt5br', '41.73.1.75', 1601893506, '__ci_last_regenerate|i:1601893327;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l5fag8v0aglsiqq9fp80io5tgakvdmlb', '209.143.6.230', 1596032618, '__ci_last_regenerate|i:1596032617;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l8qlqecs9o4clesjlt85ml04296pmfi1', '41.73.1.68', 1594909596, '__ci_last_regenerate|i:1594909334;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lcijgag4oqpo0cjocmdd0ifid5srqudu', '41.73.1.71', 1601377227, '__ci_last_regenerate|i:1601377227;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lf57gh4549qlcbvbu7ok3tjooa5rsqm2', '41.73.1.68', 1594913316, '__ci_last_regenerate|i:1594913145;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lhva546lk6uq2m411mkdjlh7m6s4v478', '41.73.1.75', 1601979934, '__ci_last_regenerate|i:1601978892;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lijc0bevqnb885imt1cte26iligrpcba', '41.73.1.68', 1594914230, '__ci_last_regenerate|i:1594914072;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lkr3ju0708hoc9bnjcqdtkpmrsmf1hoa', '41.190.12.93', 1594823314, '__ci_last_regenerate|i:1594823029;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ll97bqkqcv8n68vtanml7u1q3er93319', '129.56.34.205', 1599000740, '__ci_last_regenerate|i:1599000735;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/event/types\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lo4ei7r7lk2t6plg8kugqhuv4slvnsln', '41.73.1.75', 1601114533, '__ci_last_regenerate|i:1601114361;redirect_url|s:64:\"http://admin.acce-abuja.com.ng/portal/sendsmsmail/template/email\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ltaksh9bhfon3srgd0lrntomc7d1jfdh', '41.73.1.68', 1594907650, '__ci_last_regenerate|i:1594907522;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m048bpdn336pshhk5oh360dvphudfkhc', '41.190.12.229', 1595179567, '__ci_last_regenerate|i:1595179563;redirect_url|s:69:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/sent\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m38hrhekink2lpa7ildmn3e7iih1gfo2', '41.73.1.76', 1596031575, '__ci_last_regenerate|i:1596031289;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m6eogo7964d89iktvrvt1q26fde08193', '41.190.14.19', 1600405464, '__ci_last_regenerate|i:1600405400;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m6iur5jg5t64j100v4d3013g5jig4dp0', '41.73.1.68', 1594913685, '__ci_last_regenerate|i:1594913626;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mbd5qnb66t7skcvh08l7f3rq77pc85ii', '41.73.1.68', 1594911673, '__ci_last_regenerate|i:1594911388;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mhesmepcoohjljoc2b0hshrsnsnq6oo2', '41.73.1.75', 1601977114, '__ci_last_regenerate|i:1601977070;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mj0i4umvii1lvb4pt267b7mph481o04l', '41.73.1.75', 1595860095, '__ci_last_regenerate|i:1595858648;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mli7hij5vqeb9r8m3ksb60uf6pchh0c4', '41.190.14.51', 1595185680, '__ci_last_regenerate|i:1595185672;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mp9vb4eobnb66jp4hjtq93cve02dk15f', '41.73.1.71', 1601378456, '__ci_last_regenerate|i:1601378454;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mto7hqd2i4827fbbemnbeb5atdfn2870', '105.112.114.93', 1600181135, '__ci_last_regenerate|i:1600181134;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mu1fs0intve6tt9un25es2v561hb663r', '41.190.14.105', 1594835515, '__ci_last_regenerate|i:1594835514;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mui8rb54rviat6jkfsqfl9203k4gnt7a', '37.170.83.176', 1597171097, '__ci_last_regenerate|i:1597171097;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n091gpb78sqs7se948tpq86ga0e1m28s', '41.190.12.220', 1594818660, '__ci_last_regenerate|i:1594818370;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nf0hi3bklh4o4vf3pbb551pgmfl67opn', '41.190.14.117', 1599060532, '__ci_last_regenerate|i:1599060532;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ngkundmtvgssn727m2skur253vtqh6f6', '41.73.1.75', 1597491264, '__ci_last_regenerate|i:1597491263;redirect_url|s:54:\"https://www.admin.acce-abuja.com.ng/portal/student/add\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o3448mldct6cmeaer73kmm5nioefpksg', '41.73.1.71', 1601380564, '__ci_last_regenerate|i:1601380264;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o48c907on0dsbvi1qfd23kr6rumanre5', '41.73.1.71', 1601380263, '__ci_last_regenerate|i:1601379963;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o8cjdrn8oj5hbib173qm6tv9coq0qpvr', '41.190.12.83', 1598155969, '__ci_last_regenerate|i:1598155721;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oai9lncbi6fpp2a8h8ose4mj7hmq07r6', '41.190.12.229', 1595180491, '__ci_last_regenerate|i:1595180454;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oc1ttq142u3o26g7qkvocfokdqcsljmi', '41.190.12.220', 1594819994, '__ci_last_regenerate|i:1594819994;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ofmbfdmviapu5bmg2ckraksdcui9icuq', '41.73.1.68', 1601469247, '__ci_last_regenerate|i:1601468542;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oi7pjot6c8lqcg9ga2unjvcngmtmmli9', '41.190.12.93', 1594824066, '__ci_last_regenerate|i:1594823771;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ol8aru7l89ilngf2il41ub6e9cbahmsr', '41.190.14.105', 1594834038, '__ci_last_regenerate|i:1594833831;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oq8bnrpa9397mtrlqtphjneg6rbtqqrr', '41.190.12.93', 1594822893, '__ci_last_regenerate|i:1594822623;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ouhgkq4sek4i5p1n2798n168e9am2i9m', '41.190.12.66', 1595377052, '__ci_last_regenerate|i:1595376838;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ovplcdhl3bberuu74s0a9jubntgjq7mk', '105.112.112.224', 1601325273, '__ci_last_regenerate|i:1601325081;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p2s0tcnnrlea00mhcf4evrdlrdsme1gn', '41.190.12.227', 1601301294, '__ci_last_regenerate|i:1601301179;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pa3319oa016ecc6k1o8jse2nvdo62n0h', '41.73.1.68', 1594905568, '__ci_last_regenerate|i:1594905566;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pe1lva8v9igj4g2cqlqab812pqkv09s5', '41.190.12.93', 1594824461, '__ci_last_regenerate|i:1594824170;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('phsm3dt0uc0hhp373pup87afj4jd53to', '41.73.1.75', 1595426131, '__ci_last_regenerate|i:1595426072;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pi6qn5or21e0bhascfutiusd41plm8og', '41.190.14.129', 1594897052, '__ci_last_regenerate|i:1594897017;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pjfm6qdldq0ssgiprv3ttc3j9undkkp9', '197.242.125.206', 1595913323, '__ci_last_regenerate|i:1595913322;redirect_url|s:50:\"http://admin.acce-abuja.com.ng/portal/parents/view\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q2sthcj8rpgi79fmfuer4e21utt0k1d7', '41.190.12.248', 1594918579, '__ci_last_regenerate|i:1594918579;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q35n1cu79ldln5jee670hp2nunc3cjdk', '41.190.12.66', 1595375336, '__ci_last_regenerate|i:1595375045;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q9nfcd0k30ev3kr787ivu7c1i9cgk8jb', '41.73.1.68', 1601469531, '__ci_last_regenerate|i:1601469247;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q9sffvdocrl6t9kdfh6a1ueovmjc6ec6', '41.190.14.202', 1599071337, '__ci_last_regenerate|i:1599071037;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/event/types\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qen5jkgacpdmc2l7b3pv74c0nnsb2adn', '41.73.1.75', 1601895855, '__ci_last_regenerate|i:1601894215;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qevhvi1rcuq3ulika6eu37dnbd1nmt9f', '41.73.1.68', 1594914058, '__ci_last_regenerate|i:1594914031;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qicm60sgq8j1uu974cd7rign3fc8g2jt', '41.73.1.75', 1601980191, '__ci_last_regenerate|i:1601979936;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qkc8qrmgvtbasa3qekev3frg20i8e8a6', '197.210.52.172', 1595515714, '__ci_last_regenerate|i:1595515483;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qmtfffeta47o3i3pjo83s8ibofnnmh4a', '41.73.1.71', 1601370063, '__ci_last_regenerate|i:1601369890;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpq8aqtlsfc98btvp8db93eqp1f0vtdr', '41.73.1.71', 1601372602, '__ci_last_regenerate|i:1601372543;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qsfh4otpdt5ltb8m4n4i4dj9mqec6saj', '41.73.1.68', 1601468516, '__ci_last_regenerate|i:1601468220;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qughhv55snbra8s4k9q9e7e2g82r4nmo', '41.190.14.149', 1599062800, '__ci_last_regenerate|i:1599062800;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r0g5dv0hr8104hu1b9hhmqcs86oddhke', '41.190.14.178', 1597163760, '__ci_last_regenerate|i:1597163756;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r3uh1qqho6q0rfqu4oiuf50t6brvjpuo', '105.112.114.93', 1600177612, '__ci_last_regenerate|i:1600177611;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r5425u8034rmnpo5fpmomvbbm8u4jorp', '41.73.1.68', 1594912151, '__ci_last_regenerate|i:1594912001;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rb5tb4gh45j0gne4gg9gbler0sj480p2', '5.186.12.38', 1601380086, '__ci_last_regenerate|i:1601380085;redirect_url|s:50:\"https://www.admin.acce-abuja.com.ng/portal/classes\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rbts9ivm2k11s2sf5urk4nf2b5bo7j6f', '41.73.1.71', 1601376198, '__ci_last_regenerate|i:1601376196;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rgpk6ttgu7944q9r317ieonmoc4aioiu', '41.190.12.83', 1598155598, '__ci_last_regenerate|i:1598155381;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rimo9ovm529otj0bgg1sdutr6tn5f4ls', '41.73.1.68', 1594913652, '__ci_last_regenerate|i:1594913652;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s2l7b0vrj1vk6j1nrec5g15g12gs8jha', '41.73.1.68', 1594912918, '__ci_last_regenerate|i:1594912757;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s3p75mehaas683oj5v57oj2j87f61fnp', '41.190.14.105', 1594838575, '__ci_last_regenerate|i:1594838417;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('se58gt3cf5ai4don6vpsnkhp9tvpe9hj', '41.73.1.71', 1601375186, '__ci_last_regenerate|i:1601372886;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('skh2lpapp5nref14d48rvqut4djinu9a', '66.102.8.15', 1601374899, '__ci_last_regenerate|i:1601374896;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t8fpn8ae4sjt0ard3ossd3kk06k98r3u', '41.190.12.220', 1594818364, '__ci_last_regenerate|i:1594818057;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:36:\"You Are Now Using The Latest Version\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tsdebip4qh42q4ga83g6om1qh58qicln', '193.189.184.198', 1601466333, '__ci_last_regenerate|i:1601466331;redirect_url|s:70:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u33dt3l9losq7o9cg6mno0aorikl25cs', '41.73.1.71', 1601378456, '__ci_last_regenerate|i:1601378454;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u4sbqdkmlj2en88ngohgb1aij37abfo9', '41.190.12.223', 1598076965, '__ci_last_regenerate|i:1598076961;redirect_url|s:72:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/compose\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u6a2o7iuuuc9g8g62k6mdujh33ql1a3v', '41.190.12.93', 1594825919, '__ci_last_regenerate|i:1594825868;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u93v93711v1lcmeuj34u9il5c8ff08um', '41.190.12.83', 1598149727, '__ci_last_regenerate|i:1598149724;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ua34nfo0vu8c7kg2lr78ta9pukc6lgbv', '41.190.14.129', 1594894514, '__ci_last_regenerate|i:1594894494;redirect_url|s:58:\"https://www.admin.acce-abuja.com.ng/portal/employee/view/3\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uac8hoc41t4oe93tai420ji12pb8oefk', '152.89.163.34', 1594910640, '__ci_last_regenerate|i:1594910027;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uf67qn2acr43k4i9cr8ma2ita628sq3v', '41.73.1.75', 1601894215, '__ci_last_regenerate|i:1601894214;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uuqvv0vkucna1gtlhi1loctdth1ukjsq', '105.112.113.52', 1600682477, '__ci_last_regenerate|i:1600682229;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uvnhq76dg0itr5cg5hsho9fhisat56pu', '129.205.113.231', 1601298454, '__ci_last_regenerate|i:1601298451;redirect_url|s:44:\"http://admin.acce-abuja.com.ng/portal/branch\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v2g9kbvtmtigrt363k5o4qahj8mnoo40', '41.190.14.57', 1596655490, '__ci_last_regenerate|i:1596655411;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v4uob14mi4i2mh4k66qri64401bblo6p', '41.190.14.246', 1600683400, '__ci_last_regenerate|i:1600683400;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v6v7qujdic3r13ubqkfuf827gdpumf4m', '41.73.1.71', 1601376089, '__ci_last_regenerate|i:1601375877;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vbartl0aaq4c32tcjhrrm4fsvmtvjatg', '41.73.1.75', 1601980264, '__ci_last_regenerate|i:1601980263;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('veiapju71dt155pmpgg3vi1rjum6djud', '41.190.12.66', 1595376282, '__ci_last_regenerate|i:1595376095;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vm5me0lev8i8avbpvshusfe5ncco3q4k', '41.73.1.75', 1601892276, '__ci_last_regenerate|i:1601891908;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vmpcsi3m113j52jh7kql0nn8cp2usfqs', '41.73.1.75', 1601894216, '__ci_last_regenerate|i:1601894215;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vo2m9i7m8shn9hg42ie7dd5r8nh1vmcc', '41.73.1.72', 1601112080, '__ci_last_regenerate|i:1601111915;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vt6nvvtmsdcnnjj2shakd6ftmpf8tm6u', '41.190.14.105', 1594836596, '__ci_last_regenerate|i:1594836594;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vu2v5dluh5c19ald0s4t98efc27vf308', '41.190.14.7', 1599421662, '__ci_last_regenerate|i:1599421502;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vv7nq2e53r0ka0cuvjm0mf22d4prgrvd', '105.112.113.10', 1600779884, '__ci_last_regenerate|i:1600779635;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `is_system` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (1, 'Super Admin', 'superadmin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (2, 'Admin', 'admin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (3, 'Teacher', 'teacher', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (4, 'Accountant', 'accountant', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (5, 'Librarian', 'librarian', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (6, 'Parent', 'parent', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (7, 'Student', 'student', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (8, 'Research, Monitoring and Evaluation', 'research,monitoringandevaluation', '0');


#
# TABLE STRUCTURE FOR: salary_template
#

DROP TABLE IF EXISTS `salary_template`;

CREATE TABLE `salary_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL,
  `overtime_salary` varchar(100) NOT NULL DEFAULT '0',
  `branch_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: salary_template_details
#

DROP TABLE IF EXISTS `salary_template_details`;

CREATE TABLE `salary_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_template_id` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT '0.00',
  `type` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: schoolyear
#

DROP TABLE IF EXISTS `schoolyear`;

CREATE TABLE `schoolyear` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_year` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (1, '2019-2020', 1, '2020-02-25 20:35:41', '2020-02-26 16:54:49');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (3, '2020-2021', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (4, '2021-2022', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (5, '2022-2023', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (6, '2023-2024', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (7, '2024-2025', 1, '2020-02-25 20:35:41', '2020-02-26 01:20:04');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (9, '2025-2026', 1, '2020-02-26 08:00:10', '2020-02-26 13:00:24');


#
# TABLE STRUCTURE FOR: section
#

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `capacity` varchar(20) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (1, 'A', '150', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (2, 'B', '150', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (3, 'C', '150', 1);


#
# TABLE STRUCTURE FOR: sections_allocation
#

DROP TABLE IF EXISTS `sections_allocation`;

CREATE TABLE `sections_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (1, 1, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (2, 2, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (3, 3, 3);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (4, 4, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (5, 5, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (6, 6, 3);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (7, 7, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (8, 8, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (9, 9, 3);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (10, 10, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (11, 11, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (12, 12, 3);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (13, 13, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (14, 14, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (15, 15, 3);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (16, 16, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (17, 17, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (18, 18, 3);


#
# TABLE STRUCTURE FOR: sms_api
#

DROP TABLE IF EXISTS `sms_api`;

CREATE TABLE `sms_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `sms_api` (`id`, `name`) VALUES (1, 'twilio');
INSERT INTO `sms_api` (`id`, `name`) VALUES (2, 'clickatell');
INSERT INTO `sms_api` (`id`, `name`) VALUES (3, 'msg91');
INSERT INTO `sms_api` (`id`, `name`) VALUES (4, 'bulksms');
INSERT INTO `sms_api` (`id`, `name`) VALUES (5, 'textlocal');


#
# TABLE STRUCTURE FOR: sms_credential
#

DROP TABLE IF EXISTS `sms_credential`;

CREATE TABLE `sms_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_api_id` int(11) NOT NULL,
  `field_one` varchar(300) NOT NULL,
  `field_two` varchar(300) NOT NULL,
  `field_three` varchar(300) NOT NULL,
  `field_four` varchar(300) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: sms_template
#

DROP TABLE IF EXISTS `sms_template`;

CREATE TABLE `sms_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (1, 'admission', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (2, 'fee_collection', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {paid_amount}, {paid_date} ');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (3, 'attendance', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (4, 'exam_attendance', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_name}, {term_name}, {subject}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (5, 'exam_results', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_name}, {term_name}, {subject}, {marks}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (6, 'homework', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {subject}, {date_of_homework}, {date_of_submission}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (7, 'live_class', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {date_of_live_class}, {start_time}, {end_time}, {host_by}');


#
# TABLE STRUCTURE FOR: sms_template_details
#

DROP TABLE IF EXISTS `sms_template_details`;

CREATE TABLE `sms_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `notify_student` tinyint(3) NOT NULL DEFAULT '1',
  `notify_parent` tinyint(3) NOT NULL DEFAULT '1',
  `template_body` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: staff
#

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` int(11) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `experience_details` varchar(255) DEFAULT NULL,
  `total_experience` varchar(255) DEFAULT NULL,
  `designation` int(11) NOT NULL,
  `joining_date` varchar(100) NOT NULL,
  `birthday` varchar(100) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `present_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `salary_template_id` int(11) DEFAULT '0',
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (1, '3bf62b8', 'Adnan Baba-Ahmed', 0, '', NULL, NULL, 0, '2020-07-15', '', 'male', 'Islam', 'O+', 'No. 11 Chuba Okagdibo Street Apo', '', '+2348092406828', 'babaahmedadnan@gmail.com', 0, NULL, '5a4c4849c863c4e9d19350ddef2edded.PNG', 'https://www.facebook.com/adnanbabaahmed', 'https://ng.linkedin.com/in/adnan-baba-ahmed-31a44872', 'twitter.com/adnanu_', '2020-07-15 13:44:05', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (2, 'b1b4698', 'Alfaky Bello', 1, 'Msc Biology', '', '', 2, '2020-07-15', '', 'male', '', 'O+', 'Abuja', '', '09092082082080', 'alfakybello@gmail.com', 0, 1, 'd2716a265b93ba536f2cc3bf9a176141.JPG', '', '', '', '2020-07-15 15:44:50', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (3, 'f77e5fb', 'Adnan Baba-Ahmed', 1, 'BSc. Software Engineering', '', '', 2, '2020-07-16', '', 'male', '', '', 'No. 11 Chuba Okagdibo Street Apo', '', '+2348092406828', 'babaahmedadnan@gmail.com', 0, 1, 'bd9a4f666a4410da2d12717dd2a34c1f.JPG', '', '', '', '2020-07-16 11:40:31', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (4, 'a215dce', 'Abba Sanda', 2, 'MSc. Financial Accounting', '', '', 3, '2020-07-16', '1999-09-20', 'male', 'Islam', 'B+', 'Wuse 2, Abuja', '', '080820837823', 'abbasanda@gmail.com', 0, 1, 'defualt.png', '', '', '', '2020-07-16 15:10:09', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (5, 'fe029a4', 'Umar Sanda', 3, 'Msc. Library Management', '', '', 4, '2020-07-16', '1990-05-24', 'male', 'Islam', 'A+', 'Games Village, Abuja', '', '09075654563', 'umarsanda@gmail.com', 0, 1, 'b7c3a3cbccb9215506163355c4e086fb.png', '', '', '', '2020-07-16 15:17:30', NULL);


#
# TABLE STRUCTURE FOR: staff_attendance
#

DROP TABLE IF EXISTS `staff_attendance`;

CREATE TABLE `staff_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `status` varchar(11) DEFAULT NULL COMMENT 'P=Present, A=Absent, H=Holiday, L=Late',
  `remark` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `staff_attendance` (`id`, `staff_id`, `status`, `remark`, `date`, `branch_id`) VALUES (1, 2, 'H', 'On Vacation', '2020-07-27', 1);
INSERT INTO `staff_attendance` (`id`, `staff_id`, `status`, `remark`, `date`, `branch_id`) VALUES (2, 2, 'A', '', '2020-09-21', 1);


#
# TABLE STRUCTURE FOR: staff_bank_account
#

DROP TABLE IF EXISTS `staff_bank_account`;

CREATE TABLE `staff_bank_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `holder_name` varchar(255) NOT NULL,
  `bank_branch` varchar(255) NOT NULL,
  `bank_address` varchar(255) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: staff_department
#

DROP TABLE IF EXISTS `staff_department`;

CREATE TABLE `staff_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'Science', 1, '2020-07-15 15:39:10', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'Finance', 1, '2020-07-16 15:05:39', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 'Library', 1, '2020-07-16 15:11:20', NULL);


#
# TABLE STRUCTURE FOR: staff_designation
#

DROP TABLE IF EXISTS `staff_designation`;

CREATE TABLE `staff_designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'Head Teacher', 1, '2020-07-16 11:32:49', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 'Bursar', 1, '2020-07-16 15:04:43', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (4, 'Head Librarian', 1, '2020-07-16 15:11:32', NULL);


#
# TABLE STRUCTURE FOR: staff_documents
#

DROP TABLE IF EXISTS `staff_documents`;

CREATE TABLE `staff_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: staff_privileges
#

DROP TABLE IF EXISTS `staff_privileges`;

CREATE TABLE `staff_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `is_add` tinyint(1) NOT NULL,
  `is_edit` tinyint(1) NOT NULL,
  `is_view` tinyint(1) NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=688 DEFAULT CHARSET=utf8;

INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (1, 3, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (2, 3, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (3, 3, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (4, 3, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (5, 3, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (6, 3, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (7, 3, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (8, 3, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (9, 3, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (10, 3, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (11, 3, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (12, 3, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (13, 3, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (14, 3, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (15, 3, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (16, 3, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (17, 3, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (18, 3, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (20, 3, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (21, 3, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (22, 3, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (23, 3, 22, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (24, 3, 23, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (25, 3, 24, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (26, 3, 25, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (27, 3, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (28, 3, 27, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (29, 3, 28, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (30, 3, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (31, 3, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (32, 3, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (33, 3, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (34, 3, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (35, 3, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (36, 3, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (37, 3, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (38, 3, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (39, 3, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (40, 3, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (41, 3, 78, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (42, 3, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (43, 3, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (44, 3, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (45, 3, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (46, 3, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (47, 3, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (48, 3, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (49, 3, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (50, 3, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (51, 3, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (52, 3, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (53, 3, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (54, 3, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (55, 3, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (56, 3, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (57, 3, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (58, 3, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (59, 3, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (60, 3, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (61, 3, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (62, 3, 59, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (63, 3, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (64, 3, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (65, 3, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (66, 3, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (67, 3, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (68, 3, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (69, 3, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (70, 3, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (71, 3, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (72, 3, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (73, 3, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (74, 3, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (75, 3, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (76, 3, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (77, 3, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (78, 3, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (79, 3, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (80, 3, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (81, 3, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (82, 3, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (83, 3, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (84, 3, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (85, 3, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (86, 3, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (87, 3, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (88, 2, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (89, 2, 2, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (90, 2, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (91, 2, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (92, 2, 5, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (93, 2, 30, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (94, 2, 7, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (95, 2, 8, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (96, 2, 6, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (97, 2, 9, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (98, 2, 10, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (99, 2, 11, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (100, 2, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (101, 2, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (102, 2, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (103, 2, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (104, 2, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (105, 2, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (107, 2, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (108, 2, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (109, 2, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (110, 2, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (111, 2, 23, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (112, 2, 24, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (113, 2, 25, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (114, 2, 26, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (115, 2, 27, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (116, 2, 28, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (117, 2, 29, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (118, 2, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (119, 2, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (120, 2, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (121, 2, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (122, 2, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (123, 2, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (124, 2, 37, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (125, 2, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (126, 2, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (127, 2, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (128, 2, 78, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (129, 2, 79, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (130, 2, 40, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (131, 2, 41, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (132, 2, 42, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (133, 2, 43, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (134, 2, 44, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (135, 2, 45, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (136, 2, 46, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (137, 2, 47, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (138, 2, 48, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (139, 2, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (140, 2, 50, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (141, 2, 51, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (142, 2, 52, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (143, 2, 53, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (144, 2, 54, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (145, 2, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (146, 2, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (147, 2, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (148, 2, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (149, 2, 59, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (150, 2, 60, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (151, 2, 61, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (152, 2, 62, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (153, 2, 80, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (154, 2, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (155, 2, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (156, 2, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (157, 2, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (158, 2, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (159, 2, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (160, 2, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (161, 2, 76, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (162, 2, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (163, 2, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (164, 2, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (165, 2, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (166, 2, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (167, 2, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (168, 2, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (169, 2, 82, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (170, 2, 83, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (171, 2, 84, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (172, 2, 85, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (173, 2, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (174, 2, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (175, 7, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (176, 7, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (177, 7, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (178, 7, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (179, 7, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (180, 7, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (181, 7, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (182, 7, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (183, 7, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (184, 7, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (185, 7, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (186, 7, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (187, 7, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (188, 7, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (189, 7, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (190, 7, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (191, 7, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (192, 7, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (194, 7, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (195, 7, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (196, 7, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (197, 7, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (198, 7, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (199, 7, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (200, 7, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (201, 7, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (202, 7, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (203, 7, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (204, 7, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (205, 7, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (206, 7, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (207, 7, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (208, 7, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (209, 7, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (210, 7, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (211, 7, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (212, 7, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (213, 7, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (214, 7, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (215, 7, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (216, 7, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (217, 7, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (218, 7, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (219, 7, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (220, 7, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (221, 7, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (222, 7, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (223, 7, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (224, 7, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (225, 7, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (226, 7, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (227, 7, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (228, 7, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (229, 7, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (230, 7, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (231, 7, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (232, 7, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (233, 7, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (234, 7, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (235, 7, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (236, 7, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (237, 7, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (238, 7, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (239, 7, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (240, 7, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (241, 7, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (242, 7, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (243, 7, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (244, 7, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (245, 7, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (246, 7, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (247, 7, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (248, 7, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (249, 7, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (250, 7, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (251, 7, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (252, 7, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (253, 7, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (254, 7, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (255, 7, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (256, 7, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (257, 7, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (258, 7, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (259, 7, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (260, 7, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (261, 7, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (262, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (263, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (264, 89, 89, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (265, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (266, 2, 88, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (267, 2, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (268, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (269, 2, 90, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (270, 91, 91, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (271, 92, 92, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (272, 2, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (273, 2, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (274, 93, 93, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (275, 94, 94, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (276, 95, 95, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (277, 96, 96, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (278, 2, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (279, 2, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (280, 2, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (281, 2, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (282, 97, 97, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (283, 98, 98, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (284, 2, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (285, 2, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (286, 99, 99, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (287, 100, 100, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (288, 101, 101, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (289, 102, 102, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (290, 2, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (291, 2, 100, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (292, 2, 101, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (293, 2, 102, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (294, 103, 103, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (295, 2, 103, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (296, 3, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (297, 3, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (298, 3, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (299, 3, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (300, 3, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (301, 3, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (302, 3, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (303, 3, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (304, 3, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (305, 3, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (306, 3, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (307, 3, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (308, 3, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (309, 3, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (310, 3, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (311, 3, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (312, 4, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (313, 4, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (314, 4, 93, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (315, 4, 94, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (316, 4, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (317, 4, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (318, 4, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (319, 4, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (320, 4, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (321, 4, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (322, 4, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (323, 4, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (324, 4, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (325, 4, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (326, 4, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (327, 4, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (328, 4, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (329, 4, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (330, 4, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (331, 4, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (332, 4, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (333, 4, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (334, 4, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (335, 4, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (336, 4, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (337, 4, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (338, 4, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (339, 4, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (340, 4, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (341, 4, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (343, 4, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (344, 4, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (345, 4, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (346, 4, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (347, 4, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (348, 4, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (349, 4, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (350, 4, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (351, 4, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (352, 4, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (353, 4, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (354, 4, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (355, 4, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (356, 4, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (357, 4, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (358, 4, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (359, 4, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (360, 4, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (361, 4, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (362, 4, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (363, 4, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (364, 4, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (365, 4, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (366, 4, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (367, 4, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (368, 4, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (369, 4, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (370, 4, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (371, 4, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (372, 4, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (373, 4, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (374, 4, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (375, 4, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (376, 4, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (377, 4, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (378, 4, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (379, 4, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (380, 4, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (381, 4, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (382, 4, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (383, 4, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (384, 4, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (385, 4, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (386, 4, 58, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (387, 4, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (388, 4, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (389, 4, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (390, 4, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (391, 4, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (392, 4, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (393, 4, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (394, 4, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (395, 4, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (396, 4, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (397, 4, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (398, 4, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (399, 4, 76, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (400, 4, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (401, 4, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (402, 4, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (403, 4, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (404, 4, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (405, 4, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (406, 4, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (407, 4, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (408, 4, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (409, 4, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (410, 4, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (411, 4, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (412, 4, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (413, 4, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (414, 4, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (415, 5, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (416, 5, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (417, 5, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (418, 5, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (419, 5, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (420, 5, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (421, 5, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (422, 5, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (423, 5, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (424, 5, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (425, 5, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (426, 5, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (427, 5, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (428, 5, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (429, 5, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (430, 5, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (431, 5, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (432, 5, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (433, 5, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (434, 5, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (435, 5, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (436, 5, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (437, 5, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (438, 5, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (439, 5, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (440, 5, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (441, 5, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (442, 5, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (443, 5, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (444, 5, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (446, 5, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (447, 5, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (448, 5, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (449, 5, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (450, 5, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (451, 5, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (452, 5, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (453, 5, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (454, 5, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (455, 5, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (456, 5, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (457, 5, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (458, 5, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (459, 5, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (460, 5, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (461, 5, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (462, 5, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (463, 5, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (464, 5, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (465, 5, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (466, 5, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (467, 5, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (468, 5, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (469, 5, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (470, 5, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (471, 5, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (472, 5, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (473, 5, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (474, 5, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (475, 5, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (476, 5, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (477, 5, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (478, 5, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (479, 5, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (480, 5, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (481, 5, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (482, 5, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (483, 5, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (484, 5, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (485, 5, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (486, 5, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (487, 5, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (488, 5, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (489, 5, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (490, 5, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (491, 5, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (492, 5, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (493, 5, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (494, 5, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (495, 5, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (496, 5, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (497, 5, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (498, 5, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (499, 5, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (500, 5, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (501, 5, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (502, 5, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (503, 5, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (504, 5, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (505, 5, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (506, 5, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (507, 5, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (508, 5, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (509, 5, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (510, 5, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (511, 5, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (512, 5, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (513, 5, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (514, 5, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (515, 5, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (516, 5, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (517, 5, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (518, 104, 104, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (519, 2, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (520, 4, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (521, 2, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (522, 2, 105, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (523, 2, 106, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (524, 2, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (525, 2, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (526, 2, 108, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (527, 3, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (528, 3, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (529, 3, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (530, 3, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (531, 3, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (532, 3, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (533, 3, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (534, 2, 110, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (535, 2, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (536, 2, 112, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (537, 2, 113, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (538, 2, 114, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (539, 2, 115, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (540, 2, 116, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (541, 2, 117, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (542, 3, 110, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (543, 3, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (544, 3, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (545, 3, 113, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (546, 3, 114, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (547, 3, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (548, 3, 116, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (549, 3, 117, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (550, 2, 127, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (551, 2, 118, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (552, 2, 119, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (553, 2, 120, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (554, 2, 121, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (555, 2, 122, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (556, 2, 123, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (557, 2, 124, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (558, 2, 125, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (559, 2, 126, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (560, 8, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (561, 8, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (562, 8, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (563, 8, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (564, 8, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (565, 8, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (566, 8, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (567, 8, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (568, 8, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (569, 8, 100, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (570, 8, 101, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (571, 8, 102, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (572, 8, 118, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (573, 8, 119, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (574, 8, 120, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (575, 8, 121, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (576, 8, 122, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (577, 8, 123, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (578, 8, 124, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (579, 8, 125, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (580, 8, 126, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (581, 8, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (582, 8, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (583, 8, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (584, 8, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (585, 8, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (586, 8, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (587, 8, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (588, 8, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (589, 8, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (590, 8, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (591, 8, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (592, 8, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (593, 8, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (594, 8, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (595, 8, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (596, 8, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (597, 8, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (598, 8, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (599, 8, 110, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (600, 8, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (601, 8, 112, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (602, 8, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (603, 8, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (604, 8, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (605, 8, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (606, 8, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (607, 8, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (608, 8, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (609, 8, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (610, 8, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (611, 8, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (612, 8, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (613, 8, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (614, 8, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (615, 8, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (616, 8, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (617, 8, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (618, 8, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (619, 8, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (620, 8, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (621, 8, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (622, 8, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (623, 8, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (624, 8, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (625, 8, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (626, 8, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (627, 8, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (628, 8, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (629, 8, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (630, 8, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (631, 8, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (632, 8, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (633, 8, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (634, 8, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (635, 8, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (636, 8, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (637, 8, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (638, 8, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (639, 8, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (640, 8, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (641, 8, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (642, 8, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (643, 8, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (644, 8, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (645, 8, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (646, 8, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (647, 8, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (648, 8, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (649, 8, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (650, 8, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (651, 8, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (652, 8, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (653, 8, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (654, 8, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (655, 8, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (656, 8, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (657, 8, 61, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (658, 8, 62, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (659, 8, 80, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (660, 8, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (661, 8, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (662, 8, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (663, 8, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (664, 8, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (665, 8, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (666, 8, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (667, 8, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (668, 8, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (669, 8, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (670, 8, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (671, 8, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (672, 8, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (673, 8, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (674, 8, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (675, 8, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (676, 8, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (677, 8, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (678, 8, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (679, 8, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (680, 8, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (681, 8, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (682, 8, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (683, 8, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (684, 8, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (685, 8, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (686, 8, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (687, 8, 128, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: student
#

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `register_no` varchar(100) NOT NULL,
  `admission_date` varchar(100) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `birthday` varchar(100) DEFAULT NULL,
  `religion` varchar(100) NOT NULL,
  `caste` varchar(100) NOT NULL,
  `blood_group` varchar(100) NOT NULL,
  `mother_tongue` varchar(100) DEFAULT NULL,
  `current_address` text,
  `permanent_address` text,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL DEFAULT '0',
  `vehicle_id` int(11) NOT NULL DEFAULT '0',
  `hostel_id` int(11) NOT NULL DEFAULT '0',
  `room_id` int(11) NOT NULL DEFAULT '0',
  `previous_details` text NOT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `student` (`id`, `register_no`, `admission_date`, `first_name`, `last_name`, `gender`, `birthday`, `religion`, `caste`, `blood_group`, `mother_tongue`, `current_address`, `permanent_address`, `city`, `state`, `mobileno`, `category_id`, `email`, `parent_id`, `route_id`, `vehicle_id`, `hostel_id`, `room_id`, `previous_details`, `photo`, `created_at`, `updated_at`) VALUES (1, 'ACCE-00001', '2020-07-16', 'Em', 'Marsh', 'male', '2018-12-31', '', '', 'A-', '', 'Apo', '', 'Gudu', 'Abuja', '8082304320', 1, '', 1, 0, 0, 0, 0, '{\"school_name\":\"\",\"qualification\":\"\",\"remarks\":\"\"}', 'defualt.png', '2020-07-16 16:00:26', '2020-07-16 16:00:26');
INSERT INTO `student` (`id`, `register_no`, `admission_date`, `first_name`, `last_name`, `gender`, `birthday`, `religion`, `caste`, `blood_group`, `mother_tongue`, `current_address`, `permanent_address`, `city`, `state`, `mobileno`, `category_id`, `email`, `parent_id`, `route_id`, `vehicle_id`, `hostel_id`, `room_id`, `previous_details`, `photo`, `created_at`, `updated_at`) VALUES (2, 'ACCE-00002', '2020-09-28', 'Abdulhakeem', 'Muhammad', 'male', '2019-01-08', 'Islam', '', 'A+', 'Hausa', 'Plot 41 Festrut Estate Katampe', '', 'Abuja', 'FCT', '09094225454', 1, 'mbabdoul@gmail.com', 1, 0, 0, 0, 0, '{\"school_name\":\"Regent International School \",\"qualification\":\"\",\"remarks\":\"\"}', 'defualt.png', '2020-09-28 14:25:11', '2020-09-28 14:25:11');


#
# TABLE STRUCTURE FOR: student_attendance
#

DROP TABLE IF EXISTS `student_attendance`;

CREATE TABLE `student_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(4) DEFAULT NULL COMMENT 'P=Present, A=Absent, H=Holiday, L=Late',
  `remark` text,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `student_attendance` (`id`, `student_id`, `date`, `status`, `remark`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 1, '2020-07-27', 'H', '', 1, '2020-07-27 15:42:35', NULL);
INSERT INTO `student_attendance` (`id`, `student_id`, `date`, `status`, `remark`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 1, '2020-09-30', 'A', '', 1, '2020-09-30 13:36:40', NULL);


#
# TABLE STRUCTURE FOR: student_category
#

DROP TABLE IF EXISTS `student_category`;

CREATE TABLE `student_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `student_category` (`id`, `branch_id`, `name`) VALUES (1, 1, 'Senior');
INSERT INTO `student_category` (`id`, `branch_id`, `name`) VALUES (2, 1, 'Junior');


#
# TABLE STRUCTURE FOR: student_documents
#

DROP TABLE IF EXISTS `student_documents`;

CREATE TABLE `student_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: subject
#

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject_code` varchar(200) NOT NULL,
  `subject_type` varchar(255) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `subject_author` varchar(255) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (1, 'Mathematics', 'MTH', 'Mandatory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (2, 'English', 'ENG', 'Theory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (3, 'Computer', 'COM', 'Practical', '', 1);


#
# TABLE STRUCTURE FOR: subject_assign
#

DROP TABLE IF EXISTS `subject_assign`;

CREATE TABLE `subject_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` longtext NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (1, 1, 1, '3', 0, 1, 3, '2020-09-29 12:58:03', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (2, 1, 1, '1', 0, 1, 3, '2020-09-29 12:58:13', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (3, 1, 1, '2', 0, 1, 3, '2020-09-29 12:58:13', NULL);


#
# TABLE STRUCTURE FOR: teacher_allocation
#

DROP TABLE IF EXISTS `teacher_allocation`;

CREATE TABLE `teacher_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (1, 3, 3, 2, 3, 1);


#
# TABLE STRUCTURE FOR: teacher_note
#

DROP TABLE IF EXISTS `teacher_note`;

CREATE TABLE `teacher_note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` longtext NOT NULL,
  `file_name` longtext NOT NULL,
  `enc_name` longtext NOT NULL,
  `type_id` int(11) NOT NULL,
  `class_id` longtext NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: theme_settings
#

DROP TABLE IF EXISTS `theme_settings`;

CREATE TABLE `theme_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `border_mode` varchar(200) NOT NULL,
  `dark_skin` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `theme_settings` (`id`, `border_mode`, `dark_skin`, `created_at`, `updated_at`) VALUES (1, 'true', 'true', '2018-10-23 17:59:38', '2020-05-10 14:08:47');


#
# TABLE STRUCTURE FOR: timetable_class
#

DROP TABLE IF EXISTS `timetable_class`;

CREATE TABLE `timetable_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `break` varchar(11) DEFAULT 'false',
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_room` varchar(100) DEFAULT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `day` varchar(20) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (1, 1, 1, '0', 1, 2, 'SS1 A Classroom', '09:00:00', '11:00:00', 'monday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (2, 1, 1, '0', 2, 2, 'SS1 A Classroom', '11:00:00', '12:00:00', 'monday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (3, 1, 1, '0', 3, 2, 'SS1 A Classroom', '12:30:00', '15:00:00', 'monday', 3, 1);


#
# TABLE STRUCTURE FOR: timetable_exam
#

DROP TABLE IF EXISTS `timetable_exam`;

CREATE TABLE `timetable_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `time_start` varchar(20) NOT NULL,
  `time_end` varchar(20) NOT NULL,
  `mark_distribution` text NOT NULL,
  `hall_id` int(11) NOT NULL,
  `exam_date` date NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transactions
#

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) NOT NULL,
  `voucher_head_id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT '0.00',
  `dr` decimal(18,2) NOT NULL DEFAULT '0.00',
  `cr` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bal` decimal(18,2) NOT NULL DEFAULT '0.00',
  `date` date NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `attachments` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transactions_links
#

DROP TABLE IF EXISTS `transactions_links`;

CREATE TABLE `transactions_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) DEFAULT NULL,
  `deposit` tinyint(3) DEFAULT NULL,
  `expense` tinyint(3) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transport_assign
#

DROP TABLE IF EXISTS `transport_assign`;

CREATE TABLE `transport_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `stoppage_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `transport_assign` (`id`, `route_id`, `stoppage_id`, `vehicle_id`, `branch_id`, `created_at`) VALUES (1, 1, 1, 1, 1, '2020-09-30 13:35:37');
INSERT INTO `transport_assign` (`id`, `route_id`, `stoppage_id`, `vehicle_id`, `branch_id`, `created_at`) VALUES (2, 1, 1, 2, 1, '2020-09-30 13:35:37');
INSERT INTO `transport_assign` (`id`, `route_id`, `stoppage_id`, `vehicle_id`, `branch_id`, `created_at`) VALUES (3, 2, 1, 2, 1, '2020-09-30 13:35:54');


#
# TABLE STRUCTURE FOR: transport_route
#

DROP TABLE IF EXISTS `transport_route`;

CREATE TABLE `transport_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `start_place` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `stop_place` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `transport_route` (`id`, `name`, `start_place`, `remarks`, `stop_place`, `branch_id`) VALUES (1, 'Maitama Route', 'Nile Street', '', 'Gana Street', 1);
INSERT INTO `transport_route` (`id`, `name`, `start_place`, `remarks`, `stop_place`, `branch_id`) VALUES (2, 'Utako Route', 'Shettima Monguno St.', '', 'IBM Haruna St', 1);


#
# TABLE STRUCTURE FOR: transport_stoppage
#

DROP TABLE IF EXISTS `transport_stoppage`;

CREATE TABLE `transport_stoppage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stop_position` varchar(255) NOT NULL,
  `stop_time` time NOT NULL,
  `route_fare` decimal(18,2) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `transport_stoppage` (`id`, `stop_position`, `stop_time`, `route_fare`, `branch_id`, `created_at`) VALUES (1, 'Hostel Pickup', '13:30:00', '500.00', 1, '2020-09-30 13:35:21');


#
# TABLE STRUCTURE FOR: transport_vehicle
#

DROP TABLE IF EXISTS `transport_vehicle`;

CREATE TABLE `transport_vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_no` longtext NOT NULL,
  `capacity` longtext NOT NULL,
  `insurance_renewal` longtext NOT NULL,
  `driver_name` longtext NOT NULL,
  `driver_phone` longtext NOT NULL,
  `driver_license` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `transport_vehicle` (`id`, `vehicle_no`, `capacity`, `insurance_renewal`, `driver_name`, `driver_phone`, `driver_license`, `branch_id`, `created_at`, `updated_at`) VALUES (1, '8923h32jk', '8', '2021-01-09', 'Musa Isa', '09290180380', 'Njk9y8yf7y923f', 1, '2020-09-30 13:34:07', NULL);
INSERT INTO `transport_vehicle` (`id`, `vehicle_no`, `capacity`, `insurance_renewal`, `driver_name`, `driver_phone`, `driver_license`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'k89ausdn9uasf9', '20', '2022-06-08', 'Isa Musa', '0802808216', 'Modh932rnjiw', 1, '2020-09-30 13:34:38', NULL);


#
# TABLE STRUCTURE FOR: voucher_head
#

DROP TABLE IF EXISTS `voucher_head`;

CREATE TABLE `voucher_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `system` tinyint(1) DEFAULT '0',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

