#
# TABLE STRUCTURE FOR: accounts
#

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `balance` double(18,2) NOT NULL DEFAULT '0.00',
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `accounts` (`id`, `name`, `number`, `description`, `balance`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'ACCE-Abuja GTBank', '00210310', 'Guaranty Trust Bank For ACCE-Abuja', '660000.00', 1, '2020-10-12 15:46:47', '2020-10-12 15:47:01');
INSERT INTO `accounts` (`id`, `name`, `number`, `description`, `balance`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'ACCE-Abuja Jaiz Bank', '43020480824', 'Jaiz Bank Plc. For ACCE-Abuja', '4990000.00', 1, '2020-10-12 15:47:59', '2020-10-12 15:47:59');


#
# TABLE STRUCTURE FOR: advance_salary
#

DROP TABLE IF EXISTS `advance_salary`;

CREATE TABLE `advance_salary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `deduct_month` varchar(20) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `reason` text CHARACTER SET utf32 COLLATE utf32_unicode_ci,
  `request_date` datetime DEFAULT NULL,
  `paid_date` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=pending,2=paid,3=rejected',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `issued_by` varchar(200) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `advance_salary` (`id`, `staff_id`, `amount`, `deduct_month`, `year`, `reason`, `request_date`, `paid_date`, `status`, `create_at`, `issued_by`, `comments`, `branch_id`) VALUES (1, 2, '1000.00', '02', '2021', 'Unpunctual', '2020-12-21 19:13:16', '2020-12-21 19:15:29', 3, '2020-12-21 19:13:16', '4', '', 1);


#
# TABLE STRUCTURE FOR: attachments
#

DROP TABLE IF EXISTS `attachments`;

CREATE TABLE `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `type_id` int(11) NOT NULL,
  `uploader_id` varchar(20) NOT NULL,
  `class_id` varchar(20) DEFAULT 'unfiltered',
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `subject_id` varchar(200) DEFAULT 'unfiltered',
  `session_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `attachments` (`id`, `title`, `remarks`, `type_id`, `uploader_id`, `class_id`, `file_name`, `enc_name`, `subject_id`, `session_id`, `date`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'Adnan Upload', '', 1, '1', 'unfiltered', 'acce-logo.png', 'c7fe7cd91783ab810e70b940bddafbd0.png', 'unfiltered', 3, '2020-07-15', 1, '2020-07-15 15:49:20', '2020-07-16 16:53:29');
INSERT INTO `attachments` (`id`, `title`, `remarks`, `type_id`, `uploader_id`, `class_id`, `file_name`, `enc_name`, `subject_id`, `session_id`, `date`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'AAAA', 'MP4', 2, '1', 'unfiltered', 'b7c3a3cbccb9215506163355c4e086fb.png', 'becddf6a108d24f2d0cabf462589bfdb.png', 'unfiltered', 3, '2020-10-13', 1, '2020-10-13 12:21:58', '2020-10-13 12:21:57');


#
# TABLE STRUCTURE FOR: attachments_type
#

DROP TABLE IF EXISTS `attachments_type`;

CREATE TABLE `attachments_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `attachments_type` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'PNG', 1, '2020-07-15 15:48:31', NULL);
INSERT INTO `attachments_type` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'MP4', 1, '2020-10-13 12:18:01', NULL);


#
# TABLE STRUCTURE FOR: award
#

DROP TABLE IF EXISTS `award`;

CREATE TABLE `award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `gift_item` varchar(255) NOT NULL,
  `award_amount` decimal(18,2) NOT NULL,
  `award_reason` text NOT NULL,
  `given_date` date NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: book
#

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `author` varchar(255) NOT NULL,
  `isbn_no` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `edition` varchar(255) NOT NULL,
  `purchase_date` date NOT NULL,
  `description` text NOT NULL,
  `price` decimal(18,2) NOT NULL,
  `total_stock` varchar(20) NOT NULL,
  `issued_copies` varchar(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `book` (`id`, `title`, `cover`, `author`, `isbn_no`, `category_id`, `publisher`, `edition`, `purchase_date`, `description`, `price`, `total_stock`, `issued_copies`, `created_at`, `updated_at`, `branch_id`) VALUES (1, 'The Audacity Of Hope - Barack Obama', NULL, '', '', 1, 'Barack Obama', '', '2020-07-18', '', '0.00', '1', '0', '2020-07-18 13:08:20', NULL, 1);


#
# TABLE STRUCTURE FOR: book_category
#

DROP TABLE IF EXISTS `book_category`;

CREATE TABLE `book_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `book_category` (`id`, `name`, `branch_id`) VALUES (1, 'Biography', 1);


#
# TABLE STRUCTURE FOR: book_issues
#

DROP TABLE IF EXISTS `book_issues`;

CREATE TABLE `book_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `date_of_issue` date DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `fine_amount` decimal(18,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = pending, 1 = accepted, 2 = rejected, 3 = returned',
  `issued_by` varchar(255) DEFAULT NULL,
  `return_by` int(11) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `book_issues` (`id`, `book_id`, `user_id`, `role_id`, `date_of_issue`, `date_of_expiry`, `return_date`, `fine_amount`, `status`, `issued_by`, `return_by`, `session_id`, `branch_id`, `created_at`) VALUES (1, 1, 4, 4, '2020-09-29', '2020-10-02', NULL, '0.00', 1, '1', NULL, 3, 1, '2020-09-29 14:25:05');
INSERT INTO `book_issues` (`id`, `book_id`, `user_id`, `role_id`, `date_of_issue`, `date_of_expiry`, `return_date`, `fine_amount`, `status`, `issued_by`, `return_by`, `session_id`, `branch_id`, `created_at`) VALUES (2, 1, 4, 4, '2020-12-21', '2021-01-05', NULL, '0.00', 0, '4', NULL, 3, 1, '2020-12-21 19:19:31');


#
# TABLE STRUCTURE FOR: branch
#

DROP TABLE IF EXISTS `branch`;

CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `school_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `symbol` varchar(25) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `stu_generate` tinyint(3) DEFAULT '0',
  `stu_username_prefix` varchar(255) NOT NULL,
  `stu_default_password` varchar(255) NOT NULL,
  `grd_generate` tinyint(3) DEFAULT '0',
  `grd_username_prefix` varchar(255) NOT NULL,
  `grd_default_password` varchar(255) NOT NULL,
  `teacher_restricted` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `branch` (`id`, `name`, `school_name`, `email`, `mobileno`, `currency`, `symbol`, `city`, `state`, `address`, `stu_generate`, `stu_username_prefix`, `stu_default_password`, `grd_generate`, `grd_username_prefix`, `grd_default_password`, `teacher_restricted`, `created_at`, `updated_at`) VALUES (1, 'ACCE Abuja', 'ACCE Abuja', 'info@acce-abuja.com.ng', '+2348092406828', 'NGN', '₦', 'Abuja', 'Federal Capital Territory', '', 0, '', '', 0, '', '', 1, '2020-07-15 15:21:22', NULL);


#
# TABLE STRUCTURE FOR: bulk_msg_category
#

DROP TABLE IF EXISTS `bulk_msg_category`;

CREATE TABLE `bulk_msg_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT 'sms=1, email=2',
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `bulk_msg_category` (`id`, `name`, `body`, `type`, `branch_id`) VALUES (1, 'Test', ' This is a test  from {name}  {email} -  {mobile_no} ', 1, 1);
INSERT INTO `bulk_msg_category` (`id`, `name`, `body`, `type`, `branch_id`) VALUES (2, 'Test Mail', '<p>Testing from  {name} </p>', 2, 1);


#
# TABLE STRUCTURE FOR: bulk_sms_email
#

DROP TABLE IF EXISTS `bulk_sms_email`;

CREATE TABLE `bulk_sms_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) DEFAULT NULL,
  `sms_gateway` varchar(55) DEFAULT '0',
  `message` text,
  `email_subject` varchar(255) DEFAULT NULL,
  `message_type` tinyint(3) DEFAULT '0' COMMENT 'sms=1, email=2',
  `recipient_type` tinyint(3) NOT NULL COMMENT 'group=1, individual=2, class=3',
  `recipients_details` longtext,
  `additional` longtext,
  `schedule_time` datetime DEFAULT NULL,
  `posting_status` tinyint(3) NOT NULL COMMENT 'schedule=1,competed=2',
  `total_thread` int(11) NOT NULL,
  `successfully_sent` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `bulk_sms_email` (`id`, `campaign_name`, `sms_gateway`, `message`, `email_subject`, `message_type`, `recipient_type`, `recipients_details`, `additional`, `schedule_time`, `posting_status`, `total_thread`, `successfully_sent`, `branch_id`, `created_at`) VALUES (1, 'TEsting camp', '0', '<p>Testing from  {name} </p>', 'Acce sub test', 2, 2, '', '', '2020-07-16 15:01:28', 2, 1, 0, 1, '2020-07-16 15:01:28');
INSERT INTO `bulk_sms_email` (`id`, `campaign_name`, `sms_gateway`, `message`, `email_subject`, `message_type`, `recipient_type`, `recipients_details`, `additional`, `schedule_time`, `posting_status`, `total_thread`, `successfully_sent`, `branch_id`, `created_at`) VALUES (2, 'Test Campaign', '0', '<p> {mobile_no} Testing from  {name} x   {email} </p>', 'Tester Camp', 2, 2, '', '', '2020-09-29 14:15:14', 2, 1, 0, 1, '2020-09-29 14:15:14');
INSERT INTO `bulk_sms_email` (`id`, `campaign_name`, `sms_gateway`, `message`, `email_subject`, `message_type`, `recipient_type`, `recipients_details`, `additional`, `schedule_time`, `posting_status`, `total_thread`, `successfully_sent`, `branch_id`, `created_at`) VALUES (3, 'Test Campaign', '0', '<p> {name}  {email}  {mobile_no} <br></p>', 'tester', 2, 2, '', '', '2020-10-05 11:28:52', 2, 1, 0, 1, '2020-10-05 11:28:52');
INSERT INTO `bulk_sms_email` (`id`, `campaign_name`, `sms_gateway`, `message`, `email_subject`, `message_type`, `recipient_type`, `recipients_details`, `additional`, `schedule_time`, `posting_status`, `total_thread`, `successfully_sent`, `branch_id`, `created_at`) VALUES (4, 'holiday', '0', '<p>rer<br></p>', 'sfgddf', 2, 1, '{\"role\":[\"2\"]}', '', '2021-01-15 13:45:00', 2, 2, 0, 1, '2021-01-15 13:39:58');


#
# TABLE STRUCTURE FOR: card_templete
#

DROP TABLE IF EXISTS `card_templete`;

CREATE TABLE `card_templete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_type` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `background` varchar(355) DEFAULT NULL,
  `logo` varchar(355) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `layout_width` varchar(11) NOT NULL DEFAULT '54',
  `layout_height` varchar(11) NOT NULL DEFAULT '86',
  `photo_style` tinyint(1) NOT NULL,
  `photo_size` varchar(25) NOT NULL,
  `top_space` varchar(25) NOT NULL,
  `bottom_space` varchar(25) NOT NULL,
  `right_space` varchar(25) NOT NULL,
  `left_space` varchar(25) NOT NULL,
  `qr_code` varchar(25) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `card_templete` (`id`, `card_type`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `layout_width`, `layout_height`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (1, 1, 'Student ID', 1, 'acce-logo2.png', 'logo_1.jpg', '', '<p> {name}  {gender}  {father_name}  {mother_name}  {student_photo}  {register_no}  {roll}  {admission_date}  {class}  {section}  {category}  {caste}  {religion}  {blood_group}  {birthday}  {email}  {mobileno}  {present_address}  {permanent_address}  {logo}  {signature}  {qr_code}  {institute_name}  {institute_email}  {institute_address}  {institute_mobile_no}  {print_date}  {expiry_date} <br></p>', '85.60', '53.98', 1, '100', '15', '15', '15', '15', 'register_no', 1, '2020-10-05 10:58:27');
INSERT INTO `card_templete` (`id`, `card_type`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `layout_width`, `layout_height`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (2, 1, 'Staff ID', 2, 'acce-logo3.png', 'logo.jpg', 'stamp1.png', '<p style=\"text-align: right; border-radius: 50%; height: 20%; width: auto;\"> {staff_photo} <br></p><p style=\"text-align: left;\"><br></p><p style=\"text-align: left;\">Name :  {name}</p><p style=\"text-align: left;\">Email :  {email} </p><p>Department: {department}<br></p><p>Phone : {mobileno}<br></p><p style=\"text-align: right; \"> {signature} <br></p><p style=\"text-align: right; \">{qr_code}<br></p><p style=\"text-align: right; \"> {institute_email} </p>', '85.60', '53.98', 1, '100', '15', '15', '15', '15', 'staff_id', 1, '2020-10-05 11:23:32');
INSERT INTO `card_templete` (`id`, `card_type`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `layout_width`, `layout_height`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (3, 1, 'Staff ID (Back)', 2, '', 'logo1.png', 'stamp.png', '<p style=\"text-align: center; \"> {logo}</p><p style=\"text-align: center; \">{qr_code} </p><p style=\"text-align: center;\">{signature}</p><div style=\"text-align: center; \"> {print_date} -  {expiry_date} <br></div>', '85.60', '53.98', 2, '15', '0', '0', '0', '0', 'staff_id', 1, '2020-10-08 13:07:58');


#
# TABLE STRUCTURE FOR: certificates_templete
#

DROP TABLE IF EXISTS `certificates_templete`;

CREATE TABLE `certificates_templete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `background` varchar(355) DEFAULT NULL,
  `logo` varchar(355) DEFAULT NULL,
  `signature` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `page_layout` tinyint(1) NOT NULL,
  `photo_style` tinyint(1) NOT NULL,
  `photo_size` varchar(25) NOT NULL,
  `top_space` varchar(25) NOT NULL,
  `bottom_space` varchar(25) NOT NULL,
  `right_space` varchar(25) NOT NULL,
  `left_space` varchar(25) NOT NULL,
  `qr_code` varchar(25) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `certificates_templete` (`id`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `page_layout`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (1, 'Test Cert', 1, 'acce-logo.png', 'acce-logo-removebg-preview.png', 'acce-logo-removebg-preview1.png', '<p> {name}  {gender}  {father_name}  {mother_name}  {student_photo}  {register_no}  {roll}  {admission_date}  {class}  {section}  {category}  {caste}  {religion}  {birthday}  {email}  {mobileno}  {present_address}  {logo}  {signature}  {institute_email}  {institute_address}  {institute_mobile_no}  {print_date} <br></p>', 1, 1, '100', '5', '5', '5', '5', 'register_no', 1, '2020-07-16 15:54:56');
INSERT INTO `certificates_templete` (`id`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `page_layout`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (2, 'Al-Ansar Foundation', 2, 'acce-logo1.png', 'logo.png', 'Signature.png', '<p>The name&nbsp; {name} of&nbsp; {department} and designation&nbsp; {designation},&nbsp; {department},&nbsp; {staff_photo},&nbsp; {staff_id}.</p><p><br></p><p> {qr_code} <br></p>', 2, 2, '100', '5', '5', '5', '5', 'staff_id', 1, '2020-10-05 10:46:29');


#
# TABLE STRUCTURE FOR: class
#

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_numeric` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (1, 'Primary 3', '3', '2020-07-15 15:35:11', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (2, 'Primary 2', '2', '2020-07-15 15:36:42', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (4, 'Primary 1', '1', '2020-09-29 12:51:49', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (5, 'Reception', '0', '2020-09-29 12:52:04', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (7, 'Nursery 1', '1', '2020-09-29 12:52:57', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (8, 'Nursery 2', '2', '2020-09-29 12:53:12', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (13, 'JS 2', '2', '2020-09-29 12:54:52', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (14, 'JS 1', '1', '2020-09-29 12:55:06', NULL, 1);


#
# TABLE STRUCTURE FOR: custom_field
#

DROP TABLE IF EXISTS `custom_field`;

CREATE TABLE `custom_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_to` varchar(50) DEFAULT NULL,
  `field_label` varchar(100) NOT NULL,
  `default_value` text,
  `field_type` enum('text','textarea','dropdown','date','checkbox','number','url','email') NOT NULL,
  `required` varchar(5) NOT NULL DEFAULT 'false',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `show_on_table` varchar(5) DEFAULT NULL,
  `field_order` int(11) NOT NULL,
  `bs_column` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `custom_field` (`id`, `form_to`, `field_label`, `default_value`, `field_type`, `required`, `status`, `show_on_table`, `field_order`, `bs_column`, `branch_id`, `created_at`) VALUES (1, 'parents', 'Complaints, Suggestions or Feedback', 'Complaints, Suggestions or Feedback', 'textarea', '0', 1, '1', 1, 8, 1, '2020-11-06 14:26:16');


#
# TABLE STRUCTURE FOR: custom_fields_values
#

DROP TABLE IF EXISTS `custom_fields_values`;

CREATE TABLE `custom_fields_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: email_config
#

DROP TABLE IF EXISTS `email_config`;

CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) NOT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_user` varchar(255) DEFAULT NULL,
  `smtp_pass` varchar(255) DEFAULT NULL,
  `smtp_port` varchar(100) DEFAULT NULL,
  `smtp_encryption` varchar(10) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `email_config` (`id`, `email`, `protocol`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `smtp_encryption`, `branch_id`) VALUES (1, 'it@acce-abuja.com.ng', 'smtp', 'smtp.gmail.com', 'admin@acce-abuja.com.ng', 'acceabuja2020', '587', 'tls', 1);


#
# TABLE STRUCTURE FOR: email_templates
#

DROP TABLE IF EXISTS `email_templates`;

CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (1, 'account_registered', '{institute_name}, {name}, {login_username}, {password}, {user_role}, {login_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (2, 'forgot_password', '{institute_name}, {username}, {email}, {reset_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (3, 'change_password', '{institute_name}, {username}, {email}, {password}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (4, 'new_message_received', '{institute_name}, {recipient}, {message}, {message_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (5, 'payslip_generated', '{institute_name}, {username}, {month_year}, {payslip_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (6, 'award', '{institute_name}, {winner_name}, {award_name}, {gift_item}, {award_reason}, {given_date}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (7, 'leave_approve', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (8, 'leave_reject', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (9, 'advance_salary_approve', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (10, 'advance_salary_reject', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');


#
# TABLE STRUCTURE FOR: email_templates_details
#

DROP TABLE IF EXISTS `email_templates_details`;

CREATE TABLE `email_templates_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `template_body` text NOT NULL,
  `notified` tinyint(1) NOT NULL DEFAULT '1',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `email_templates_details` (`id`, `template_id`, `subject`, `template_body`, `notified`, `branch_id`) VALUES (1, 1, 'Your Account Has Been Registered on {institute_name} Portal', '<p>Hello {name},</p><p><br></p><p>Your Login Details for {institute_name} are below</p><p>Username : {<span xss=removed>login_username</span>}</p><p>Password : {<span xss=removed>password</span>}</p><p>as a {<span xss=removed>user_role</span>}.</p><p><br></p><p>Login URL : {login_url}</p>', 1, 1);


#
# TABLE STRUCTURE FOR: enroll
#

DROP TABLE IF EXISTS `enroll`;

CREATE TABLE `enroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `roll` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` tinyint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `enroll` (`id`, `student_id`, `class_id`, `section_id`, `roll`, `session_id`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 3, 14, 2, 0, 4, 1, '2020-11-14 15:21:22', NULL);


#
# TABLE STRUCTURE FOR: event
#

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remark` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` text NOT NULL,
  `audition` longtext NOT NULL,
  `selected_list` longtext NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `show_web` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `event` (`id`, `title`, `remark`, `status`, `type`, `audition`, `selected_list`, `start_date`, `end_date`, `image`, `created_by`, `created_at`, `updated_at`, `branch_id`, `show_web`) VALUES (1, 'Mathematics Midterm', '<p>Maths Midterms</p>', 1, '2', '1', 'null', '2020-09-29', '2020-10-01', 'AL-ANSAR_NEWS_BULLETIN-page-0.jpg', '1', '2020-09-29 14:18:11', NULL, 1, 0);
INSERT INTO `event` (`id`, `title`, `remark`, `status`, `type`, `audition`, `selected_list`, `start_date`, `end_date`, `image`, `created_by`, `created_at`, `updated_at`, `branch_id`, `show_web`) VALUES (2, 'ACCE invites GFX for advanced employee training', '<p xss=removed><strong>Introduction</strong></p><p xss=removed>Senior employees in Employee Relations- Human Resources or Personnel and Administration who are directly or indirectly responsible for supporting employees while protecting the organization.</p><p xss=removed><strong>Objectives</strong></p><ul xss=removed><li xss=removed>Define Employee Relations from a legal perspective and link it with the labor law.</li><li xss=removed>Use the legal and ethical approach in dealing with personal issues of employees.</li><li xss=removed>Conduct reliable opinion surveys aimed at assessing organizational health.</li><li xss=removed>Provide tangible support to other HR functions in establishing and implementing a fair performance management culture.</li><li xss=removed>Implement a recognition system aimed at enhancing employee retention.</li><li xss=removed>List the main steps in dispute resolutions and use them to protect both employees and the organization.</li><li xss=removed>Establish a code of conduct and compliance culture in the organization.</li></ul><p xss=removed><strong>Contents</strong></p><p xss=removed><strong>Day One</strong></p><p xss=removed><strong>Understanding Employee Relations (ER)</strong></p><ul xss=removed><li xss=removed>The Importance of Knowing the Labor Law</li><li xss=removed>The Labor Law Definition of Employee Relations</li><li xss=removed>Employee Rights and Responsibilities</li><li xss=removed>Accountabilities for Employers and Organizations</li><li xss=removed>The Importance of Balancing Rights of Both Parties</li></ul><p xss=removed><strong>?Day Two</strong></p><p xss=removed><strong>Managing Personal Issues</strong></p><ul xss=removed><li xss=removed>The Definition of a Personal Issue</li><li xss=removed>Deciding on Counseling Tactics</li><li xss=removed>The Importance of Drawing the Line between Coaching and Counseling</li><li xss=removed>Approaches to Counseling</li><li xss=removed>Providing Counsel without Harming Organizational Interests and Accountabilities</li><li xss=removed>When to Avoid or Refuse Providing Counsel</li><li xss=removed>The Responsibilities of ER Counselors</li></ul><p xss=removed><strong>?Day Three</strong></p><p xss=removed><strong>Employee Surveys</strong></p><ul xss=removed><li xss=removed>The Difference between Opinion and Morale Surveys</li><li xss=removed>Approaches to Measuring Morale Surveys</li><li xss=removed>The Use of Subjective and Objective Data</li><li xss=removed>The Main Key Performance Indicators in Morale Surveys</li><li xss=removed>Establishing an Employee Morale Index</li></ul><p xss=removed><strong>Performance Management (PM)</strong></p><ul xss=removed><li xss=removed>The Role of ER in Managing Performance</li><li xss=removed>The Components of a Fair Performance Management System</li><li xss=removed>Measuring the Tangibles: How to Use Goals and Targets in a PM System</li><li xss=removed>Measuring the Intangibles: The Role of Competencies and Values in Measuring Performance</li></ul><p xss=removed><strong>?Day Four</strong></p><p xss=removed><strong>Employee Recognition</strong></p><ul xss=removed><li xss=removed>The Essentials of a Recognition Program</li><li xss=removed>Tangible and Intangible Rewards</li><li xss=removed>Linking Performance with Pay: The Role of ER</li><li xss=removed>Dealing with Underperformers</li></ul><p xss=removed><strong>Dispute Resolution</strong></p><ul xss=removed><li xss=removed>The Definition of a Dispute</li><li xss=removed>Differences between Disputes - Conflicts and Differences of Opinion</li><li xss=removed>What the Labor Law Says about Disputes</li><li xss=removed>The Policy and Procedure for Dispute Resolution</li><li xss=removed>The Main Steps in Resolving Disputes</li><li xss=removed>Escalating Disputes: What to Do When Disputes Are Irreconcilable</li></ul><p xss=removed><strong>?Day Five</strong></p><p xss=removed><strong>Employee Grievances</strong></p><ul xss=removed><li xss=removed>The definition of a grievance</li><li xss=removed>Grievances versus complaints versus whining</li><li xss=removed>The grievance handling procedures: recommended steps</li><li xss=removed>Grievance rate and grievance resolution rate</li><li xss=removed>The main KPIs for measuring your grievance resolution ratio</li></ul><p xss=removed><strong>Codes of Conduct and Compliance</strong></p><ul xss=removed><li xss=removed>The Definition of a Code of Conduct</li><li xss=removed>The Role of ER in Establishing Codes of Conduct</li><li xss=removed>The Main Sections in a Code of Conduct Manual</li><li xss=removed>Compliance Issues: The Role of ER</li></ul>', 1, 'holiday', '1', 'null', '2020-11-06', '2020-11-12', 'gfx-logo.png', '1', '2020-11-06 14:40:46', NULL, 1, 0);


#
# TABLE STRUCTURE FOR: event_types
#

DROP TABLE IF EXISTS `event_types`;

CREATE TABLE `event_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `icon` varchar(200) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `event_types` (`id`, `name`, `icon`, `branch_id`) VALUES (1, 'PTA', 'users', 1);
INSERT INTO `event_types` (`id`, `name`, `icon`, `branch_id`) VALUES (2, 'Midterm Examination', 'concierge-bell', 1);


#
# TABLE STRUCTURE FOR: exam
#

DROP TABLE IF EXISTS `exam`;

CREATE TABLE `exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `term_id` int(11) DEFAULT NULL,
  `type_id` tinyint(4) NOT NULL COMMENT '1=mark,2=gpa,3=both',
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `remark` text NOT NULL,
  `mark_distribution` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: exam_attendance
#

DROP TABLE IF EXISTS `exam_attendance`;

CREATE TABLE `exam_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `status` varchar(4) DEFAULT NULL COMMENT 'P=Present, A=Absent, L=Late',
  `remark` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: exam_hall
#

DROP TABLE IF EXISTS `exam_hall`;

CREATE TABLE `exam_hall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hall_no` longtext NOT NULL,
  `seats` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (1, '2', 50, 1);
INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (2, '12', 38, 1);


#
# TABLE STRUCTURE FOR: exam_mark_distribution
#

DROP TABLE IF EXISTS `exam_mark_distribution`;

CREATE TABLE `exam_mark_distribution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: exam_term
#

DROP TABLE IF EXISTS `exam_term`;

CREATE TABLE `exam_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (1, 'Mid-Term', 1, 3);
INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (2, 'First Term', 1, 3);


#
# TABLE STRUCTURE FOR: fee_allocation
#

DROP TABLE IF EXISTS `fee_allocation`;

CREATE TABLE `fee_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `fee_allocation` (`id`, `student_id`, `group_id`, `branch_id`, `session_id`, `created_at`) VALUES (3, 2, 1, 1, 3, '2020-11-06 14:48:58');
INSERT INTO `fee_allocation` (`id`, `student_id`, `group_id`, `branch_id`, `session_id`, `created_at`) VALUES (4, 4, 3, 1, 3, '2021-01-17 22:25:29');
INSERT INTO `fee_allocation` (`id`, `student_id`, `group_id`, `branch_id`, `session_id`, `created_at`) VALUES (5, 10, 3, 1, 3, '2021-01-17 22:25:29');
INSERT INTO `fee_allocation` (`id`, `student_id`, `group_id`, `branch_id`, `session_id`, `created_at`) VALUES (6, 11, 3, 1, 3, '2021-01-17 22:25:29');


#
# TABLE STRUCTURE FOR: fee_fine
#

DROP TABLE IF EXISTS `fee_fine`;

CREATE TABLE `fee_fine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `fine_value` varchar(20) NOT NULL,
  `fine_type` varchar(20) NOT NULL,
  `fee_frequency` varchar(20) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fee_fine` (`id`, `group_id`, `type_id`, `fine_value`, `fine_type`, `fee_frequency`, `branch_id`, `session_id`) VALUES (1, 1, 1, '8000', '1', '0', 1, 3);


#
# TABLE STRUCTURE FOR: fee_groups
#

DROP TABLE IF EXISTS `fee_groups`;

CREATE TABLE `fee_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `fee_groups` (`id`, `name`, `description`, `session_id`, `branch_id`, `created_at`) VALUES (3, 'Tuition Fees', '', 3, 1, '2021-01-17 22:20:20');


#
# TABLE STRUCTURE FOR: fee_groups_details
#

DROP TABLE IF EXISTS `fee_groups_details`;

CREATE TABLE `fee_groups_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fee_groups_id` int(11) NOT NULL,
  `fee_type_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (3, 3, 1, '900000.00', '2021-01-18', '2021-01-17 22:20:20');


#
# TABLE STRUCTURE FOR: fee_payment_history
#

DROP TABLE IF EXISTS `fee_payment_history`;

CREATE TABLE `fee_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `allocation_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `collect_by` varchar(20) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL,
  `fine` decimal(18,2) NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `remarks` longtext NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (1, 1, 1, '1', '75000.00', '0.00', '0.00', '2', '', '2020-09-29');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (2, 2, 1, '4', '75000.00', '0.00', '2000.00', '2', '', '2020-10-12');


#
# TABLE STRUCTURE FOR: fees_reminder
#

DROP TABLE IF EXISTS `fees_reminder`;

CREATE TABLE `fees_reminder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `frequency` varchar(255) NOT NULL,
  `days` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `student` tinyint(3) NOT NULL,
  `guardian` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `fees_reminder` (`id`, `frequency`, `days`, `message`, `student`, `guardian`, `branch_id`, `created_at`) VALUES (1, 'before', '2', '{guardian_name} abeg test {child_name} on  {due_date} for  {due_amount} and  {fee_type}', 1, 1, 1, '2020-09-29 12:45:37');
INSERT INTO `fees_reminder` (`id`, `frequency`, `days`, `message`, `student`, `guardian`, `branch_id`, `created_at`) VALUES (2, 'after', '3', 'Your child has been missing classes {child_name} , due date is.  {fee_type}  {due_amount}  {due_date}', 1, 1, 1, '2020-12-21 19:21:12');
INSERT INTO `fees_reminder` (`id`, `frequency`, `days`, `message`, `student`, `guardian`, `branch_id`, `created_at`) VALUES (3, 'before', '30', 'y7', 1, 1, 1, '2021-01-17 22:17:52');


#
# TABLE STRUCTURE FOR: fees_type
#

DROP TABLE IF EXISTS `fees_type`;

CREATE TABLE `fees_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `fee_code` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `created_at`) VALUES (1, 'Tuition Fees', 'tuition-fees', 'Terminal Tuition Fees', 1, '2020-09-29 12:21:26');
INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `created_at`) VALUES (2, 'Excursion Fees', 'excursion-fees', '', 1, '2020-12-21 19:22:14');


#
# TABLE STRUCTURE FOR: front_cms_about
#

DROP TABLE IF EXISTS `front_cms_about`;

CREATE TABLE `front_cms_about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `about_image` varchar(255) NOT NULL,
  `elements` mediumtext NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_about` (`id`, `title`, `subtitle`, `page_title`, `content`, `banner_image`, `about_image`, `elements`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Welcome to School', 'Best Education Mangment Systems', 'About Us', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut volutpat rutrum eros amet sollicitudin interdum. Suspendisse pulvinar, velit nec pharetra interdum, ante tellus ornare mi, et mollis tellus neque vitae elit. Mauris adipiscing mauris fringilla turpis interdum sed pulvinar nisi malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit.\r\n                        </p>\r\n                        <p>\r\n                            Donec sed odio dui. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula. Mauris sit amet neque nec nunc gravida. \r\n                        </p>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-sm-6 col-12\">\r\n                                <ul class=\"list-unstyled list-style-3\">\r\n                                    <li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n                                    <li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n                                    <li><a href=\"#\">Ophthalmology</a></li>\r\n                                    <li><a href=\"#\">Dermitology</a></li>\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"col-sm-6 col-12\">\r\n                                <ul class=\"list-unstyled list-style-3\">\r\n                                    <li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n                                    <li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n                                    <li><a href=\"#\">Ophthalmology</a></li>\r\n                                </ul>\r\n                            </div>\r\n                        </div>', 'about1.jpg', 'about1.png', '{\"cta_title\":\"Get in touch to join our community\",\"button_text\":\"Contact Our Office\",\"button_url\":\"contact\"}', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_admission
#

DROP TABLE IF EXISTS `front_cms_admission`;

CREATE TABLE `front_cms_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_admission` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Make An Admission', '<p>Lorem ipsum dolor sit amet, eum illum dolore concludaturque ex, ius latine adipisci no. Pro at nullam laboramus definitiones. Mandamusconceptam omittantur cu cum. Brute appetere it scriptorem ei eam, ne vim velit novum nominati. Causae volutpat percipitur at sed ne.</p>\r\n', 'Admission', 'admission1.jpg', 'Ramom - School Management System With CMS', 'Ramom  Admission Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_contact
#

DROP TABLE IF EXISTS `front_cms_contact`;

CREATE TABLE `front_cms_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `box_title` varchar(255) DEFAULT NULL,
  `box_description` varchar(500) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `form_title` varchar(355) DEFAULT NULL,
  `address` varchar(355) DEFAULT NULL,
  `phone` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `submit_text` varchar(355) NOT NULL,
  `map_iframe` text,
  `page_title` varchar(255) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_contact` (`id`, `box_title`, `box_description`, `box_image`, `form_title`, `address`, `phone`, `email`, `submit_text`, `map_iframe`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'WE\'D LOVE TO HEAR FROM YOU', 'Fusce convallis diam vitae velit tempus rutrum. Donec nisl nisl, vulputate eu sapien sed, adipiscing vehicula massa. Mauris eget commodo neque, id molestie enim.', 'contact-info-box1.png', 'Get in touch by filling the form below', '4896  Romrog Way, LOS ANGELES,\r\nCalifornia', '123-456-7890, \r\n123-456-7890', 'info@example.com\r\nsupport@example.com', 'Send', NULL, 'Contact Us', 'contact1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_events
#

DROP TABLE IF EXISTS `front_cms_events`;

CREATE TABLE `front_cms_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_events` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Upcoming Events', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p><p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.</p>', 'Events', 'events1.jpg', 'Ramom - School Management System With CMS', 'Ramom Events Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq
#

DROP TABLE IF EXISTS `front_cms_faq`;

CREATE TABLE `front_cms_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_faq` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Frequently Asked Questions', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p>\r\n\r\n<p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven&#39;t heard of them accusamus labore sustainable VHS.</p>', 'Faq', 'faq1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq_list
#

DROP TABLE IF EXISTS `front_cms_faq_list`;

CREATE TABLE `front_cms_faq_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (1, 'Any Information you provide on applications for disability, life or accidental insurance ?', '<p>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n</p>\r\n<ul>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Sed do eiusmod tempor incididunt ut labore et dolore magna aliq.</li>\r\n<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact.</li>\r\n<li>That a reader will be distracted by the readable content of a page when looking at its layout.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</li>\r\n<li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n<li>Readable content of a page when looking at its layout.</li>\r\n<li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n<li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n</ul>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (2, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (3, 'Opposed to using \'Content here, content here\', making it look like readable English ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (4, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (5, 'What types of documents are required to travel?', '<p><strong>Lorem ipsum</strong> dolor sit amet, an labores explicari qui, eu nostrum copiosae argumentum has. Latine propriae quo no, unum ridens expetenda id sit, at usu eius eligendi singulis. Sea ocurreret principes ne. At nonumy aperiri pri, nam quodsi copiosae intellegebat et, ex deserunt euripidis usu. Per ad ullum lobortis. Duo volutpat imperdiet ut, postea salutatus imperdiet ut per, ad utinam debitis invenire has.</p>\r\n\r\n<ol>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari quilabores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n</ol>', 1);


#
# TABLE STRUCTURE FOR: front_cms_home
#

DROP TABLE IF EXISTS `front_cms_home`;

CREATE TABLE `front_cms_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `item_type` varchar(20) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `elements` mediumtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `active` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (1, 'Welcome To Education', 'We will give you future', 'wellcome', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using content.\r\n\r\nMaking it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '{\"image\":\"wellcome1.png\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (2, 'Experience Teachers Team', NULL, 'teachers', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident.', '{\"teacher_start\":\"0\",\"image\":\"featured-parallax1.jpg\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (3, 'WHY CHOOSE US', NULL, 'services', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (4, 'Request for a free Education Class', NULL, 'cta', '', '{\"mobile_no\":\"+1-12345678\",\"button_text\":\"Request Now\",\"button_url\":\"#\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (5, 'Wellcome To <span>ACCE</span>', NULL, 'slider', 'Lorem Ipsum is simply dummy text printer took a galley of type and scrambled it to make a type specimen book.', '{\"position\":\"c-left\",\"button_text1\":\"View Services\",\"button_url1\":\"#\",\"button_text2\":\"Learn More\",\"button_url2\":\"#\",\"image\":\"home-slider-1592582779.jpg\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (6, 'Online  <span>Live Class</span> Facility', NULL, 'slider', 'Lorem Ipsum is simply dummy text printer took a galley of type and scrambled it to make a type specimen book.', '{\"position\":\"c-left\",\"button_text1\":\"Read More\",\"button_url1\":\"#\",\"button_text2\":\"Get Started\",\"button_url2\":\"#\",\"image\":\"home-slider-1592582805.jpg\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (8, 'Online Classes', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-video\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (9, 'Scholarship', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-graduation-cap\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (10, 'Books & Liberary', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-book-reader\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (11, 'Trending Courses', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fab fa-discourse\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (12, 'WHAT PEOPLE SAYS', NULL, 'testimonial', 'Fusce sem dolor, interdum in efficitur at, faucibus nec lorem. Sed nec molestie justo.', '', 1, 0);


#
# TABLE STRUCTURE FOR: front_cms_home_seo
#

DROP TABLE IF EXISTS `front_cms_home_seo`;

CREATE TABLE `front_cms_home_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_home_seo` (`id`, `page_title`, `meta_keyword`, `meta_description`, `branch_id`) VALUES (1, 'Home', 'School Home Page', 'Copyright Info', 1);


#
# TABLE STRUCTURE FOR: front_cms_menu
#

DROP TABLE IF EXISTS `front_cms_menu`;

CREATE TABLE `front_cms_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `ordering` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `open_new_tab` int(11) NOT NULL DEFAULT '0',
  `ext_url` tinyint(3) NOT NULL DEFAULT '0',
  `ext_url_address` text,
  `publish` tinyint(3) NOT NULL,
  `system` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (1, 'Home', 'index', 1, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (2, 'Events', 'events', 3, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (3, 'Teachers', 'teachers', 2, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (4, 'About Us', 'about', 4, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (5, 'FAQ', 'faq', 5, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (6, 'Online Admission', 'admission', 6, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (7, 'Contact Us', 'contact', 7, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');


#
# TABLE STRUCTURE FOR: front_cms_pages
#

DROP TABLE IF EXISTS `front_cms_pages`;

CREATE TABLE `front_cms_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: front_cms_services
#

DROP TABLE IF EXISTS `front_cms_services`;

CREATE TABLE `front_cms_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `parallax_image` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_services` (`id`, `title`, `subtitle`, `parallax_image`, `branch_id`) VALUES (1, 'Get Well Soon', 'Our Best <span>Services</span>', 'service_parallax1.jpg', 1);


#
# TABLE STRUCTURE FOR: front_cms_services_list
#

DROP TABLE IF EXISTS `front_cms_services_list`;

CREATE TABLE `front_cms_services_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (1, 'Online Course Facilities', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text.', 'fas fa-headphones', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (2, 'Modern Book Library', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover.', 'fas fa-book-open', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (3, 'Be Industrial Leader', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model.', 'fas fa-industry', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (4, 'Programming Courses', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will.', 'fas fa-code', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (5, 'Foreign Languages', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover.', 'fas fa-language', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (6, 'Alumni Directory', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a for \'lorem ipsum\' will uncover.', 'fas fa-user-graduate', 1);


#
# TABLE STRUCTURE FOR: front_cms_setting
#

DROP TABLE IF EXISTS `front_cms_setting`;

CREATE TABLE `front_cms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_title` varchar(255) NOT NULL,
  `url_alias` varchar(255) DEFAULT NULL,
  `cms_active` tinyint(4) NOT NULL DEFAULT '0',
  `online_admission` tinyint(4) NOT NULL DEFAULT '0',
  `theme` varchar(255) NOT NULL,
  `captcha_status` varchar(20) NOT NULL,
  `recaptcha_site_key` varchar(255) NOT NULL,
  `recaptcha_secret_key` varchar(255) NOT NULL,
  `address` varchar(350) NOT NULL,
  `mobile_no` varchar(60) NOT NULL,
  `fax` varchar(60) NOT NULL,
  `receive_contact_email` varchar(255) NOT NULL,
  `email` varchar(60) NOT NULL,
  `copyright_text` varchar(255) NOT NULL,
  `fav_icon` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `footer_about_text` varchar(300) NOT NULL,
  `working_hours` varchar(300) NOT NULL,
  `facebook_url` varchar(100) NOT NULL,
  `twitter_url` varchar(100) NOT NULL,
  `youtube_url` varchar(100) NOT NULL,
  `google_plus` varchar(100) NOT NULL,
  `linkedin_url` varchar(100) NOT NULL,
  `pinterest_url` varchar(100) NOT NULL,
  `instagram_url` varchar(100) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_setting` (`id`, `application_title`, `url_alias`, `cms_active`, `online_admission`, `theme`, `captcha_status`, `recaptcha_site_key`, `recaptcha_secret_key`, `address`, `mobile_no`, `fax`, `receive_contact_email`, `email`, `copyright_text`, `fav_icon`, `logo`, `footer_about_text`, `working_hours`, `facebook_url`, `twitter_url`, `youtube_url`, `google_plus`, `linkedin_url`, `pinterest_url`, `instagram_url`, `branch_id`) VALUES (1, 'School Management System With CMS', 'example', 0, 1, 'red', 'disable', '', '', 'Your Address', '+12345678', '12345678', 'info@example.com', 'info@demo.com', 'Copyright © 2020 <span>Ramom</span>. All Rights Reserved.', 'fav_icon1.png', 'logo1.png', 'If you are going to use a passage LorIsum, you anythirassing hidden in the middle of text. Lators on the Internet tend to.', '<span>Hours : </span>  Mon To Fri - 10AM - 04PM,  Sunday Closed', 'https://facebook.com', 'https://twitter.com', 'https://youtube.com', 'https://google.com', 'https://linkedin.com', 'https://pinterest.com', 'https://instagram.com', 1);


#
# TABLE STRUCTURE FOR: front_cms_teachers
#

DROP TABLE IF EXISTS `front_cms_teachers`;

CREATE TABLE `front_cms_teachers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_teachers` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Teachers', 'teachers1.jpg', 'ACCE PORTAL', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_testimonial
#

DROP TABLE IF EXISTS `front_cms_testimonial`;

CREATE TABLE `front_cms_testimonial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `surname` varchar(355) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rank` int(5) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (1, 'Gartrell Wright', 'Los Angeles', 'user-1582830398.jpg', 'Intexure have done an excellent job presenting the analysis & insights. I am confident in saying  have helped encounter  is to be welcomed and every pain avoided”.', 1, 1, 1, '2019-08-23 13:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (2, 'Clifton Hyde', 'Newyork City', 'defualt.png', '“Owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted always holds”.', 4, 1, 1, '2019-08-23 13:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (3, 'Emily Lemus', 'Los Angeles', 'defualt.png', '“Intexure have done an excellent job presenting the analysis & insights. I am confident in saying  have helped encounter  is to be welcomed and every pain avoided”.', 5, 1, 1, '2019-08-23 13:26:42');


#
# TABLE STRUCTURE FOR: global_settings
#

DROP TABLE IF EXISTS `global_settings`;

CREATE TABLE `global_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institute_name` varchar(255) NOT NULL,
  `institution_code` varchar(255) NOT NULL,
  `reg_prefix` varchar(255) NOT NULL,
  `institute_email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `currency_symbol` varchar(100) NOT NULL,
  `sms_service_provider` varchar(100) NOT NULL,
  `session_id` int(11) NOT NULL,
  `translation` varchar(100) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `animations` varchar(100) NOT NULL,
  `timezone` varchar(100) NOT NULL,
  `date_format` varchar(100) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `linkedin_url` varchar(255) NOT NULL,
  `youtube_url` varchar(255) NOT NULL,
  `cron_secret_key` varchar(255) DEFAULT NULL,
  `preloader_backend` tinyint(1) DEFAULT '1',
  `cms_default_branch` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `global_settings` (`id`, `institute_name`, `institution_code`, `reg_prefix`, `institute_email`, `address`, `mobileno`, `currency`, `currency_symbol`, `sms_service_provider`, `session_id`, `translation`, `footer_text`, `animations`, `timezone`, `date_format`, `facebook_url`, `twitter_url`, `linkedin_url`, `youtube_url`, `cron_secret_key`, `preloader_backend`, `cms_default_branch`, `created_at`, `updated_at`) VALUES (1, 'ACCE Abuja', 'ACCE-', 'on', 'ramom@example.com', 'Plot 81 Kafe District, Opposite Maija Plaza, Adjacent Saraha Estate, Gwarinpa, Abuja.', '(+234) 804-568-90', 'NGN', '₦', 'disabled', 3, 'english', 'All Rights Reserved © Copyright 2020 ACCE-Abuja', 'fadeInUp', 'Africa/Lagos', 'd.M.Y', '', '', '', '', 'dafe95d487bb3ef0ee5a759136c796b6', 1, 1, '2018-10-22 10:07:49', '2020-05-01 22:37:06');


#
# TABLE STRUCTURE FOR: grade
#

DROP TABLE IF EXISTS `grade`;

CREATE TABLE `grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `grade_point` varchar(255) NOT NULL,
  `lower_mark` int(11) NOT NULL,
  `upper_mark` int(11) NOT NULL,
  `remark` text NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: hall_allocation
#

DROP TABLE IF EXISTS `hall_allocation`;

CREATE TABLE `hall_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `hall_no` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: homework
#

DROP TABLE IF EXISTS `homework`;

CREATE TABLE `homework` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `date_of_homework` date NOT NULL,
  `date_of_submission` date NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `sms_notification` tinyint(2) NOT NULL,
  `schedule_date` date DEFAULT NULL,
  `document` varchar(255) NOT NULL,
  `evaluation_date` date DEFAULT NULL,
  `evaluated_by` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: homework_evaluation
#

DROP TABLE IF EXISTS `homework_evaluation`;

CREATE TABLE `homework_evaluation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homework_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `remark` text NOT NULL,
  `rank` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: hostel
#

DROP TABLE IF EXISTS `hostel`;

CREATE TABLE `hostel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `category_id` int(11) NOT NULL,
  `address` longtext NOT NULL,
  `watchman` longtext NOT NULL,
  `remarks` longtext,
  `branch_id` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `hostel` (`id`, `name`, `category_id`, `address`, `watchman`, `remarks`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'Red Hostel', 1, 'Apo', 'Bashir Ahmed', 'Near Gudu', 1, '2020-09-30 13:16:59', NULL);
INSERT INTO `hostel` (`id`, `name`, `category_id`, `address`, `watchman`, `remarks`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'Barau Dikko House', 2, 'Katampe', 'Dawisu', 'Near Guzape Ext', 1, '2020-09-30 13:17:50', NULL);


#
# TABLE STRUCTURE FOR: hostel_category
#

DROP TABLE IF EXISTS `hostel_category`;

CREATE TABLE `hostel_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `description` longtext,
  `branch_id` int(11) DEFAULT NULL,
  `type` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `hostel_category` (`id`, `name`, `description`, `branch_id`, `type`, `created_at`, `updated_at`) VALUES (1, 'Junior', '', 1, 'hostel', '2020-09-30 13:14:20', NULL);
INSERT INTO `hostel_category` (`id`, `name`, `description`, `branch_id`, `type`, `created_at`, `updated_at`) VALUES (2, 'Senior', '', 1, 'hostel', '2020-09-30 13:14:29', NULL);
INSERT INTO `hostel_category` (`id`, `name`, `description`, `branch_id`, `type`, `created_at`, `updated_at`) VALUES (3, 'JS1', '', 1, 'room', '2020-09-30 13:14:55', NULL);
INSERT INTO `hostel_category` (`id`, `name`, `description`, `branch_id`, `type`, `created_at`, `updated_at`) VALUES (4, 'SS1', '', 1, 'room', '2020-09-30 13:15:07', NULL);


#
# TABLE STRUCTURE FOR: hostel_room
#

DROP TABLE IF EXISTS `hostel_room`;

CREATE TABLE `hostel_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `no_beds` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `bed_fee` decimal(18,2) NOT NULL,
  `remarks` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `hostel_room` (`id`, `name`, `hostel_id`, `no_beds`, `category_id`, `bed_fee`, `remarks`, `branch_id`) VALUES (1, 'Room 512', 1, 15, 4, '4500.00', '', 1);
INSERT INTO `hostel_room` (`id`, `name`, `hostel_id`, `no_beds`, `category_id`, `bed_fee`, `remarks`, `branch_id`) VALUES (2, 'Room 979', 1, 45, 3, '15000.00', '', 1);


#
# TABLE STRUCTURE FOR: language_list
#

DROP TABLE IF EXISTS `language_list`;

CREATE TABLE `language_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `lang_field` varchar(600) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (1, 'English', 'english', 1, '2018-11-15 12:36:31', '2020-04-18 20:05:12');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (3, 'Arabic', 'arabic', 1, '2018-11-15 12:36:31', '2019-01-20 03:04:53');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (32, 'Hausa', 'lang_32', 0, '2020-10-06 11:26:09', '2020-10-06 12:18:24');


#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `english` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `arabic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lang_32` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1151 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1, 'language', 'Language', 'لغة', 'Harshe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (2, 'attendance_overview', 'Attendance Overview', 'نظرة عامة على الحضور', 'Bayanin Halartan');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (3, 'annual_fee_summary', 'Annual Fee Summary', 'ملخص الرسوم السنوية', 'Takaitawa Na Shekara-shekara');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (4, 'my_annual_attendance_overview', 'My Annual Attendance Overview', 'حضري السنوي نظرة عامة', 'Taron Zuwan Na Shekara-shekara');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (5, 'schedule', 'Schedule', 'جداول', 'Jadawalin');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (6, 'student_admission', 'Student Admission', 'قبول الطلاب', 'Shiga Dalibi');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (7, 'returned', 'Returned', 'عاد', 'An dawo');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (8, 'user_name', 'User Name', 'اسم المستخدم', 'Sunan Mai amfani');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (9, 'rejected', 'Rejected', 'مرفوض', 'An ƙi shi');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (10, 'route_name', 'Route Name', 'اسم المسار', 'Sunan Hanyar');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (11, 'route_fare', 'Route Fare', 'الطريق الأجرة', 'Hanyar tafiya');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (12, 'edit_route', 'Edit Route', 'تحرير المسار', 'Shirya Hanya');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (13, 'this_value_is_required', 'This value is required.', 'هذه القيمة مطلوبة', 'Ana Bukatar Wannan Darajar');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (14, 'vehicle_no', 'Vehicle No', 'السيارة لا', 'Abin hawa Babu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (15, 'insurance_renewal_date', 'Insurance Renewal Date', 'تاريخ تجديد التأمين', 'Kwanakin Sabunta Inshora');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (16, 'driver_name', 'Driver Name', 'اسم السائق', 'Sunan Direba');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (17, 'driver_license', 'Driver License', 'رخصة قيادة', 'Lasisin Tuki');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (18, 'select_route', 'Select Route', 'حدد الطريق', 'Zaɓi Hanyar');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (19, 'edit_vehicle', 'Edit Vehicle', 'تحرير السيارة', 'Shirya Mota');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (20, 'add_students', 'Add Students', ' إضافة الطلاب', 'Kara Dalibai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (21, 'vehicle_number', 'Vehicle Number', 'عدد المركبات', 'Lambar Mota');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (22, 'select_route_first', 'Select Route First', 'حدد الطريق أولا', 'Zaɓi Hanyar Farko');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (23, 'transport_fee', 'Transport Fee', 'مصاريف الشحن', 'Kudin Kawowa');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (24, 'control', 'Control', 'مراقبة', 'Sarrafawa');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (25, 'set_students', 'Set Students', 'تعيين الطلاب', 'Saita Dalibai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (26, 'hostel_list', 'Hostel List', 'قائمة نزل', 'Jerin dakunan kwanan dalibai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (27, 'watchman_name', 'Watchman Name', 'اسم الحارس', 'Sunan Mai tsaro');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (28, 'hostel_address', 'Hostel Address', 'عنوان الفندق', 'Adireshin dakunan kwanan dalibai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (29, 'edit_hostel', 'Edit Hostel', 'تحرير نزل', 'Shirya Dakunan kwanan dalibai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (30, 'room_name', 'Room Name', 'اسم الغرفة', 'Sunan daki');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (31, 'no_of_beds', 'No Of Beds', 'عدد الأسرة', 'Adadin gado');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (32, 'select_hostel_first', 'Select Hostel First', 'حدد نزل أولا', 'Zaɓi Dakunan kwanan dalibai Na Farko');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (33, 'remaining', 'Remaining', 'متبق', 'Saura');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (34, 'hostel_fee', 'Hostel Fee', 'رسوم النزل', 'Kudin Dakunan kwanan dalibai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (35, 'accountant_list', 'Accountant List', 'قائمة المحاسبين', 'Jerin akawu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (36, 'students_fees', 'Students Fees', 'رسوم الطلاب', 'Kudaden dalibi');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (37, 'fees_status', 'Fees Status', 'حالة الرسوم', 'Halin kuɗi');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (38, 'books', 'Books', 'الكتب', 'Littattafai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (39, 'home_page', 'Home Page', 'الصفحة الرئيسية', 'Shafin Farko');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (40, 'collected', 'Collected', 'جمع', 'Tattara');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (41, 'student_mark', 'Student Mark', 'علامة الطالب', 'Alamar Dalibi');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (42, 'select_exam_first', 'Select Exam First', 'حدد الامتحان أولا', 'Zaɓi Jarabawa Na Farko');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (43, 'transport_details', 'Transport Details', 'تفاصيل النقل', 'Bayanin sufuri');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (44, 'no_of_teacher', 'No of Teacher', 'لا المعلم', 'Yawan Malamai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (45, 'basic_details', 'Basic Details', 'تفاصيل أساسية', 'Cikakkun bayanai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (46, 'fee_progress', 'Fee Progress', 'رسوم التقدم', 'Ci gaban Kudi');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (47, 'word', 'Word', 'كلمة', 'Kalma');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (48, 'book_category', 'Book Category', 'فئة الكتاب', 'Rukunin Litattafai');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (49, 'driver_phone', 'Driver Phone', 'سائق الهاتف', 'Wayar Direba');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (50, 'invalid_csv_file', 'Invalid / Corrupted CSV File', 'ملف كسف غير صالح / معطل', 'Fayil Csv mara aiki');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (51, 'requested_book_list', 'Requested Book List', 'طلب قائمة الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (52, 'request_status', 'Request Status', 'حالة الطلب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (53, 'book_request', 'Book Request', 'طلب الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (54, 'logout', 'Logout', 'الخروج', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (55, 'select_payment_method', 'Select Payment Method', 'اختار طريقة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (56, 'select_method', 'Select Method', 'حدد الطريقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (57, 'payment', 'Payment', 'دفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (58, 'filter', 'Filter', 'منقي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (59, 'status', 'Status', 'الحالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (60, 'paid', 'Paid', 'دفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (61, 'unpaid', 'Unpaid', 'غير مدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (62, 'method', 'Method', 'طريقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (63, 'cash', 'Cash', 'السيولة النقدية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (64, 'check', 'Check', 'الاختيار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (65, 'card', 'Card', 'بطاقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (66, 'payment_history', 'Payment History', 'تاريخ الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (67, 'category', 'Category', 'فئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (68, 'book_list', 'Book List', 'قائمة الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (69, 'author', 'Author', 'مؤلف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (70, 'price', 'Price', 'السعر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (71, 'available', 'Available', 'متاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (72, 'unavailable', 'Unavailable', 'غير متوفره', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (73, 'transport_list', 'Transport List', 'قائمة النقل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (74, 'edit_transport', 'Edit Transport', 'تحرير النقل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (75, 'hostel_name', 'Hostel Name', 'اسم المهجع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (76, 'number_of_room', 'Hostel Of Room', 'عدد الغرف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (77, 'yes', 'Yes', 'نعم فعلا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (78, 'no', 'No', 'لا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (79, 'messages', 'Messages', 'رسائل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (80, 'compose', 'Compose', 'إرسال رسالة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (81, 'recipient', 'Recipient', 'مستلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (82, 'select_a_user', 'Select A User', 'تحديد مستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (83, 'send', 'Send', 'إرسال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (84, 'global_settings', 'Global Settings', 'اعدادات النظام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (85, 'currency', 'Currency', 'عملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (86, 'system_email', 'System Email', 'نظام البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (87, 'create', 'Create', 'خلق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (88, 'save', 'Save', 'حفظ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (89, 'file', 'File', 'ملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (90, 'theme_settings', 'Theme Settings', 'إعدادات موضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (91, 'default', 'Default', 'افتراضي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (92, 'select_theme', 'Select Theme', 'اختر الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (93, 'upload_logo', 'Upload Logo', 'تحميل الشعار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (94, 'upload', 'Upload', 'تحميل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (95, 'remember', 'Remember', 'تذكر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (96, 'not_selected', 'Not Selected', 'لم يتم اختياره', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (97, 'disabled', 'Disabled', 'معاق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (98, 'inactive_account', 'Inactive Account', 'حساب غير نشط', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (99, 'update_translations', 'Update Translations', 'تحديث الترجمات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (100, 'language_list', 'Language List', 'قائمة لغة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (101, 'option', 'Option', 'خيار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (102, 'edit_word', 'Edit Word', 'تحرير الكلمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (103, 'update_profile', 'Update Profile', 'تحديث الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (104, 'current_password', 'Current Password', 'كلمة السر الحالية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (105, 'new_password', 'New Password', 'كلمة السر الجديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (106, 'login', 'Login', 'تسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (107, 'reset_password', 'Reset Password', 'اعادة تعيين كلمة السر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (108, 'present', 'Present', 'حاضر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (109, 'absent', 'Absent', 'غائب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (110, 'update_attendance', 'Update Attendance', 'تحديث الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (111, 'undefined', 'Undefined', 'غير محدد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (112, 'back', 'Back', 'الى الخلف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (113, 'save_changes', 'Save Changes', 'حفظ التغيرات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (114, 'uploader', 'Uploader', 'رافع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (115, 'download', 'Download', 'تحميل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (116, 'remove', 'Remove', 'إزالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (117, 'print', 'Print', 'طباعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (118, 'select_file_type', 'Select File Type', 'حدد نوع الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (119, 'excel', 'Excel', 'تفوق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (120, 'other', 'Other', 'آخر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (121, 'students_of_class', 'Students Of Class', 'طلبة الدرجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (122, 'marks_obtained', 'Marks Obtained', 'العلامات التي يحصل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (123, 'attendance_for_class', 'Attendance For Class', 'الحضور لفئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (124, 'receiver', 'Receiver', 'المتلقي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (125, 'please_select_receiver', 'Please Select Receiver', 'الرجاء الإختيار استقبال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (126, 'session_changed', 'Session Changed', 'جلسة تغيير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (127, 'exam_marks', 'Exam Marks', 'علامات الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (128, 'total_mark', 'Total Mark', 'عدد الأقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (129, 'mark_obtained', 'Mark Obtained', 'علامة حصل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (130, 'invoice/payment_list', 'Invoice / Payment List', 'فاتورة / قائمة دفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (131, 'obtained_marks', 'Obtained Marks', 'العلامات التي تم الحصول عليها', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (132, 'highest_mark', 'Highest Mark', 'أعلى الأقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (133, 'grade', 'Grade (GPA)', 'درجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (134, 'dashboard', 'Dashboard', 'لوحة القيادة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (135, 'student', 'Student', 'طالب علم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (136, 'rename', 'Rename', 'إعادة تسمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (137, 'class', 'Class', 'صف مدرسي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (138, 'teacher', 'Teacher', 'مدرس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (139, 'parents', 'Parents', 'الآباء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (140, 'subject', 'Subject', 'موضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (141, 'student_attendance', 'Student Attendance', 'حضور الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (142, 'exam_list', 'Exam List', 'قائمة الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (143, 'grades_range', 'Grades Range', 'مجموعة الدرجات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (144, 'loading', 'Loading', 'جار التحميل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (145, 'library', 'Library', 'مكتبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (146, 'hostel', 'Hostel', 'المهجع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (147, 'events', 'Events', 'اللافتة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (148, 'message', 'Message', 'الرسالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (149, 'translations', 'Translations', 'ترجمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (150, 'account', 'Account', 'حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (151, 'selected_session', 'Selected Session', 'جلسة مختارة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (152, 'change_password', 'Change Password', 'تغيير كلمة السر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (153, 'section', 'Section', 'قسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (154, 'edit', 'Edit', 'تحرير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (155, 'delete', 'Delete', 'حذف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (156, 'cancel', 'Cancel', 'إلغاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (157, 'parent', 'Parent', 'أصل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (158, 'attendance', 'Attendance', 'الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (159, 'addmission_form', 'Admission Form', 'شكل القبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (160, 'name', 'Name', 'اسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (161, 'select', 'Select', 'اختار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (162, 'roll', 'Roll', 'لفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (163, 'birthday', 'Date Of Birth', 'تاريخ الميلاد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (164, 'gender', 'Gender', 'جنس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (165, 'male', 'Male', 'ذكر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (166, 'female', 'Female', 'أنثى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (167, 'address', 'Address', 'عنوان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (168, 'phone', 'Phone', 'هاتف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (169, 'email', 'Email', 'البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (170, 'password', 'Password', 'كلمه السر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (171, 'transport_route', 'Transport Route', 'النقل الطريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (172, 'photo', 'Photo', 'صورة فوتوغرافية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (173, 'select_class', 'Select Class', 'حدد فئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (174, 'username_password_incorrect', 'Username Or Password Is Incorrect', 'اسم المستخدم أو كلمة المرور غير صحيحة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (175, 'select_section', 'Select Section', 'حدد القسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (176, 'options', 'Options', 'خيارات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (177, 'mark_sheet', 'Mark Sheet', 'ورقة علامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (178, 'profile', 'Profile', 'الملف الشخصي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (179, 'select_all', 'Select All', 'اختر الكل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (180, 'select_none', 'Select None', 'حدد بلا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (181, 'average', 'Average', 'متوسط', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (182, 'transfer', 'Transfer', 'تحويل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (183, 'edit_teacher', 'Edit Teacher', 'تحرير المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (184, 'sex', 'Sex', 'جنس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (185, 'marksheet_for', 'Marksheet For', 'ورقة علامة ل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (186, 'total_marks', 'Total Marks', 'مجموع الدرجات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (187, 'parent_phone', 'Parent Phone', 'الأم الهاتف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (188, 'subject_author', 'Subject Author', 'الموضوع المؤلف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (189, 'update', 'Update', 'تحديث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (190, 'class_list', 'Class List', 'قائمة الطبقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (191, 'class_name', 'Class Name', 'اسم الطبقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (192, 'name_numeric', 'Name Numeric', 'اسم الرقمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (193, 'select_teacher', 'Select Teacher', 'حدد المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (194, 'edit_class', 'Edit Class', 'تحرير الفئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (195, 'section_name', 'Section Name', 'اسم القسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (196, 'add_section', 'Add Section', 'إضافة مقطع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (197, 'subject_list', 'Subject List', 'قائمة الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (198, 'subject_name', 'Subject Name', 'اسم الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (199, 'edit_subject', 'Edit Subject', 'تحرير الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (200, 'day', 'Day', 'يوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (201, 'starting_time', 'Starting Time', 'ابتداء من الوقت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (202, 'hour', 'Hour', 'ساعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (203, 'minutes', 'Minutes', 'دقيقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (204, 'ending_time', 'Ending Time', 'إنهاء الوقت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (205, 'select_subject', 'Select Subject', 'حدد الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (206, 'select_date', 'Select Date', 'حدد التاريخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (207, 'select_month', 'Select Month', 'اختر الشهر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (208, 'select_year', 'Select Year', 'اختر السنة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (209, 'add_language', 'Add Language', 'إضافة لغة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (210, 'exam_name', 'Exam Name', 'اسم الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (211, 'date', 'Date', 'تاريخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (212, 'comment', 'Comment', 'التعليق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (213, 'edit_exam', 'Edit Exam', 'تحرير امتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (214, 'grade_list', 'Grade List', 'قائمة الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (215, 'grade_name', 'Grade Name', 'اسم الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (216, 'grade_point', 'Grade Point', 'الصف نقطة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (217, 'select_exam', 'Select Exam', 'حدد الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (218, 'students', 'Students', 'الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (219, 'subjects', 'Subjects', 'المواضيع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (220, 'total', 'Total', 'مجموع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (221, 'select_academic_session', 'Select Academic Session', 'حدد الدورة الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (222, 'invoice_informations', 'Invoice Informations', 'معلومات الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (223, 'title', 'Title', 'عنوان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (224, 'description', 'Description', 'وصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (225, 'payment_informations', 'Payment Informations', 'معلومات الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (226, 'view_invoice', 'View Invoice', 'عرض الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (227, 'payment_to', 'Payment To', 'دفع ل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (228, 'bill_to', 'Bill To', 'فاتورة الى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (229, 'total_amount', 'Total Amount', 'المبلغ الإجمالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (230, 'paid_amount', 'Paid Amount', 'المبلغ المدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (231, 'due', 'Due', 'بسبب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (232, 'amount_paid', 'Amount Paid', 'المبلغ المدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (233, 'payment_successfull', 'Payment has been successful', 'دفع النجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (234, 'add_invoice/payment', 'Add Invoice/payment', 'إضافة فاتورة / دفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (235, 'invoices', 'Invoices', 'الفواتير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (236, 'action', 'Action', 'عمل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (237, 'required', 'Required', 'مطلوب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (238, 'info', 'Info', 'معلومات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (239, 'month', 'Month', '\r\nشهر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (240, 'details', 'Details', 'تفاصيل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (241, 'new', 'New', 'الجديد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (242, 'reply_message', 'Reply Message', 'رسالة الرد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (243, 'message_sent', 'Message Sent', 'تم الارسال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (244, 'search', 'Search', 'بحث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (245, 'religion', 'Religion', 'دين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (246, 'blood_group', 'Blood group', 'فصيلة الدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (247, 'database_backup', 'Database Backup', 'قاعدة بيانات النسخ الاحتياطي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (248, 'search', 'Search', 'بحث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (249, 'payments_history', 'Fees Pay / Invoice', 'رسوم الدفع / الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (250, 'message_restore', 'Message Restore', 'استعادة الرسائل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (251, 'write_new_message', 'Write New Message', 'إرسال رسالة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (252, 'attendance_sheet', 'Attendance Sheet', 'ورقة الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (253, 'holiday', 'Holiday', 'يوم الاجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (254, 'exam', 'Exam', 'امتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (255, 'successfully', 'Successfully', 'بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (256, 'admin', 'Admin', 'مشرف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (257, 'inbox', 'Inbox', 'صندوق الوارد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (258, 'sent', 'Sent', 'أرسلت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (259, 'important', 'Important', 'مهم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (260, 'trash', 'Trash', 'قمامة، يدمر، يهدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (261, 'error', 'Unsuccessful', 'غير ناجحة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (262, 'sessions_list', 'Sessions List', 'قائمة الجلسات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (263, 'session_settings', 'Session Settings', 'إعدادات الجلسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (264, 'add_designation', 'Add Designation', 'إضافة تسمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (265, 'users', 'Users', 'المستخدمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (266, 'librarian', 'Librarian', 'أمين المكتبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (267, 'accountant', 'Accountant', 'محاسب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (268, 'academics', 'Academics', 'مؤسسيا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (269, 'employees_attendance', 'Employees Attendance', 'حضور الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (270, 'set_exam_term', 'Set Exam Term', 'تعيين مدة الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (271, 'set_attendance', 'Set Attendance', 'تعيين الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (272, 'marks', 'Marks', 'علامات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (273, 'books_category', 'Books Category', 'فئة الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (274, 'transport', 'Transport', 'المواصلات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (275, 'fees', 'Fees', 'رسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (276, 'fees_allocation', 'Fees Allocation', 'توزيع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (277, 'fee_category', 'Fee Category', 'فئة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (278, 'report', 'Report', 'أبلغ عن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (279, 'employee', 'Employee', 'الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (280, 'invoice', 'Invoice', 'فاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (281, 'event_catalogue', 'Event Catalogue', 'كتالوج الأحداث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (282, 'total_paid', 'Total Paid', 'مجموع المبالغ المدفوعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (283, 'total_due', 'Total Due', 'الاجمالي المستحق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (284, 'fees_collect', 'Fees Collect', 'تحصيل الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (285, 'total_school_students_attendance', 'Total School Students Attendance', 'مجموع طلاب المدارس الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (286, 'overview', 'Overview', 'نظرة عامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (287, 'currency_symbol', 'Currency Symbol', 'رمز العملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (288, 'enable', 'Enable', 'مكن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (289, 'disable', 'Disable', 'تعطيل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (290, 'payment_settings', 'Payment Settings', 'إعدادات الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (291, 'student_attendance_report', 'Student Attendance Report', 'تقرير حضور الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (292, 'attendance_type', 'Attendance Type', 'نوع الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (293, 'late', 'Late', 'متأخر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (294, 'employees_attendance_report', 'Employees Attendance Report', 'الموظفين تقرير الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (295, 'attendance_report_of', 'Attendance Report Of', 'تقرير الحضور من', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (296, 'fee_paid_report', 'Fee Paid Report', 'الرسوم المدفوعة التقرير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (297, 'invoice_no', 'Invoice No', 'رقم الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (298, 'payment_mode', 'Payment Mode', 'طريقة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (299, 'payment_type', 'Payment Type', 'نوع الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (300, 'done', 'Done', 'فعله', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (301, 'select_fee_category', 'Select Fee Category', 'حدد فئة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (302, 'discount', 'Discount', 'خصم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (303, 'enter_discount_amount', 'Enter Discount Amount', 'أدخل مبلغ الخصم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (304, 'online_payment', 'Online Payment', 'الدفع عن بعد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (305, 'student_name', 'Student Name', 'أسم الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (306, 'invoice_history', 'Invoice History', 'تاريخ الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (307, 'discount_amount', 'Discount Amount', 'مقدار الخصم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (308, 'invoice_list', 'Invoice List', 'قائمة الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (309, 'partly_paid', 'Partly Paid', 'تدفع جزئيا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (310, 'fees_list', 'Fees List', 'قائمة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (311, 'voucher_id', 'Voucher ID', 'معرف القسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (312, 'transaction_date', 'Transaction Date', 'تاريخ الصفقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (313, 'admission_date', 'Admission Date', 'تاريخ القبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (314, 'user_status', 'User Status', 'حالة المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (315, 'nationality', 'Nationality', 'جنسية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (316, 'register_no', 'Register No', 'سجل رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (317, 'first_name', 'First Name', 'الاسم الاول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (318, 'last_name', 'Last Name', 'الكنية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (319, 'state', 'State', 'حالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (320, 'transport_vehicle_no', 'Transport Vehicle No', 'رقم مركبة النقل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (321, 'percent', 'Percent', 'نسبه مئويه', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (322, 'average_result', 'Average Result', 'متوسط ​​النتيجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (323, 'student_category', 'Student Category', 'طالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (324, 'category_name', 'Category Name', 'اسم التصنيف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (325, 'category_list', 'Category List', 'قائمة الفئات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (326, 'please_select_student_first', 'Please Select Students First', 'يرجى اختيار الطلاب أولا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (327, 'designation', 'Designation', 'تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (328, 'qualification', 'Qualification', 'المؤهل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (329, 'account_deactivated', 'Account Deactivated', 'تم إلغاء تنشيط الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (330, 'account_activated', 'Account Activated', 'تم تنشيط الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (331, 'designation_list', 'Designation List', 'قائمة التعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (332, 'joining_date', 'Joining Date', 'تاريخ الانضمام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (333, 'relation', 'Relation', 'علاقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (334, 'father_name', 'Father Name', 'اسم الأب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (335, 'librarian_list', 'Librarian List', 'قائمة أمين المكتبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (336, 'class_numeric', 'Class Numeric', 'فئة رقمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (337, 'maximum_students', 'Maximum Students', 'الحد الأقصى للطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (338, 'class_room', 'Class Room', 'قاعة الدراسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (339, 'pass_mark', 'Pass Mark', 'علامة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (340, 'exam_time', 'Exam Time (Min)', 'وقت الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (341, 'time', 'Time', 'زمن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (342, 'subject_code', 'Subject Code', 'رمز الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (343, 'full_mark', 'Full Mark', 'درجة كاملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (344, 'subject_type', 'Subject Type', 'نوع الموضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (345, 'date_of_publish', 'Date Of Publish', 'تاريخ النشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (346, 'file_name', 'File Name', 'اسم الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (347, 'students_list', 'Students List', 'قائمة الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (348, 'start_date', 'Start Date', 'تاريخ البدء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (349, 'end_date', 'End Date', 'تاريخ الانتهاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (350, 'term_name', 'Term Name', 'اسم المدى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (351, 'grand_total', 'Grand Total', 'المبلغ الإجمالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (352, 'result', 'Result', 'نتيجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (353, 'books_list', 'Books List', 'قائمة الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (354, 'book_isbn_no', 'Book ISBN No', 'كتاب رقم إيسبن رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (355, 'total_stock', 'Total Stock', 'إجمالي الأسهم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (356, 'issued_copies', 'Issued Copies', 'تم إصدار نسخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (357, 'publisher', 'Publisher', 'الناشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (358, 'books_issue', 'Books Issue', 'كتاب المسألة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (359, 'user', 'User', 'المستعمل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (360, 'fine', 'Fine', 'غرامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (361, 'pending', 'Pending', 'قيد الانتظار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (362, 'return_date', 'Return Date', 'تاريخ العودة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (363, 'accept', 'Accept', 'قبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (364, 'reject', 'Reject', 'رفض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (365, 'issued', 'Issued', 'نشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (366, 'return', 'Return', 'إرجاع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (367, 'renewal', 'Renewal', 'تجديد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (368, 'fine_amount', 'Fine Amount', 'كمية غرامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (369, 'password_mismatch', 'Password Mismatch', 'عدم تطابق كلمة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (370, 'settings_updated', 'Settings Update', 'تحديث الإعدادات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (371, 'pass', 'Pass', 'البشري', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (372, 'event_to', 'Event To', 'الحدث ل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (373, 'all_users', 'All Users', 'جميع المستخدمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (374, 'employees_list', 'Employees List', 'قائمة الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (375, 'on', 'On', 'على', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (376, 'timezone', 'Timezone', 'وحدة زمنية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (377, 'get_result', 'Get Result', 'الحصول على نتيجة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (378, 'apply', 'Apply', 'تطبيق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (379, 'hrm', 'Human Resource', 'الموارد البشرية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (380, 'payroll', 'Payroll', 'كشف رواتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (381, 'salary_assign', 'Salary Assign', 'مراقبة الرواتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (382, 'employee_salary', 'Payment Salary', 'دفع الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (383, 'application', 'Application', 'الوضعية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (384, 'award', 'Award', 'جائزة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (385, 'basic_salary', 'Basic Salary', 'راتب اساسي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (386, 'employee_name', 'Employee Name', 'اسم الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (387, 'name_of_allowance', 'Name Of Allowance', 'اسم البدل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (388, 'name_of_deductions', 'Name Of Deductions', 'اسم الاستقطاعات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (389, 'all_employees', 'All Employees', 'كل الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (390, 'total_allowance', 'Total Allowance', 'مجموع المخصصات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (391, 'total_deduction', 'Total Deductions', 'مجموع الخصومات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (392, 'net_salary', 'Net Salary', 'صافي الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (393, 'payslip', 'Payslip', 'قسيمة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (394, 'days', 'Days', 'أيام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (395, 'category_name_already_used', 'Category Name Already Used', 'اسم الفئة المستخدمة من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (396, 'leave_list', 'Leave List', 'قائمة الإجازات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (397, 'leave_category', 'Leave Category', 'ترك الفئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (398, 'applied_on', 'Applied On', 'تطبيق على', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (399, 'accepted', 'Accepted', 'قبلت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (400, 'leave_statistics', 'Leave Statistics', 'وترك الإحصاءات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (401, 'leave_type', 'Leave Type', 'نوع الإجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (402, 'reason', 'Reason', 'السبب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (403, 'close', 'Close', 'أغلق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (404, 'give_award', 'Give Award', 'إعطاء الجائزة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (405, 'list', 'List', 'قائمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (406, 'award_name', 'Award Name', 'اسم الجائزة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (407, 'gift_item', 'Gift Item', 'هدية البند', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (408, 'cash_price', 'Cash Price', 'سعر الصرف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (409, 'award_reason', 'Award Reason', 'جائزة السبب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (410, 'given_date', 'Given Date', 'تاريخ معين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (411, 'apply_leave', 'Apply Leave', 'تطبيق الإجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (412, 'leave_application', 'Leave Application', 'اترك التطبيق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (413, 'allowances', 'Allowances', 'البدلات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (414, 'add_more', 'Add More', 'أضف المزيد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (415, 'deductions', 'Deductions', 'الخصومات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (416, 'salary_details', 'Salary Details', 'تفاصيل الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (417, 'salary_month', 'Salary Month', 'راتب شهر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (418, 'leave_data_update_successfully', 'Leave Data Updated Successfully', 'ترك البيانات تحديثها بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (419, 'fees_history', 'Fees History', 'تاريخ الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (420, 'bank_name', 'Bank Name', 'اسم البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (421, 'branch', 'Branch', 'فرع شجرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (422, 'bank_address', 'Bank Address', 'عنوان البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (423, 'ifsc_code', 'IFSC Code', 'رمز إفسك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (424, 'account_no', 'Account No', 'رقم الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (425, 'add_bank', 'Add Bank', 'إضافة بنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (426, 'account_name', 'Account Holder', 'أسم الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (427, 'database_backup_completed', 'Database Backup Completed', 'اكتمل قاعدة بيانات النسخ الاحتياطي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (428, 'restore_database', 'Restore Database', 'استعادة قاعدة البيانات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (429, 'template', 'Template', 'قالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (430, 'time_and_date', 'Time And Date', 'الوقت و التاريخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (431, 'everyone', 'Everyone', 'كل واحد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (432, 'invalid_amount', 'Invalid Amount', 'مبلغ غير صحيح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (433, 'leaving_date_is_not_available_for_you', 'Leaving Date Is Not Available For You', 'ترك التاريخ غير متاح لك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (434, 'animations', 'Animations', 'الرسوم المتحركة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (435, 'email_settings', 'Email Settings', 'إعدادات البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (436, 'deduct_month', 'Deduct Month', 'خصم الشهر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (437, 'no_employee_available', 'No Employee Available', 'لا يتوفر موظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (438, 'advance_salary_application_submitted', 'Advance Salary Application Submitted', 'تم تقديم طلب الراتب المتقدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (439, 'date_format', 'Date Format', 'صيغة التاريخ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (440, 'id_card_generate', 'ID Card Generate', 'بطاقة الهوية تولد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (441, 'issue_salary', 'Issue Salary', 'إصدار الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (442, 'advance_salary', 'Advance Salary', 'راتب مقدما', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (443, 'logo', 'Logo', 'شعار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (444, 'book_request', 'Book Request', 'طلب الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (445, 'reporting', 'Reporting', 'التقارير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (446, 'paid_salary', 'Paid Salary', 'الراتب المدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (447, 'due_salary', 'Due Salary', 'الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (448, 'route', 'Route', 'طريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (449, 'academic_details', 'Academic Details', 'التفاصيل الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (450, 'guardian_details', 'Guardian Details', 'التفاصيل الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (451, 'due_amount', 'Due Amount', 'مبلغ مستحق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (452, 'fee_due_report', 'Fee Due Report', 'تقرير الرسوم المستحقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (453, 'other_details', 'Other Details', 'تفاصيل أخرى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (454, 'last_exam_report', 'Last Exam Report', 'تقرير الاختبار الأخير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (455, 'book_issued', 'Book Issued', ' كتاب صدر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (456, 'interval_month', 'Interval 30 Days', 'الفاصل الزمني 30 يومًا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (457, 'attachments', 'Attachments', 'مرفقات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (458, 'fees_payment', 'Fees Payment', 'دفع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (459, 'fees_summary', 'Fees Summary', 'ملخص الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (460, 'total_fees', 'Total Fees', 'الرسوم الكلية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (461, 'weekend_attendance_inspection', 'Weekend Attendance Inspection', 'فحص الحضور في عطلة نهاية الاسبوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (462, 'book_issued_list', 'Book Issued List', 'كتاب صدر قائمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (463, 'lose_your_password', 'Lose Your Password?', '?تفقد كلمة المرور الخاصة بك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (464, 'all_branch_dashboard', 'All Branch Dashboard', 'كل لوحة فرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (465, 'academic_session', 'Academic Session', 'الدورة الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (466, 'all_branches', 'All Branches', 'كل الفروع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (467, 'admission', 'Admission', 'قبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (468, 'create_admission', 'Create Admission', 'إنشاء القبول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (469, 'multiple_import', 'Multiple Import', 'استيراد متعدد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (470, 'student_details', 'Student Details', 'تفاصيل الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (471, 'student_list', 'Student List', 'قائمة الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (472, 'login_deactivate', 'Login Deactivate', 'تسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (473, 'parents_list', 'Parents List', 'قائمة الوالدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (474, 'add_parent', 'Add Parent', 'أضف الوالد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (475, 'employee_list', 'Employee List', 'قائمة موظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (476, 'add_department', 'Add Department', 'أضف قسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (477, 'add_employee', 'Add Employee', 'إضافة موظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (478, 'salary_template', 'Salary Template', 'قالب الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (479, 'salary_payment', 'Salary Payment', 'دفع المرتبات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (480, 'payroll_summary', 'Payroll Summary', 'ملخص الرواتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (481, 'academic', 'Academic', 'أكاديمي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (482, 'control_classes', 'Control Classes', 'فئات التحكم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (483, 'assign_class_teacher', 'Assign Class Teacher', 'تعيين معلم الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (484, 'class_assign', 'Class Assign', 'تعيين فئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (485, 'assign', 'Assign', 'تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (486, 'promotion', 'Promotion', 'ترقية وظيفية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (487, 'attachments_book', 'Attachments Book', 'كتاب المرفقات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (488, 'upload_content', 'Upload Content', 'تحميل المحتوى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (489, 'attachment_type', 'Attachment Type', 'نوع المرفق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (490, 'exam_master', 'Exam Master', 'الامتحان ماجستير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (491, 'exam_hall', 'Exam Hall', 'قاعة الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (492, 'mark_entries', 'Mark Entries', 'إدخالات مارك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (493, 'tabulation_sheet', 'Tabulation Sheet', 'ورقة الجدولة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (494, 'supervision', 'Supervision', 'إشراف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (495, 'hostel_master', 'Hostel Master', 'نزل ماستر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (496, 'hostel_room', 'Hostel Room', 'غرفة نزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (497, 'allocation_report', 'Allocation Report', 'تقرير التخصيص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (498, 'route_master', 'Route Master', 'سيد الطريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (499, 'vehicle_master', 'Vehicle Master', 'سيد السيارة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (500, 'stoppage', 'Stoppage', 'إضراب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (501, 'assign_vehicle', 'Assign Vehicle', 'تخصيص مركبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (502, 'reports', 'Reports', 'تقارير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (503, 'books_entry', 'Books Entry', 'دخول الكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (504, 'event_type', 'Event Type', 'نوع الحدث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (505, 'add_events', 'Add Events', 'إضافة أحداث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (506, 'student_accounting', 'Student Accounting', 'محاسبة الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (507, 'create_single_invoice', 'Create Single Invoice', 'إنشاء فاتورة واحدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (508, 'create_multi_invoice', 'Create Multi Invoice', 'إنشاء متعدد الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (509, 'summary_report', 'Summary Report', 'تقرير ملخص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (510, 'office_accounting', 'Office Accounting', 'محاسبة المكتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (511, 'under_group', 'Under Group', 'تحت المجموعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (512, 'bank_account', 'Bank Account', 'حساب البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (513, 'ledger_account', 'Ledger Account', 'حساب دفتر الأستاذ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (514, 'create_voucher', 'Create Voucher', 'إنشاء قسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (515, 'day_book', 'Day Book', 'كتاب اليوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (516, 'cash_book', 'Cash Book', 'كتاب النقدية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (517, 'bank_book', 'Bank Book', 'كتاب البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (518, 'ledger_book', 'Ledger Book', 'دفتر الأستاذ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (519, 'trial_balance', 'Trial Balance', 'ميزان المراجعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (520, 'settings', 'Settings', 'الإعدادات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (521, 'sms_settings', 'Sms Settings', 'إعدادات الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (522, 'cash_book_of', 'Cash Book Of', 'كتاب النقدية من', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (523, 'by_cash', 'By Cash', 'نقدا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (524, 'by_bank', 'By Bank', 'عن طريق البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (525, 'total_strength', 'Total Strength', 'القوة الكلية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (526, 'teachers', 'Teachers', 'معلمون', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (527, 'student_quantity', 'Student Quantity', 'كمية الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (528, 'voucher', 'Voucher', 'قسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (529, 'total_number', 'Total Number', 'মোট সংখ্যা', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (530, 'total_route', 'Total Route', 'الطريق الإجمالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (531, 'total_room', 'Total Room', 'مجموع الغرفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (532, 'amount', 'Amount', 'كمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (533, 'branch_dashboard', 'Branch Dashboard', 'لوحة تحكم الفرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (534, 'branch_list', 'Branch List', 'قائمة الفرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (535, 'create_branch', 'Create Branch', 'إنشاء فرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (536, 'branch_name', 'Branch Name', 'اسم الفرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (537, 'school_name', 'School Name', 'اسم المدرسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (538, 'mobile_no', 'Mobile No', 'رقم الموبايل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (539, 'symbol', 'Symbol', 'رمز', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (540, 'city', 'City', 'مدينة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (541, 'academic_year', 'Academic Year', 'السنة الأكاديمية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (542, 'select_branch_first', 'First Select The Branch', 'أولا اختر الفرع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (543, 'select_class_first', 'Select Class First', 'اختر الفئة الأولى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (544, 'select_country', 'Select Country', 'حدد الدولة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (545, 'mother_tongue', 'Mother Tongue', 'اللغة الأم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (546, 'caste', 'Caste', 'الطائفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (547, 'present_address', 'Present Address', 'العنوان الحالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (548, 'permanent_address', 'Permanent Address', 'العنوان الثابت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (549, 'profile_picture', 'Profile Picture', 'الصوره الشخصيه', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (550, 'login_details', 'Login Details', 'تفاصيل تسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (551, 'retype_password', 'Retype Password', 'أعد إدخال كلمة السر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (552, 'occupation', 'Occupation', 'الاحتلال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (553, 'income', 'Income', 'الإيرادات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (554, 'education', 'Education', 'التعليم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (555, 'first_select_the_route', 'First Select The Route', 'أولا اختر الطريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (556, 'hostel_details', 'Hostel Details', 'تفاصيل النزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (557, 'first_select_the_hostel', 'First Select The Hostel', 'প্রথম ছাত্রাবাস নির্বাচন', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (558, 'previous_school_details', 'Previous School Details', 'تفاصيل المدرسة السابقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (559, 'book_name', 'Book Name', 'اسم الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (560, 'select_ground', 'Select Ground', 'اختر الأرض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (561, 'import', 'Import', 'استيراد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (562, 'add_student_category', 'Add Student Category', 'إضافة فئة الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (563, 'id', 'Id', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (564, 'edit_category', 'Edit Category', 'تحرير الفئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (565, 'deactivate_account', 'Deactivate Account', 'تعطيل الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (566, 'all_sections', 'All Sections', 'كل الأقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (567, 'authentication_activate', 'Authentication Activate', 'تفعيل المصادقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (568, 'department', 'Department', ' قسم، أقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (569, 'salary_grades', 'Salary Grades', 'راتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (570, 'overtime', 'Overtime Rate (Per Hour)', 'معدل العمل الإضافي (لكل ساعة)', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (571, 'salary_grade', 'Salary Grade', 'راتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (572, 'payable_type', 'Payable Type', 'نوع الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (573, 'edit_type', 'Edit Type', 'تحرير النوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (574, 'role', 'Role', 'وظيفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (575, 'remuneration_info_for', 'Remuneration Info For', 'الأجور معلومات عن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (576, 'salary_paid', 'Salary Paid', 'الراتب المدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (577, 'salary_unpaid', 'Salary Unpaid', 'الراتب غير مدفوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (578, 'pay_now', 'Pay Now', 'ادفع الآن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (579, 'employee_role', 'Employee Role', 'دور الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (580, 'create_at', 'Create At', 'خلق في', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (581, 'select_employee', 'Select Employee', 'اختر الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (582, 'review', 'Review', 'إعادة النظر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (583, 'reviewed_by', 'Reviewed By', 'تمت مراجعته من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (584, 'submitted_by', 'Submitted By', 'المقدمة من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (585, 'employee_type', 'Employee Type', 'نوع موظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (586, 'approved', 'Approved', 'وافق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (587, 'unreviewed', 'Unreviewed', 'غير مراجع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (588, 'creation_date', 'Creation Date', 'تاريخ الإنشاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (589, 'no_information_available', 'No Information Available', 'لا توجد معلومات متاحة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (590, 'continue_to_payment', 'Continue To Payment', 'مواصلة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (591, 'overtime_total_hour', 'Overtime Total Hour', 'الساعة الاجمالية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (592, 'overtime_amount', 'Overtime Amount', 'مبلغ العمل الإضافي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (593, 'remarks', 'Remarks', 'تعليق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (594, 'view', 'View', 'رأي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (595, 'leave_appeal', 'Leave Appeal', 'اترك الاستئناف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (596, 'create_leave', 'Create Leave', 'خلق إجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (597, 'user_role', 'User Role', 'دور المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (598, 'date_of_start', 'Date Of Start', 'تاريخ البدء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (599, 'date_of_end', 'Date Of End', 'تاريخ النهاية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (600, 'winner', 'Winner', 'الفائز', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (601, 'select_user', 'Select User', 'اختر المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (602, 'create_class', 'Create Class', 'إنشاء فصل دراسي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (603, 'class_teacher_allocation', 'Class Teacher Allocation', 'تخصيص معلم الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (604, 'class_teacher', 'Class Teacher', 'معلم الصف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (605, 'create_subject', 'Create Subject', 'إنشاء موضوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (606, 'select_multiple_subject', 'Select Multiple Subject', 'حدد موضوعًا متعددًا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (607, 'teacher_assign', 'Teacher Assign', 'تعيين المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (608, 'teacher_assign_list', 'Teacher Assign List', 'قائمة تعيين المعلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (609, 'select_department_first', 'Select Department First', 'حدد القسم أولاً', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (610, 'create_book', 'Create Book', 'إنشاء كتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (611, 'book_title', 'Book Title', 'عنوان كتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (612, 'cover', 'Cover', 'التغطية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (613, 'edition', 'Edition', 'الإصدار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (614, 'isbn_no', 'ISBN No', 'رقم ISBN', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (615, 'purchase_date', 'Purchase Date', 'تاريخ الشراء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (616, 'cover_image', 'Cover Image', 'صورة الغلاف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (617, 'book_issue', 'Book Issue', 'إصدار الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (618, 'date_of_issue', 'Date Of Issue', 'تاريخ المسألة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (619, 'date_of_expiry', 'Date Of Expiry', 'تاريخ الانتهاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (620, 'select_category_first', 'Select Category First', 'حدد الفئة الأولى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (621, 'type_name', 'Type Name', 'أكتب اسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (622, 'type_list', 'Type List', 'قائمة الأنواع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (623, 'icon', 'Icon', 'أيقونة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (624, 'event_list', 'Event List', 'قائمة الأحداث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (625, 'create_event', 'Create Event', 'انشاء حدث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (626, 'type', 'Type', 'نوع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (627, 'audience', 'Audience', 'الجمهور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (628, 'created_by', 'Created By', 'انشأ من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (629, 'publish', 'Publish', 'ينشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (630, 'everybody', 'Everybody', 'الجميع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (631, 'selected_class', 'Selected Class', 'فئة مختارة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (632, 'selected_section', 'Selected Section', 'القسم المختار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (633, 'information_has_been_updated_successfully', 'Information Has Been Updated Successfully', 'تم تحديث المعلومات بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (634, 'create_invoice', 'Create Invoice', 'إنشاء فاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (635, 'invoice_entry', 'Invoice Entry', 'إدخال الفاتورة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (636, 'quick_payment', 'Quick Payment', 'دفع سريع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (637, 'write_your_remarks', 'Write Your Remarks', 'اكتب ملاحظاتك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (638, 'reset', 'Reset', 'إعادة تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (639, 'fees_payment_history', 'Fees Payment History', 'تاريخ دفع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (640, 'fees_summary_report', 'Fees Summary Report', 'تقرير ملخص الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (641, 'add_account_group', 'Add Account Group', 'إضافة مجموعة حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (642, 'account_group', 'Account Group', 'جماعة حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (643, 'account_group_list', 'Account Group List', 'قائمة مجموعة الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (644, 'mailbox', 'Mailbox', 'صندوق بريد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (645, 'refresh_mail', 'Refresh Mail', 'تحديث البريد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (646, 'sender', 'Sender', 'مرسل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (647, 'general_settings', 'General Settings', 'الاعدادات العامة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (648, 'institute_name', 'Institute Name', 'اسم المعهد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (649, 'institution_code', 'Institution Code', 'رمز المؤسسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (650, 'sms_service_provider', 'Sms Service Provider', 'مزود خدمة الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (651, 'footer_text', 'Footer Text', 'نص التذييل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (652, 'payment_control', 'Payment Control', 'مراقبة الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (653, 'sms_config', 'Sms Config', 'تكوين الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (654, 'sms_triggers', 'Sms Triggers', 'مشغلات الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (655, 'authentication_token', 'Authentication Token', 'رمز المصادقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (656, 'sender_number', 'Sender Number', 'رقم المرسل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (657, 'username', 'Username', 'اسم المستخدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (658, 'api_key', 'Api Key', 'مفتاح API', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (659, 'authkey', 'Authkey', 'Authkey', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (660, 'sender_id', 'Sender Id', 'معرف الإرسال', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (661, 'sender_name', 'Sender Name', 'اسم المرسل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (662, 'hash_key', 'Hash Key', 'مفتاح التجزئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (663, 'notify_enable', 'Notify Enable', 'إعلام تمكين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (664, 'exam_attendance', 'Exam Attendance', 'حضور الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (665, 'exam_results', 'Exam Results', 'نتائج الامتحانات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (666, 'email_config', 'Email Config', 'تكوين البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (667, 'email_triggers', 'Email Triggers', 'مشغلات البريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (668, 'account_registered', 'Account Registered', 'تم تسجيل الحساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (669, 'forgot_password', 'Forgot Password', 'هل نسيت كلمة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (670, 'new_message_received', 'New Message Received', 'تم تلقي رسالة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (671, 'payslip_generated', 'Payslip Generated', 'تم إنشاء Payslip', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (672, 'leave_approve', 'Leave Approve', 'اترك الموافقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (673, 'leave_reject', 'Leave Reject', 'اترك رفض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (674, 'advance_salary_approve', 'Leave Reject', 'اترك رفض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (675, 'advance_salary_reject', 'Advance Salary Reject', 'رفض الراتب المسبق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (676, 'add_session', 'Add Session', 'إضافة جلسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (677, 'session', 'Session', 'جلسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (678, 'created_at', 'Created At', 'أنشئت في', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (679, 'sessions', 'Sessions', 'الجلسات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (680, 'flag', 'Flag', 'العلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (681, 'stats', 'Stats', 'احصائيات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (682, 'updated_at', 'Updated At', 'تم التحديث في', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (683, 'flag_icon', 'Flag Icon', 'رمز العلم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (684, 'password_restoration', 'Password Restoration', 'استعادة كلمة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (685, 'forgot', 'Forgot', 'نسيت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (686, 'back_to_login', 'Back To Login', 'العودة لتسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (687, 'database_list', 'Database List', 'قائمة قاعدة البيانات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (688, 'create_backup', 'Create Backup', 'انشئ نسخة احتياطية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (689, 'backup', 'Backup', 'دعم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (690, 'backup_size', 'Backup Size', 'حجم النسخ الاحتياطي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (691, 'file_upload', 'File Upload', 'تحميل الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (692, 'parents_details', 'Parents Details', 'تفاصيل الوالدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (693, 'social_links', 'Social Links', 'روابط اجتماعية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (694, 'create_hostel', 'Create Hostel', 'إنشاء نزل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (695, 'allocation_list', 'Allocation List', 'قائمة التخصيص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (696, 'payslip_history', 'Payslip History', 'سجل الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (697, 'my_attendance_overview', 'My Attendance Overview', 'نظرة عامة على الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (698, 'total_present', 'Total Present', 'المجموع الحالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (699, 'total_absent', 'Total Absent', 'المجموع الكلي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (700, 'total_late', 'Total Late', 'المجموع المتأخر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (701, 'class_teacher_list', 'Class Teacher List', 'قائمة مدرس الفصل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (702, 'section_control', 'Section Control', 'التحكم بالقسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (703, 'capacity ', 'Capacity', 'سعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (704, 'request', 'Request', 'طلب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (705, 'salary_year', 'Salary Year', 'سنة الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (706, 'create_attachments', 'Create Attachments', 'إنشاء المرفقات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (707, 'publish_date', 'Publish Date', 'تاريخ النشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (708, 'attachment_file', 'Attachment File', 'ملف المرفق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (709, 'age', 'Age', 'عمر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (710, 'student_profile', 'Student Profile', 'الملف الشخصي للطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (711, 'authentication', 'Authentication', 'المصادقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (712, 'parent_information', 'Parent Information', 'معلومات الوالدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (713, 'full_marks', 'Full Marks', 'علامات كاملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (714, 'passing_marks', 'Passing Marks', 'علامات النجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (715, 'highest_marks', 'Highest Marks', 'أعلى العلامات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (716, 'unknown', 'Unknown', 'مجهول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (717, 'unpublish', 'Unpublish', 'غير منشور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (718, 'login_authentication_deactivate', 'Login Authentication Deactivate', 'إلغاء تنشيط مصادقة تسجيل الدخول', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (719, 'employee_profile', 'Employee Profile', 'ملف تعريف الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (720, 'employee_details', 'Employee Details', 'تفاصيل الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (721, 'salary_transaction', 'Salary Transaction', 'معاملة الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (722, 'documents', 'Documents', 'مستندات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (723, 'actions', 'Actions', 'أجراءات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (724, 'activity', 'Activity', 'نشاط', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (725, 'department_list', 'Department List', 'قائمة الأقسام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (726, 'manage_employee_salary', 'Manage Employee Salary', 'إدارة راتب الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (727, 'the_configuration_has_been_updated', 'The Configuration Has Been Updated', 'تم تحديث التكوين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (728, 'add', 'Add', 'أضف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (729, 'create_exam', 'Create Exam', 'إنشاء امتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (730, 'term', 'Term', 'مصطلح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (731, 'add_term', 'Add Term', 'إضافة مصطلح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (732, 'create_grade', 'Create Grade', 'إنشاء تقدير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (733, 'mark_starting', 'Mark Starting', 'علامة البداية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (734, 'mark_until', 'Mark Until', 'ضع علامة حتى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (735, 'room_list', 'Room List', 'قائمة غرفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (736, 'room', 'Room', 'غرفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (737, 'route_list', 'Route List', 'قائمة المسار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (738, 'create_route', 'Create Route', 'إنشاء طريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (739, 'vehicle_list', 'Vehicle List', 'قائمة المركبات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (740, 'create_vehicle', 'Create Vehicle', 'إنشاء مركبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (741, 'stoppage_list', 'Stoppage List', 'قائمة التوقف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (742, 'create_stoppage', 'Create Stoppage', 'إنشاء توقف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (743, 'stop_time', 'Stop Time', 'وقت التوقف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (744, 'employee_attendance', 'Employee Attendance', 'حضور الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (745, 'attendance_report', 'Employee Attendance', 'حضور الموظف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (746, 'opening_balance', 'Opening Balance', 'الرصيد الافتتاحي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (747, 'add_opening_balance', 'Add Opening Balance', 'إضافة رصيد افتتاحي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (748, 'credit', 'Credit', 'ائتمان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (749, 'debit', 'Debit', 'مدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (750, 'opening_balance_list', 'Opening Balance List', 'قائمة الرصيد الافتتاحي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (751, 'voucher_list', 'Voucher List', 'قائمة القسائم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (752, 'voucher_head', 'Voucher Head', 'رئيس قسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (753, 'payment_method', 'Payment Method', 'طريقة الدفع او السداد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (754, 'credit_ledger_account', 'Credit Ledger Account', 'حساب دفتر الأستاذ الائتماني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (755, 'debit_ledger_account', 'Debit Ledger Account', 'حساب دفتر الأستاذ المدين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (756, 'voucher_no', 'Voucher No', 'رقم القسيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (757, 'balance', 'Balance', 'توازن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (758, 'event_details', 'Event Details', 'تفاصيل الحدث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (759, 'welcome_to', 'Welcome To', 'مرحبا بك في', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (760, 'report_card', 'Report Card', 'بطاقة تقرير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (761, 'online_pay', 'Online Pay', 'الدفع عبر الإنترنت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (762, 'annual_fees_summary', 'Annual Fees Summary', 'ملخص الرسوم السنوية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (763, 'my_children', 'My Children', 'أطفالي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (764, 'assigned', 'Assigned', 'تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (765, 'confirm_password', 'Confirm Password', 'تأكيد كلمة المرور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (766, 'searching_results', 'Searching Results', 'نتائج البحث', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (767, 'information_has_been_saved_successfully', 'Information Has Been Saved Successfully', 'تم حفظ المعلومات بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (768, 'information_deleted', 'The information has been successfully deleted', 'تم حذف المعلومات بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (769, 'deleted_note', '*Note : This data will be permanently deleted', '* ملاحظة: سيتم حذف هذه البيانات نهائيًا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (770, 'are_you_sure', 'Are You Sure?', 'هل أنت واثق؟', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (771, 'delete_this_information', 'Do You Want To Delete This Information?', 'هل تريد حذف هذه المعلومات؟', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (772, 'yes_continue', 'Yes, Continue', 'نعم ، استمر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (773, 'deleted', 'Deleted', 'تم الحذف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (774, 'collect', 'Collect', 'تجميع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (775, 'school_setting', 'School Setting', 'إعداد المدرسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (776, 'set', 'Set', 'جلس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (777, 'quick_view', 'Quick View', 'نظرة سريعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (778, 'due_fees_invoice', 'Due Fees Invoice', 'فاتورة رسوم مستحقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (779, 'my_application', 'My Application', 'طلبي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (780, 'manage_application', 'Manage Application', 'إدارة الطلب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (781, 'leave', 'Leave', 'غادر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (782, 'live_class_rooms', 'Live Class Rooms', 'غرف الصف المباشر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (783, 'homework', 'Homework', 'واجب منزلي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (784, 'evaluation_report', 'Evaluation Report', 'تقرير التقييم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (785, 'exam_term', 'Exam Term', 'مصطلح الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (786, 'distribution', 'Distribution', 'توزيع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (787, 'exam_setup', 'Exam Setup', 'إعداد الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (788, 'sms', 'Sms', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (789, 'fees_type', 'Fees Type', 'نوع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (790, 'fees_group', 'Fees Group', 'مجموعة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (791, 'fine_setup', 'Fine Setup', 'الإعداد الجيد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (792, 'fees_reminder', 'Fees Reminder', 'تذكير بالرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (793, 'new_deposit', 'New Deposit', 'وديعة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (794, 'new_expense', 'New Expense', 'نفقة جديدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (795, 'all_transactions', 'All Transactions', 'كل الحركات المالية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (796, 'head', 'Head', 'رئيس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (797, 'fees_reports', 'Fees Reports', 'تقارير الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (798, 'fees_report', 'Fees Report', 'تقرير الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (799, 'receipts_report', 'Receipts Report', 'تقرير الإيصالات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (800, 'due_fees_report', 'Due Fees Report', 'تقرير الرسوم المستحقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (801, 'fine_report', 'Fine Report', 'تقرير جيد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (802, 'financial_reports', 'Financial Reports', 'تقارير مالية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (803, 'statement', 'Statement', 'بيان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (804, 'repots', 'Repots', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (805, 'expense', 'Expense', 'مصروف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (806, 'transitions', 'Transitions', 'الانتقالات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (807, 'sheet', 'Sheet', 'ورقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (808, 'income_vs_expense', 'Income Vs Expense', 'الدخل مقابل المصاريف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (809, 'attendance_reports', 'Attendance Reports', 'تقارير الحضور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (810, 'examination', 'Examination', 'فحص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (811, 'school_settings', 'School Settings', 'إعدادات المدرسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (812, 'role_permission', 'Role Permission', 'إذن الدور', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (813, 'cron_job', 'Cron Job', 'وظيفة كرون', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (814, 'custom_field', 'Custom Field', 'حقل مخصص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (815, 'enter_valid_email', 'Enter Valid Email', 'أدخل بريدًا إلكترونيًا صالحًا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (816, 'lessons', 'Lessons', 'الدروس', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (817, 'live_class', 'Live Class', 'فئة حية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (818, 'sl', 'Sl', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (819, 'meeting_id', 'Live Class', 'فئة حية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (820, 'start_time', 'Start Time', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (821, 'end_time', 'End Time', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (822, 'zoom_meeting_id', 'Zoom Meeting Id', 'تكبير / تصغير معرف الاجتماع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (823, 'zoom_meeting_password', 'Zoom Meeting Password', 'تكبير كلمة مرور الاجتماع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (824, 'time_slot', 'Time Slot', 'فسحة زمنية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (825, 'send_notification_sms', 'Send Notification Sms', 'إرسال رسالة إعلام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (826, 'host', 'Host', 'مضيف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (827, 'school', 'School', 'مدرسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (828, 'accounting_links', 'Accounting Links', 'روابط المحاسبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (829, 'applicant', 'Applicant', 'طالب وظيفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (830, 'apply_date', 'Apply Date', 'تاريخ تطبيق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (831, 'add_leave', 'Add Leave', 'أضف إجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (832, 'leave_date', 'Leave Date', 'تاريخ مغادرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (833, 'attachment', 'Attachment', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (834, 'comments', 'Comments', 'تعليقات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (835, 'staff_id', 'Staff Id', 'معرف الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (836, 'income_vs_expense_of', 'Income Vs Expense Of', 'دخل مقابل حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (837, 'designation_name', 'Designation Name', 'اسم التعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (838, 'already_taken', 'This %s already exists.', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (839, 'department_name', 'Department Name', 'اسم القسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (840, 'date_of_birth', 'Date Of Birth', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (841, 'bulk_delete', 'Bulk Delete', 'حذف مجمّع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (842, 'guardian_name', 'Guardian Name', 'اسم الوصي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (843, 'fees_progress', 'Fees Progress', 'رسوم التقدم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (844, 'evaluate', 'Evaluate', 'تقييم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (845, 'date_of_homework', 'Date Of Homework', 'تاريخ الواجب المنزلي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (846, 'date_of_submission', 'Date Of Submission', 'تاريخ التقديم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (847, 'student_fees_report', 'Student Fees Report', 'تقرير رسوم الطالب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (848, 'student_fees_reports', 'Student Fees Reports', 'تقارير رسوم الطلاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (849, 'due_date', 'Due Date', 'تاريخ الاستحقاق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (850, 'payment_date', 'Payment Date', 'موعد الدفع', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (851, 'payment_via', 'Payment Via', 'الدفع عن طريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (852, 'generate', 'Generate', 'انشاء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (853, 'print_date', 'Print Date', 'تاريخ الطباعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (854, 'bulk_sms_and_email', 'Bulk Sms And Email', 'الرسائل القصيرة والبريد الإلكتروني', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (855, 'campaign_type', 'Campaign Type', 'نوع الحملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (856, 'both', 'Both', 'على حد سواء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (857, 'regular', 'Regular', 'منتظم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (858, 'Scheduled', 'Scheduled', 'المقرر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (859, 'campaign', 'Campaign', 'حملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (860, 'campaign_name', 'Campaign Name', 'اسم الحملة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (861, 'sms_gateway', 'Sms Gateway', 'بوابة الرسائل القصيرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (862, 'recipients_type', 'Recipients Type', 'نوع المستلمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (863, 'recipients_count', 'Recipients Count', 'عدد المستلمين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (864, 'body', 'Body', 'الجسم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (865, 'guardian_already_exist', 'Guardian Already Exist', 'الوصي موجود بالفعل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (866, 'guardian', 'Guardian', 'وصي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (867, 'mother_name', 'Mother Name', 'اسم الأم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (868, 'bank_details', 'Bank Details', 'التفاصيل المصرفية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (869, 'skipped_bank_details', 'Skipped Bank Details', 'تخطي تفاصيل البنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (870, 'bank', 'Bank', 'مصرف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (871, 'holder_name', 'Holder Name', 'اسم صاحب التسجيل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (872, 'bank_branch', 'Bank Branch', 'فرع بنك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (873, 'custom_field_for', 'Custom Field For', 'حقل مخصص لـ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (874, 'label', 'Label', 'ضع الكلمة المناسبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (875, 'order', 'Order', 'طلب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (876, 'online_admission', 'Online Admission', 'القبول عبر الإنترنت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (877, 'field_label', 'Field Label', 'تسمية الميدان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (878, 'field_type', 'Field Label', 'تسمية الميدان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (879, 'default_value', 'Default Value', 'القيمة الافتراضية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (880, 'checked', 'Checked', 'التحقق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (881, 'unchecked', 'Unchecked', 'غير محدد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (882, 'roll_number', 'Roll Number', 'رقم اللفة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (883, 'add_rows', 'Add Rows', 'إضافة صفوف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (884, 'salary', 'Salary', 'راتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (885, 'basic', 'Basic', 'الأساسي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (886, 'allowance', 'Allowance', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (887, 'deduction', 'Deduction', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (888, 'net', 'Net', 'Net', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (889, 'activated_sms_gateway', 'Activated Sms Gateway', 'بوابة الرسائل القصيرة المنشّطة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (890, 'account_sid', 'Account Sid', 'حساب Sid', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (891, 'roles', 'Roles', 'الأدوار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (892, 'system_role', 'System Role', 'دور النظام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (893, 'permission', 'Permission', 'الإذن', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (894, 'edit_session', 'Edit Session', 'تحرير الجلسة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (895, 'transactions', 'Transactions', 'المعاملات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (896, 'default_account', 'Default Account', 'الحساب الافتراضي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (897, 'deposit', 'Deposit', 'الوديعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (898, 'acccount', 'Acccount', 'حساب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (899, 'role_permission_for', 'Role Permission For', 'إذن دور لـ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (900, 'feature', 'Feature', 'خاصية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (901, 'access_denied', 'Access Denied', 'تم الرفض', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (902, 'time_start', 'Time Start', 'وقت البدء', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (903, 'time_end', 'Time End', 'انتهى الوقت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (904, 'month_of_salary', 'Month Of Salary', 'شهر الراتب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (905, 'add_documents', 'Add Documents', 'أضف وثائق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (906, 'document_type', 'Document Type', 'نوع الوثيقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (907, 'document', 'Document', 'المستند', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (908, 'document_title', 'Document Title', 'عنوان الوثيقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (909, 'document_category', 'Document Category', 'فئة الوثيقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (910, 'exam_result', 'Exam Result', 'نتيجة الإمتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (911, 'my_annual_fee_summary', 'My Annual Fee Summary', 'ملخص رسومي السنوي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (912, 'book_manage', 'Book Manage', 'إدارة الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (913, 'add_leave_category', 'Add Leave Category', 'إضافة فئة إجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (914, 'edit_leave_category', 'Edit Leave Category', 'تحرير فئة الإجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (915, 'staff_role', 'Staff Role', 'دور الموظفين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (916, 'edit_assign', 'Edit Assign', 'تحرير تعيين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (917, 'view_report', 'View Report', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (918, 'rank_out_of_5', 'Rank Out Of 5', 'مرتبة من 5', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (919, 'hall_no', 'Hall No', 'القاعة رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (920, 'no_of_seats', 'No Of Seats', 'عدد المقاعد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (921, 'mark_distribution', 'Mark Distribution', 'توزيع مارك', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (922, 'exam_type', 'Exam Type', 'نوع الامتحان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (923, 'marks_and_grade', 'Marks And Grade', 'العلامات والدرجات', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (924, 'min_percentage', 'Min Percentage', 'النسبة المئوية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (925, 'max_percentage', 'Max Percentage', 'النسبة المئوية القصوى', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (926, 'cost_per_bed', 'Cost Per Bed', 'تكلفة السرير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (927, 'add_category', 'Add Category', 'إضافة فئة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (928, 'category_for', 'Category For', 'التصنيف لـ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (929, 'start_place', 'Start Place', 'ابدأ مكان', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (930, 'stop_place', 'Stop Place', 'مكان التوقف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (931, 'vehicle', 'Vehicle', 'مركبة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (932, 'select_multiple_vehicle', 'Select Multiple Vehicle', 'حدد مركبة متعددة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (933, 'book_details', 'Book Details', 'تفاصيل الكتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (934, 'issued_by', 'Issued By', 'أصدرت من قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (935, 'return_by', 'Return By', 'العودة بواسطة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (936, 'group', 'Group', 'مجموعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (937, 'individual', 'Individual', 'فرد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (938, 'recipients', 'Recipients', 'المستلمون', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (939, 'group_name', 'Group Name', 'أسم المجموعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (940, 'fee_code', 'Fee Code', 'كود الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (941, 'fine_type', 'Fine Type', 'نوع جيد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (942, 'fine_value', 'Fine Value', 'قيمة جيدة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (943, 'late_fee_frequency', 'Late Fee Frequency', 'تردد الرسوم المتأخرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (944, 'fixed_amount', 'Fixed Amount', 'مبلغ ثابت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (945, 'fixed', 'Fixed', 'ثابت', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (946, 'daily', 'Daily', 'اليومي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (947, 'weekly', 'Weekly', 'أسبوعي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (948, 'monthly', 'Monthly', 'شهريا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (949, 'annually', 'Annually', 'سنويا', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (950, 'first_select_the_group', 'First Select The Group', 'أولا حدد المجموعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (951, 'percentage', 'Percentage', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (952, 'value', 'Value', 'القيمة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (953, 'fee_group', 'Fee Group', 'مجموعة الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (954, 'due_invoice', 'Due Invoice', 'فاتورة مستحقة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (955, 'reminder', 'Reminder', 'تذكير', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (956, 'frequency', 'Frequency', 'تكرر', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (957, 'notify', 'Notify', 'أبلغ', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (958, 'before', 'Before', 'قبل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (959, 'after', 'After', 'بعد', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (960, 'number', 'Number', 'رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (961, 'ref_no', 'Ref No', 'مصدر رقم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (962, 'pay_via', 'Pay Via', 'ادفع عن طريق', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (963, 'ref', 'Ref', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (964, 'dr', 'Dr', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (965, 'cr', 'Cr', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (966, 'edit_book', 'Edit Book', 'تحرير كتاب', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (967, 'leaves', 'Leaves', 'اوراق اشجار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (968, 'leave_request', 'Leave Request', 'طلب إجازة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (969, 'this_file_type_is_not_allowed', 'This File Type Is Not Allowed', 'نوع الملف هذا غير مسموح به', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (970, 'error_reading_the_file', 'Error Reading The File', 'خطأ في قراءة الملف', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (971, 'staff', 'Staff', 'العاملين', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (972, 'waiting', 'Waiting', 'انتظار', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (973, 'live', 'Live', 'حي', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (974, 'by', 'By', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (975, 'host_live_class', 'Host Live Class', 'استضافة فئة مباشرة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (976, 'join_live_class', 'Join Live Class', 'انضم إلى Live Class', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (977, 'system_logo', 'System Logo', 'شعار النظام', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (978, 'text_logo', 'Text Logo', 'شعار النص', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (979, 'printing_logo', 'Printing Logo', 'شعار الطباعة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (980, 'expired', 'Expired', 'منتهية الصلاحية', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (981, 'collect_fees', 'Collect Fees', 'تحصيل الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (982, 'fees_code', 'Fees Code', 'كود الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (983, 'collect_by', 'Collect By', 'اجمع بواسطة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (984, 'fee_payment', 'Fee Payment', 'دفع الرسوم', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (985, 'write_message', 'Write Message', 'اكتب رسالة', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (986, 'discard', 'Discard', 'تجاهل', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (987, 'message_sent_successfully', 'Message Sent Successfully', 'تم إرسال الرسالة بنجاح', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (988, 'not_found_anything', 'Not Found Anything', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (989, 'email_subject', 'Email Subject', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (990, 'certificate', 'Certificate', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (991, 'templete', 'Templete', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (992, 'advance_salary_request', 'Advance Salary Request', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (993, 'system_update', 'System Update', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (994, 'visit_home_page', 'Visit Home Page', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (995, 'frontend', 'Frontend', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (996, 'setting', 'Setting', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (997, 'menu', 'Menu', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (998, 'page', 'Page', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (999, 'manage', 'Manage', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1000, 'slider', 'Slider', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1001, 'features', 'Features', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1002, 'testimonial', 'Testimonial', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1003, 'service', 'Service', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1004, 'faq', 'Faq', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1005, 'card_management', 'Card Management', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1006, 'id_card', 'Id Card', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1007, 'admit_card', 'Admit Card', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1008, 'update_now', 'Update Now', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1009, 'usename', 'Usename', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1010, 'website_page', 'Website Page', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1011, 'welcome', 'Welcome', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1012, 'services', 'Services', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1013, 'call_to_action_section', 'Call To Action Section', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1014, 'subtitle', 'Subtitle', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1015, 'cta', 'Cta', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1016, 'button_text', 'Button Text', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1017, 'button_url', 'Button Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1018, '_title', ' Title', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1019, 'meta', 'Meta', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1020, 'keyword', 'Keyword', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1021, 'position', 'Position', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1022, 'target_new_window', 'Target New Window', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1023, 'external_url', 'External Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1024, 'external_link', 'External Link', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1025, 'submit', 'Submit', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1026, 'appointment', 'Appointment', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1027, 'banner_photo', 'Banner Photo', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1028, 'contact', 'Contact', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1029, 'box_title', 'Box Title', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1030, 'box_description', 'Box Description', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1031, 'box_photo', 'Box Photo', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1032, 'form_title', 'Form Title', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1033, 'submit_button_text', 'Submit Button Text', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1034, 'map_iframe', 'Map Iframe', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1035, 'guardian_relation', 'Guardian Relation', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1036, 'button_text_1', 'Button Text 1', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1037, 'button_url_1', 'Button Url 1', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1038, 'button_text_2', 'Button Text 2', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1039, 'button_url_2', 'Button Url 2', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1040, 'left', 'Left', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1041, 'center', 'Center', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1042, 'right', 'Right', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1043, 'about', 'About', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1044, 'content', 'Content', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1045, 'about_photo', 'About Photo', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1046, 'parallax_photo', 'Parallax Photo', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1047, 'audition', 'Audition', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1048, 'show_website', 'Show Website', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1049, 'image', 'Image', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1050, 'experience_details', 'Experience Details', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1051, 'total_experience', 'Total Experience', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1052, 'class_schedule', 'Class Schedule', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1053, 'play', 'Play', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1054, 'video', 'Video', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1055, 'website', 'Website', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1056, 'cms', 'Cms', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1057, 'url_alias', 'Url Alias', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1058, 'cms_frontend', 'Cms Frontend', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1059, 'enabled', 'Enabled', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1060, 'receive_email_to', 'Receive Email To', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1061, 'captcha_status', 'Captcha Status', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1062, 'recaptcha_site_key', 'Recaptcha Site Key', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1063, 'recaptcha_secret_key', 'Recaptcha Secret Key', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1064, 'working_hours', 'Working Hours', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1065, 'fav_icon', 'Fav Icon', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1066, 'theme', 'Theme', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1067, 'fax', 'Fax', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1068, 'footer_about_text', 'Footer About Text', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1069, 'copyright_text', 'Copyright Text', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1070, 'facebook_url', 'Facebook Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1071, 'twitter_url', 'Twitter Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1072, 'youtube_url', 'Youtube Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1073, 'google_plus', 'Google Plus', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1074, 'linkedin_url', 'Linkedin Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1075, 'pinterest_url', 'Pinterest Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1076, 'instagram_url', 'Instagram Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1077, 'edit_attachments', 'Edit Attachments', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1078, 'cms_default_branch', 'Cms Default Branch', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1079, 'prefix', 'Prefix', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1080, 'url', 'Url', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1081, 'language_unpublished', 'Language Unpublished', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1082, 'you_are_now_using_the_latest_version', 'You Are Now Using The Latest Version', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1083, 'applicable_user', 'Applicable User', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1084, 'page_layout', 'Page Layout', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1085, 'background', 'Background', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1086, 'signature', 'Signature', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1087, 'edit_branch', 'Edit Branch', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1088, 'create_section', 'Create Section', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1089, 'section_list', 'Section List', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1090, 'edit_section', 'Edit Section', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1091, 'teacher_restricted', 'Teacher Restricted', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1092, 'no_sms_gateway_available', 'No Sms Gateway Available', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1093, 'SMS configuration not found', 'SMS Configuration Not Found', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1094, 'username_has_already_been_used', 'Username Has Already Been Used', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1095, 'certificate_name', 'Certificate Name', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1096, 'no_fees_have_been_allocated', 'No Fees Have Been Allocated', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1097, 'teachers_list', 'Teachers List', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1098, 'my_child', 'My Child', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1099, 'surname', 'Surname', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1100, 'rank', 'Rank', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1101, 'unpublished_on_website', 'Unpublished On Website', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1102, 'published_on_website', 'Published On Website', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1103, 'language_published', 'Language Published', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1104, 'select_for_everyone', 'Select For Everyone', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1105, 'parents_profile', 'Parents Profile', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1106, 'childs', 'Childs', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1107, 'fee_collection', 'Fee Collection', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1108, 'room_category', 'Room Category', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1109, 'hostels_room_edit', 'Hostels Room Edit', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1110, 'edit_room', 'Edit Room', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1111, 'student_promotion', 'Student Promotion', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1112, 'the_next_session_was_transferred_to_the_students', 'The Next Session Was Transferred To The Students', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1113, 'promote_to_session', 'Promote To Session', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1114, 'promote_to_class', 'Promote To Class', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1115, 'promote_to_section', 'Promote To Section', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1116, 'mark_summary', 'Mark Summary', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1117, 'layout_width', 'Layout Width', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1118, 'layout_height', 'Layout Height', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1119, 'width', 'Width', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1120, 'height', 'Height', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1121, 'expiry_date', 'Expiry Date', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1122, 'translation_update', 'Translation Update', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1123, ' live_class_reports', ' Live Class Reports', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1124, 'live_class_method', 'Live Class Method', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1125, 'set_record', 'Set Record', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1126, 'set_mute_on_start', 'Set Mute On Start', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1127, 'duration', 'Duration', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1128, 'live_class_reports', 'Live Class Reports', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1129, 'student_participation_report', 'Student Participation Report', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1130, 'api_credential', 'Api Credential', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1131, 'preloader_backend', 'Preloader Backend', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1132, 'payment_details', 'Payment Details', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1133, 'leave_days', 'Leave Days', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1134, 'all', 'All', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1135, 'belongs_to', 'Belongs To', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1136, 'bs_column', 'Bs Column', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1137, 'field_order', 'Field Order', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1138, 'total_dr', 'Total Dr', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1139, 'total_cr', 'Total Cr', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1140, 'today_or_the_previous_day_can_not_be_issued', 'Today Or The Previous Day Can Not Be Issued', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1141, 'Meeting Not Found.', 'Meeting Not Found.', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1142, 'change', 'Change', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1143, 'password_has_been_changed', 'Password Has Been Changed', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1144, 'current_password_is_invalid', 'Current Password Is Invalid', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1145, 'schedule_date', 'Schedule Date', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1146, 'schedule_time', 'Schedule Time', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1147, 'hostels', 'Hostels', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1148, 'there_is_no_room_allocation', 'There Is No Room Allocation', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1149, 'card_number', 'Card Number', '', NULL);
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `lang_32`) VALUES (1150, 'fees_pay_now', 'Fees Pay Now', '', NULL);


#
# TABLE STRUCTURE FOR: leave_application
#

DROP TABLE IF EXISTS `leave_application`;

CREATE TABLE `leave_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `category_id` int(2) NOT NULL,
  `reason` longtext CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `leave_days` varchar(20) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '1' COMMENT '1=pending,2=accepted 3=rejected',
  `apply_date` date DEFAULT NULL,
  `approved_by` int(11) NOT NULL,
  `orig_file_name` varchar(255) NOT NULL,
  `enc_file_name` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `session_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: leave_category
#

DROP TABLE IF EXISTS `leave_category`;

CREATE TABLE `leave_category` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `role_id` tinyint(1) NOT NULL,
  `days` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `leave_category` (`id`, `name`, `role_id`, `days`, `branch_id`) VALUES (1, 'Sick Leave', 3, 7, 1);
INSERT INTO `leave_category` (`id`, `name`, `role_id`, `days`, `branch_id`) VALUES (2, 'Sick Leave', 4, 7, 1);
INSERT INTO `leave_category` (`id`, `name`, `role_id`, `days`, `branch_id`) VALUES (3, 'Sick Leave', 2, 7, 1);
INSERT INTO `leave_category` (`id`, `name`, `role_id`, `days`, `branch_id`) VALUES (4, 'Sick Leave', 5, 7, 1);
INSERT INTO `leave_category` (`id`, `name`, `role_id`, `days`, `branch_id`) VALUES (5, 'Casual Leave', 2, 3, 1);
INSERT INTO `leave_category` (`id`, `name`, `role_id`, `days`, `branch_id`) VALUES (6, 'Casual Leave', 5, 3, 1);
INSERT INTO `leave_category` (`id`, `name`, `role_id`, `days`, `branch_id`) VALUES (7, 'Public Holiday', 7, 3, 1);
INSERT INTO `leave_category` (`id`, `name`, `role_id`, `days`, `branch_id`) VALUES (8, 'Paternity Leave', 3, 90, 1);


#
# TABLE STRUCTURE FOR: live_class
#

DROP TABLE IF EXISTS `live_class`;

CREATE TABLE `live_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `live_class_method` tinyint(1) DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `meeting_id` varchar(255) NOT NULL,
  `meeting_password` varchar(255) NOT NULL,
  `own_api_key` tinyint(1) DEFAULT '0',
  `duration` int(11) DEFAULT '0',
  `bbb` longtext NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` varchar(11) NOT NULL,
  `remarks` text NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_by` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `live_class` (`id`, `live_class_method`, `title`, `meeting_id`, `meeting_password`, `own_api_key`, `duration`, `bbb`, `class_id`, `section_id`, `remarks`, `date`, `start_time`, `end_time`, `created_by`, `status`, `created_at`, `branch_id`) VALUES (1, 1, 'Live Class tester', '5501540696', 'booty', 0, 0, '', 1, '[\"1\"]', 'Revision', '2020-10-02', '13:30:00', '13:30:00', 1, 0, '2020-09-29 13:34:23', 1);
INSERT INTO `live_class` (`id`, `live_class_method`, `title`, `meeting_id`, `meeting_password`, `own_api_key`, `duration`, `bbb`, `class_id`, `section_id`, `remarks`, `date`, `start_time`, `end_time`, `created_by`, `status`, `created_at`, `branch_id`) VALUES (2, 2, 'Mathematics Midterm', 'adn-5tx-wx6-rdo', '', 0, 30, '{\"attendee_password\":\"bcd53b\",\"moderator_password\":\"6f85d2\",\"max_participants\":\"30\",\"mute_on_start\":1,\"set_record\":1}', 1, '[\"1\"]', '', '2021-01-12', '15:30:00', '16:00:00', 1, 0, '2021-01-12 14:21:15', 1);


#
# TABLE STRUCTURE FOR: live_class_config
#

DROP TABLE IF EXISTS `live_class_config`;

CREATE TABLE `live_class_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zoom_api_key` varchar(255) DEFAULT NULL,
  `zoom_api_secret` varchar(255) NOT NULL,
  `bbb_salt_key` varchar(355) DEFAULT NULL,
  `bbb_server_base_url` varchar(355) DEFAULT NULL,
  `staff_api_credential` tinyint(1) NOT NULL DEFAULT '0',
  `student_api_credential` tinyint(1) NOT NULL DEFAULT '0',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `live_class_config` (`id`, `zoom_api_key`, `zoom_api_secret`, `bbb_salt_key`, `bbb_server_base_url`, `staff_api_credential`, `student_api_credential`, `branch_id`) VALUES (1, 'G-W8fkvLQpmFh0sETSEe2g', 'JC0wDJFlnKAcwx3o3kzB8bL5YyVwSGq6pSeP', '606485', 'https://demo.bigbluebutton.org/gl/adn-5tx-wx6-rdo/', 1, 1, 1);


#
# TABLE STRUCTURE FOR: live_class_reports
#

DROP TABLE IF EXISTS `live_class_reports`;

CREATE TABLE `live_class_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `live_class_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: login_credential
#

DROP TABLE IF EXISTS `login_credential`;

CREATE TABLE `login_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` tinyint(2) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1(active) 0(deactivate)',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (1, 1, 'babaahmedadnan@gmail.com', '$2y$10$E//IhTVVxR0nDINcsGqP3uO6a5zC7dRXkfn2iK2AUqeI7DK.GEhSu', 1, 1, '2021-01-26 11:03:24', '2020-07-15 13:44:05', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (2, 2, 'alfaky', '$2y$10$UJ68GGj9OOL2SLF.6/luF.u1SgUPKaLC1C0q4Pf7h0/dHRWhBlaku', 3, 1, '2021-01-20 12:48:46', '2020-07-15 15:44:50', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (3, 3, 'adnanu', '$2y$10$rfQQmJ/aHTP7pQT.HpLrDOg5fIA.Q0P22tl4Yjb0oeR4HIfED/Khm', 2, 1, '2020-07-16 15:02:02', '2020-07-16 11:40:31', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (4, 4, 'abba', '$2y$10$rUFwqfQ6LJm2uXZ0EGYnzuNmxYKl5B1XJTD5Q1nrMNSQ63eaSt4lG', 4, 1, '2021-01-17 22:16:13', '2020-07-16 15:10:10', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (5, 5, 'umar', '$2y$10$iGfb6R07ui34rn.vk/M5C..oFEY04UyKzb7nHOGnd0r/UNg3aO3RS', 5, 1, '2020-11-06 17:42:33', '2020-07-16 15:17:31', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (9, 6, 'founder@acce-abuja.com.ng', '$2y$10$1rE6Z0vrIfAMXNPwi/zS6.vobClFbSC4fQzea3fOkw9bfI33ryobS', 9, 1, '2021-01-15 12:57:07', '2020-11-06 09:47:01', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (10, 3, 'Alfaqs@gmail.com', '$2y$10$PLx63NX7EYZyfdQY1P4gquOUSgspTJ4uHsp9K5sUhWF6jN5tDIb2K', 7, 1, NULL, '2020-11-14 15:21:22', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (11, 7, 'magaji.maryam@acce-abuja.com.ng', '$2y$10$W2.mNf863XBLY6h0savb9eE2GlE.tOWj966e7XInwyqMgq8RX8ZEO', 2, 1, '2021-01-25 10:45:09', '2021-01-13 10:49:50', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (12, 8, 'odachi.cosmas@acce-abuja.com.ng', '$2y$10$rJ17wq23MpuSOAo3upaSz.xA5nUH0Ff0N2O7b/c/cxgxLZkq/WgzK', 3, 1, '2021-01-13 15:37:37', '2021-01-13 12:48:52', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (13, 9, 'osinachi.nwosu@acce-abuja.com.ng', '$2y$10$iRwXC83ow2QgVWnZqv056evLZZTV8d49yqP/aOYbtAwIiutr0qSgm', 3, 1, '2021-01-14 10:08:36', '2021-01-13 12:58:36', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (14, 10, 'fareedah.yousuf@acce-abuja.com.ng', '$2y$10$mWN4zUFE5qdyFglX1uIwAexc9cyFqjAQK5Hc69EvS/bJBZAiS/RKS', 3, 1, '2021-01-13 14:41:16', '2021-01-13 13:11:52', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (15, 11, 'abduljelil.rafiyat@acce-abuja.com.ng', '$2y$10$Ao85wXqVGgkpiiAwUl39ee6Eb2X0QhFAiFPmpJmb6mbD0xA5pSf2.', 3, 1, '2021-01-13 17:43:22', '2021-01-13 13:16:53', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (16, 12, 'sherifat.aliya@acce-abuja.com.ng', '$2y$10$uFsmeGkTGvs.gW2RoTTgrOdUaYoppd3mHcrDscIQMz2SjQAQD7/1q', 3, 1, '2021-01-21 13:28:56', '2021-01-13 13:18:49', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (17, 13, 'mefogune.emuejeraye@acce-abuja.com.ng', '$2y$10$KBAAVGxaPa.X6jOEIG0HE.s4RFAjg8Gyf4cTK889PUwufgQS20ZuO', 3, 1, '2021-01-14 12:19:04', '2021-01-13 13:26:15', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (18, 14, 'yusuf.abolaji@acce-abuja.com.ng', '$2y$10$1Jir9Sgmf87JRayv0LR2GeozXTT96fA81Ukz3HtmqzNPODFZX8cdW', 3, 1, '2021-01-18 11:31:50', '2021-01-13 13:27:22', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (19, 15, 'bashirat.oduola@acce-abuja.com.ng', '$2y$10$BtnK4WsOAaIbNJ32OXM9DeUySIuCxofV/8vPoNJcSBYym64ALtxpm', 3, 1, '2021-01-13 14:44:22', '2021-01-13 13:36:03', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (20, 16, 'ibrahim.kayode@acce-abuja.com.ng', '$2y$10$4poXBmSdNTwQu92Ne67anOLVtTJlU/G7h2Ag22BqdxuHCsGH9YrCW', 3, 1, '2021-01-13 14:42:35', '2021-01-13 13:40:51', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (21, 17, 'abduljelil.oladebo@acce-abuja.com.ng', '$2y$10$7gQI2gCmUdMF1.Av.INLSO/BaakGZ8RPMvjdXjBb/4M20xJpXm3Ei', 3, 1, '2021-01-13 17:41:47', '2021-01-13 13:42:47', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (22, 18, 'muhammad.nasir@acce-abuja.com.ng', '$2y$10$Ci2u1nVmsiNFYbWburIAIebv6jjZgx/ni4ne26vg4IZjWuhIqDoui', 3, 1, '2021-01-19 13:03:19', '2021-01-13 13:46:24', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (23, 19, 'asiya.mukhtar@acce-abuja.com.ng', '$2y$10$PKeKmQmVTuUj/8wnmzJx/OHVuzXYfUlqjofpi2isqJzkKVn0PWUZa', 3, 1, '2021-01-16 00:38:00', '2021-01-13 13:47:41', NULL);


#
# TABLE STRUCTURE FOR: mark
#

DROP TABLE IF EXISTS `mark`;

CREATE TABLE `mark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `mark` text,
  `absent` varchar(4) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: message
#

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `subject` varchar(255) NOT NULL,
  `file_name` text,
  `enc_name` text,
  `trash_sent` tinyint(1) NOT NULL,
  `trash_inbox` int(11) NOT NULL,
  `fav_inbox` tinyint(1) NOT NULL,
  `fav_sent` tinyint(1) NOT NULL,
  `reciever` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 unread 1 read',
  `reply_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 unread 1 read',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (1, '<p>Hello</p>', 'GSuite integration and main domain not responding', 'acce-logo.png', '461e4c607b649f0d58f00d4264aac78d.png', 0, 0, 0, 0, '3-2', '1-1', 1, 0, '2020-07-16 16:58:46', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (2, '<p>Hello Login</p>', 'Login Problems', NULL, NULL, 0, 0, 0, 0, '2-3', '7-2', 0, 0, '2020-09-28 14:28:22', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (3, '<p>Send users prices</p>', 'How much for the users?', NULL, NULL, 0, 0, 0, 1, '4-4', '1-1', 1, 0, '2020-09-29 14:20:25', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (4, '<p>4589484yuituyuyuy</p>', 'How much for the users?', 'd2716a265b93ba536f2cc3bf9a176141.JPG', '52cea6fb46a30494f13d225323e0d1b9.JPG', 0, 0, 0, 0, '3-2', '1-1', 1, 0, '2020-10-13 14:20:22', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (5, '<p>Testing</p>', 'How much for the users?', NULL, NULL, 0, 0, 0, 0, '3-2', '5-5', 1, 0, '2020-10-26 12:50:29', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (6, '<p>user_login: founder@acce-abuja.com.ng</p><p>user_pass: founder</p>', 'Founder’s ACCE-Abuja School Portal Activation', NULL, NULL, 0, 0, 0, 0, '9-6', '1-1', 1, 0, '2020-11-06 09:56:20', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (7, '<p>Hope, you are understanding the traing</p>', 'communication', NULL, NULL, 1, 0, 0, 0, '3-10', '3-18', 1, 0, '2021-01-13 15:03:34', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (8, '<p>fffrg<br></p>', 'aa', NULL, NULL, 0, 0, 0, 0, '3-9', '3-2', 0, 0, '2021-01-13 15:03:53', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (9, '<p>aser ebja but adf hfiadhnkjh f jdvj rlj ,jg dh dkvn icnodefjavksnh aniefi</p>', 'prompt attention', NULL, NULL, 0, 0, 0, 0, '3-8', '3-14', 1, 0, '2021-01-13 15:04:21', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (10, 'sir', 'from Mefo', NULL, NULL, 0, 0, 0, 0, '3-18', '3-13', 1, 0, '2021-01-13 15:04:24', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (11, '<p>Mrs Abduljelil</p>', 'Hello', NULL, NULL, 0, 0, 0, 0, '3-11', '3-19', 1, 0, '2021-01-13 15:04:25', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (12, '<p>welcome to ACCE Gwarimpa</p>', 'Hello', NULL, NULL, 0, 0, 0, 0, '3-17', '3-16', 0, 0, '2021-01-13 15:04:25', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (13, '<p>Salamualaikum warahmatullah</p>', 'Greetings', NULL, NULL, 0, 0, 0, 0, '3-16', '3-17', 0, 0, '2021-01-13 15:04:27', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (14, '<p>yrf</p>', 'km', NULL, NULL, 0, 0, 0, 0, '3-2', '3-14', 0, 0, '2021-01-13 15:04:56', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (15, '<p>How are you coping with the training?<br></p>', 'progress', NULL, NULL, 0, 0, 0, 0, '3-15', '3-9', 1, 0, '2021-01-13 15:04:56', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (16, '<p>GOOD AFTERNOON MA. TRUST YOU ARE FINE.</p>', 'GREETINGS', NULL, NULL, 0, 0, 0, 0, '3-19', '3-11', 1, 0, '2021-01-13 15:05:05', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (17, '<p>i write to inform of the meeting on Monday for inter house sports event</p>', 'love later', NULL, NULL, 0, 0, 0, 0, '3-14', '3-8', 1, 0, '2021-01-13 15:05:12', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (18, '<p>Salamualaikum warahmatullah</p>', 'Greetings', NULL, NULL, 0, 0, 0, 0, '3-16', '3-17', 0, 0, '2021-01-13 15:05:17', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (19, '<p>Salamualaikum warahmatullah</p>', 'Greetings', NULL, NULL, 0, 0, 0, 0, '3-16', '3-17', 0, 0, '2021-01-13 15:05:34', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (20, '<p>Hello mr Osi,</p><p>send me a copy of the lesson plan pls</p>', 'lesson plan', NULL, NULL, 0, 0, 0, 0, '3-9', '3-15', 0, 0, '2021-01-13 15:05:41', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (21, '<p>Salamualaikum warahmatullah</p>', 'Greetings', NULL, NULL, 0, 0, 0, 0, '3-16', '3-17', 0, 0, '2021-01-13 15:05:49', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (22, '<p>Salamualaikum warahmatullah</p>', 'Greetings', NULL, NULL, 0, 0, 0, 0, '3-16', '3-17', 1, 0, '2021-01-13 15:06:07', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (23, '<p>Hello mr Osi,</p><p>send me a copy of the lesson plan pls</p>', 'lesson plan', NULL, NULL, 0, 0, 0, 0, '3-9', '3-15', 0, 0, '2021-01-13 15:06:40', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (24, '<p>Hello mr Osi,</p><p>send me a copy of the lesson plan pls</p>', 'lesson plan', NULL, NULL, 0, 0, 0, 0, '3-9', '3-15', 0, 0, '2021-01-13 15:06:59', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (25, '<p>Hello mr Osi,</p><p>send me a copy of the lesson plan pls</p>', 'lesson plan', NULL, NULL, 0, 0, 0, 0, '3-9', '3-15', 0, 0, '2021-01-13 15:07:10', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (26, '<p>Salamualaikum</p>', 'greetings', NULL, NULL, 0, 0, 0, 0, '3-11', '3-17', 1, 0, '2021-01-13 15:07:24', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (27, '<p>Salamualaikum</p>', 'greetings', NULL, NULL, 0, 0, 0, 0, '3-11', '3-17', 1, 0, '2021-01-13 15:07:33', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (28, '<p>good day sir<br></p>', 'sir', NULL, NULL, 0, 0, 0, 0, '3-8', '3-13', 1, 0, '2021-01-13 15:07:42', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (29, '<p>Hi Ms Maryam, hope you are following the training?</p>', 'hello!', NULL, NULL, 0, 0, 0, 1, '2-7', '3-10', 1, 1, '2021-01-13 15:08:09', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (30, '<p>remember that minus god , there can be no permanent peace and joy of heart</p>', 'miracle in action', NULL, NULL, 0, 0, 0, 0, '3-9', '3-8', 1, 0, '2021-01-13 15:22:43', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (31, '<p>please permit me to host a live class with you</p>', 'Maths lesson', NULL, NULL, 0, 0, 0, 0, '2-7', '3-18', 1, 0, '2021-01-13 16:32:56', NULL);
INSERT INTO `message` (`id`, `body`, `subject`, `file_name`, `enc_name`, `trash_sent`, `trash_inbox`, `fav_inbox`, `fav_sent`, `reciever`, `sender`, `read_status`, `reply_status`, `created_at`, `updated_at`) VALUES (32, '<p>Dear Ms. Maryam, </p><p>Please accept this as a formal notification of my absence from tomorrow’s training. I got to know that there would be training tomorrow, later in the week after which I had already planned an urgent trip out of town. </p><p>Please let me know if you need anything from me to make my absence run smoothly. </p><p>Sincerely, </p><p>Ms. Asiya</p>', 'Permission', NULL, NULL, 0, 0, 0, 0, '2-7', '3-19', 1, 0, '2021-01-16 00:55:31', NULL);


#
# TABLE STRUCTURE FOR: message_reply
#

DROP TABLE IF EXISTS `message_reply`;

CREATE TABLE `message_reply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `file_name` text NOT NULL,
  `enc_name` text NOT NULL,
  `identity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `message_reply` (`id`, `message_id`, `body`, `file_name`, `enc_name`, `identity`, `created_at`) VALUES (1, 7, '<p>yes i am. thank you. are u following too?</p>', '', '', 0, '2021-01-13 15:05:17');
INSERT INTO `message_reply` (`id`, `message_id`, `body`, `file_name`, `enc_name`, `identity`, `created_at`) VALUES (2, 7, '<p>yes i am. thank you. are u following too?</p>', '', '', 0, '2021-01-13 15:05:36');
INSERT INTO `message_reply` (`id`, `message_id`, `body`, `file_name`, `enc_name`, `identity`, `created_at`) VALUES (3, 9, '<p>I could not understand your hand writing yssuf</p>', '', '', 0, '2021-01-13 15:07:01');
INSERT INTO `message_reply` (`id`, `message_id`, `body`, `file_name`, `enc_name`, `identity`, `created_at`) VALUES (4, 29, '<p>yes ma</p>', '', '', 0, '2021-01-13 15:15:18');


#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`version`) VALUES ('305');


#
# TABLE STRUCTURE FOR: online_admission
#

DROP TABLE IF EXISTS `online_admission`;

CREATE TABLE `online_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `birthday` date NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `guardian_name` varchar(255) NOT NULL,
  `guardian_relation` varchar(50) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `mother_name` varchar(255) NOT NULL,
  `grd_occupation` varchar(255) NOT NULL,
  `grd_income` varchar(25) NOT NULL,
  `grd_education` varchar(255) NOT NULL,
  `grd_email` varchar(255) NOT NULL,
  `grd_mobile_no` varchar(50) NOT NULL,
  `grd_address` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '1',
  `branch_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `apply_date` datetime NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: parent
#

DROP TABLE IF EXISTS `parent`;

CREATE TABLE `parent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `relation` varchar(255) NOT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `occupation` varchar(100) NOT NULL,
  `income` varchar(100) NOT NULL,
  `education` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) NOT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `active` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0(active) 1(deactivate)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: payment_config
#

DROP TABLE IF EXISTS `payment_config`;

CREATE TABLE `payment_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paypal_username` varchar(255) DEFAULT NULL,
  `paypal_password` varchar(255) DEFAULT NULL,
  `paypal_signature` varchar(255) DEFAULT NULL,
  `paypal_email` varchar(255) DEFAULT NULL,
  `paypal_sandbox` tinyint(4) DEFAULT NULL,
  `paypal_status` tinyint(4) DEFAULT NULL,
  `stripe_secret` varchar(255) DEFAULT NULL,
  `stripe_demo` varchar(255) DEFAULT NULL,
  `stripe_status` tinyint(4) DEFAULT NULL,
  `payumoney_key` varchar(255) DEFAULT NULL,
  `payumoney_salt` varchar(255) DEFAULT NULL,
  `payumoney_demo` tinyint(4) DEFAULT NULL,
  `payumoney_status` tinyint(4) DEFAULT NULL,
  `paystack_secret_key` varchar(255) NOT NULL,
  `paystack_status` tinyint(4) NOT NULL,
  `razorpay_key_id` varchar(255) NOT NULL,
  `razorpay_key_secret` varchar(255) NOT NULL,
  `razorpay_demo` tinyint(4) NOT NULL,
  `razorpay_status` tinyint(4) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `payment_config` (`id`, `paypal_username`, `paypal_password`, `paypal_signature`, `paypal_email`, `paypal_sandbox`, `paypal_status`, `stripe_secret`, `stripe_demo`, `stripe_status`, `payumoney_key`, `payumoney_salt`, `payumoney_demo`, `payumoney_status`, `paystack_secret_key`, `paystack_status`, `razorpay_key_id`, `razorpay_key_secret`, `razorpay_demo`, `razorpay_status`, `branch_id`, `created_at`, `updated_at`) VALUES (1, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 2, NULL, NULL, NULL, 2, 'sk_live_859f48f15b724419e5f13514c0f2749d36676610', 1, '', '', 0, 2, 1, '2020-07-16 15:35:35', NULL);


#
# TABLE STRUCTURE FOR: payment_salary_stipend
#

DROP TABLE IF EXISTS `payment_salary_stipend`;

CREATE TABLE `payment_salary_stipend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: payment_types
#

DROP TABLE IF EXISTS `payment_types`;

CREATE TABLE `payment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (1, 'Cash', 0, '2019-07-27 18:12:21');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (2, 'Card', 0, '2019-07-27 18:12:31');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (3, 'Cheque', 0, '2019-12-21 10:07:59');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (4, 'Bank Transfer', 0, '2019-12-21 10:08:36');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (5, 'Other', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (6, 'Paypal', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (7, 'Stripe', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (8, 'PayUmoney', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (9, 'Paystack', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (10, 'Razorpay', 0, '2019-12-21 10:08:45');


#
# TABLE STRUCTURE FOR: payslip
#

DROP TABLE IF EXISTS `payslip`;

CREATE TABLE `payslip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `month` varchar(200) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL,
  `total_allowance` decimal(18,2) NOT NULL,
  `total_deduction` decimal(18,2) NOT NULL,
  `net_salary` decimal(18,2) NOT NULL,
  `bill_no` varchar(25) NOT NULL,
  `remarks` text NOT NULL,
  `pay_via` tinyint(1) NOT NULL,
  `hash` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paid_by` varchar(200) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `payslip` (`id`, `staff_id`, `month`, `year`, `basic_salary`, `total_allowance`, `total_deduction`, `net_salary`, `bill_no`, `remarks`, `pay_via`, `hash`, `created_at`, `paid_by`, `branch_id`) VALUES (1, 2, '10', '2020', '70000.00', '65000.00', '0.00', '135000.00', '0001', '', 2, '5ae8e97982fa8c3cc5a1176bfe1f91a4', '2020-10-08 13:33:02', '1', 1);
INSERT INTO `payslip` (`id`, `staff_id`, `month`, `year`, `basic_salary`, `total_allowance`, `total_deduction`, `net_salary`, `bill_no`, `remarks`, `pay_via`, `hash`, `created_at`, `paid_by`, `branch_id`) VALUES (2, 2, '12', '2020', '70000.00', '65000.00', '0.00', '135000.00', '0002', '', 4, 'f202807caf4d1d0a18c3f867c6918af9', '2020-12-21 19:10:21', '4', 1);


#
# TABLE STRUCTURE FOR: payslip_details
#

DROP TABLE IF EXISTS `payslip_details`;

CREATE TABLE `payslip_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `payslip_details` (`id`, `payslip_id`, `name`, `amount`, `type`) VALUES (1, 1, 'Transport', '50000.00', 1);
INSERT INTO `payslip_details` (`id`, `payslip_id`, `name`, `amount`, `type`) VALUES (2, 1, 'Food', '15000.00', 1);
INSERT INTO `payslip_details` (`id`, `payslip_id`, `name`, `amount`, `type`) VALUES (3, 2, 'Transport', '50000.00', 1);
INSERT INTO `payslip_details` (`id`, `payslip_id`, `name`, `amount`, `type`) VALUES (4, 2, 'Food', '15000.00', 1);


#
# TABLE STRUCTURE FOR: permission
#

DROP TABLE IF EXISTS `permission`;

CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prefix` varchar(100) NOT NULL,
  `show_view` tinyint(1) DEFAULT '1',
  `show_add` tinyint(1) DEFAULT '1',
  `show_edit` tinyint(1) DEFAULT '1',
  `show_delete` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (1, 2, 'Student', 'student', 1, 1, 1, 1, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (2, 2, 'Multiple Import', 'multiple_import', 0, 1, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (3, 2, 'Student Category', 'student_category', 1, 1, 1, 1, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (4, 2, 'Student Id Card', 'student_id_card', 1, 0, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (5, 2, 'Disable Authentication', 'student_disable_authentication', 1, 1, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (6, 4, 'Employee', 'employee', 1, 1, 1, 1, '2020-01-22 12:55:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (7, 3, 'Parent', 'parent', 1, 1, 1, 1, '2020-01-22 14:24:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (8, 3, 'Disable Authentication', 'parent_disable_authentication', 1, 1, 0, 0, '2020-01-22 15:22:21');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (9, 4, 'Department', 'department', 1, 1, 1, 1, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (10, 4, 'Designation', 'designation', 1, 1, 1, 1, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (11, 4, 'Disable Authentication', 'employee_disable_authentication', 1, 1, 0, 0, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (12, 5, 'Salary Template', 'salary_template', 1, 1, 1, 1, '2020-01-23 06:13:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (13, 5, 'Salary Assign', 'salary_assign', 1, 1, 0, 0, '2020-01-23 06:14:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (14, 5, 'Salary Payment', 'salary_payment', 1, 1, 0, 0, '2020-01-24 07:45:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (15, 5, 'Salary Summary Report', 'salary_summary_report', 1, 0, 0, 0, '2020-03-14 18:09:17');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (16, 5, 'Advance Salary', 'advance_salary', 1, 1, 1, 1, '2020-01-28 19:23:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (17, 5, 'Advance Salary Manage', 'advance_salary_manage', 1, 1, 1, 1, '2020-01-25 05:57:12');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (18, 5, 'Advance Salary Request', 'advance_salary_request', 1, 1, 0, 1, '2020-01-28 18:49:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (19, 5, 'Leave Category', 'leave_category', 1, 1, 1, 1, '2020-01-29 03:46:23');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (20, 5, 'Leave Request', 'leave_request', 1, 1, 1, 1, '2020-01-30 13:06:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (21, 5, 'Leave Manage', 'leave_manage', 1, 1, 1, 1, '2020-01-29 08:27:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (22, 5, 'Award', 'award', 1, 1, 1, 1, '2020-01-31 19:49:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (23, 6, 'Classes', 'classes', 1, 1, 1, 1, '2020-02-01 19:10:00');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (24, 6, 'Section', 'section', 1, 1, 1, 1, '2020-02-01 22:06:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (25, 6, 'Assign Class Teacher', 'assign_class_teacher', 1, 1, 1, 1, '2020-02-02 08:09:22');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (26, 6, 'Subject', 'subject', 1, 1, 1, 1, '2020-02-03 05:32:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (27, 6, 'Subject Class Assign ', 'subject_class_assign', 1, 1, 1, 1, '2020-02-03 18:43:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (28, 6, 'Subject Teacher Assign', 'subject_teacher_assign', 1, 1, 0, 1, '2020-02-03 20:05:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (29, 6, 'Class Timetable', 'class_timetable', 1, 1, 1, 1, '2020-02-04 06:50:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (30, 2, 'Student Promotion', 'student_promotion', 1, 1, 0, 0, '2020-02-05 19:20:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (31, 8, 'Attachments', 'attachments', 1, 1, 1, 1, '2020-02-06 18:59:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (32, 7, 'Homework', 'homework', 1, 1, 1, 1, '2020-02-07 06:40:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (33, 8, 'Attachment Type', 'attachment_type', 1, 1, 1, 1, '2020-02-07 08:16:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (34, 9, 'Exam', 'exam', 1, 1, 1, 1, '2020-02-07 10:59:29');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (35, 9, 'Exam Term', 'exam_term', 1, 1, 1, 1, '2020-02-07 13:09:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (36, 9, 'Exam Hall', 'exam_hall', 1, 1, 1, 1, '2020-02-07 15:31:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (37, 9, 'Exam Timetable', 'exam_timetable', 1, 1, 0, 1, '2020-02-08 18:04:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (38, 9, 'Exam Mark', 'exam_mark', 1, 1, 1, 1, '2020-02-10 13:53:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (39, 9, 'Exam Grade', 'exam_grade', 1, 1, 1, 1, '2020-02-10 18:29:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (40, 10, 'Hostel', 'hostel', 1, 1, 1, 1, '2020-02-11 05:41:36');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (41, 10, 'Hostel Category', 'hostel_category', 1, 1, 1, 1, '2020-02-11 08:52:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (42, 10, 'Hostel Room', 'hostel_room', 1, 1, 1, 1, '2020-02-11 12:50:09');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (43, 10, 'Hostel Allocation', 'hostel_allocation', 1, 0, 0, 1, '2020-02-11 14:06:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (44, 11, 'Transport Route', 'transport_route', 1, 1, 1, 1, '2020-02-12 06:26:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (45, 11, 'Transport Vehicle', 'transport_vehicle', 1, 1, 1, 1, '2020-02-12 06:57:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (46, 11, 'Transport Stoppage', 'transport_stoppage', 1, 1, 1, 1, '2020-02-12 07:49:20');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (47, 11, 'Transport Assign', 'transport_assign', 1, 1, 1, 1, '2020-02-12 10:55:21');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (48, 11, 'Transport Allocation', 'transport_allocation', 1, 0, 0, 1, '2020-02-12 20:33:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (49, 12, 'Student Attendance', 'student_attendance', 0, 1, 0, 0, '2020-02-13 06:25:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (50, 12, 'Employee Attendance', 'employee_attendance', 0, 1, 0, 0, '2020-02-13 11:04:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (51, 12, 'Exam Attendance', 'exam_attendance', 0, 1, 0, 0, '2020-02-13 12:08:14');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (52, 12, 'Student Attendance Report', 'student_attendance_report', 1, 0, 0, 0, '2020-02-13 20:20:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (53, 12, 'Employee Attendance Report', 'employee_attendance_report', 1, 0, 0, 0, '2020-02-14 07:08:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (54, 12, 'Exam Attendance Report', 'exam_attendance_report', 1, 0, 0, 0, '2020-02-14 07:21:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (55, 13, 'Book', 'book', 1, 1, 1, 1, '2020-02-14 07:40:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (56, 13, 'Book Category', 'book_category', 1, 1, 1, 1, '2020-02-15 05:11:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (57, 13, 'Book Manage', 'book_manage', 1, 1, 0, 1, '2020-02-15 12:13:24');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (58, 13, 'Book Request', 'book_request', 1, 1, 0, 1, '2020-02-17 07:45:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (59, 14, 'Event', 'event', 1, 1, 1, 1, '2020-02-17 19:02:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (60, 14, 'Event Type', 'event_type', 1, 1, 1, 1, '2020-02-18 05:40:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (61, 15, 'Sendsmsmail', 'sendsmsmail', 1, 1, 0, 1, '2020-02-22 08:19:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (62, 15, 'Sendsmsmail Template', 'sendsmsmail_template', 1, 1, 1, 1, '2020-02-22 11:14:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (63, 17, 'Account', 'account', 1, 1, 1, 1, '2020-02-25 10:34:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (64, 17, 'Deposit', 'deposit', 1, 1, 1, 1, '2020-02-25 13:56:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (65, 17, 'Expense', 'expense', 1, 1, 1, 1, '2020-02-26 07:35:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (66, 17, 'All Transactions', 'all_transactions', 1, 0, 0, 0, '2020-02-26 14:35:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (67, 17, 'Voucher Head', 'voucher_head', 1, 1, 1, 1, '2020-02-25 11:50:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (68, 17, 'Accounting Reports', 'accounting_reports', 1, 1, 1, 1, '2020-02-25 14:36:24');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (69, 16, 'Fees Type', 'fees_type', 1, 1, 1, 1, '2020-02-27 11:11:03');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (70, 16, 'Fees Group', 'fees_group', 1, 1, 1, 1, '2020-02-26 06:49:09');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (71, 16, 'Fees Fine Setup', 'fees_fine_setup', 1, 1, 1, 1, '2020-03-05 03:59:27');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (72, 16, 'Fees Allocation', 'fees_allocation', 1, 1, 1, 1, '2020-03-01 14:47:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (73, 16, 'Collect Fees', 'collect_fees', 0, 1, 0, 0, '2020-03-15 05:23:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (74, 16, 'Fees Reminder', 'fees_reminder', 1, 1, 1, 1, '2020-03-15 05:29:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (75, 16, 'Due Invoice', 'due_invoice', 1, 0, 0, 0, '2020-03-15 05:33:36');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (76, 16, 'Invoice', 'invoice', 1, 0, 0, 1, '2020-03-15 05:38:06');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (77, 9, 'Mark Distribution', 'mark_distribution', 1, 1, 1, 1, '2020-03-19 14:02:54');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (78, 9, 'Report Card', 'report_card', 1, 0, 0, 0, '2020-03-20 13:20:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (79, 9, 'Tabulation Sheet', 'tabulation_sheet', 1, 0, 0, 0, '2020-03-21 08:12:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (80, 15, 'Sendsmsmail Reports', 'sendsmsmail_reports', 1, 0, 0, 0, '2020-03-21 18:02:02');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (81, 18, 'Global Settings', 'global_settings', 1, 0, 1, 0, '2020-03-22 06:05:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (82, 18, 'Payment Settings', 'payment_settings', 1, 1, 0, 0, '2020-03-22 06:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (83, 18, 'Sms Settings', 'sms_settings', 1, 1, 1, 1, '2020-03-22 06:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (84, 18, 'Email Settings', 'email_settings', 1, 1, 1, 1, '2020-03-22 06:10:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (85, 18, 'Translations', 'translations', 1, 1, 1, 1, '2020-03-22 06:18:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (86, 18, 'Backup', 'backup', 1, 1, 1, 1, '2020-03-22 08:09:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (87, 18, 'Backup Restore', 'backup_restore', 0, 1, 0, 0, '2020-03-22 08:09:34');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (88, 7, 'Homework Evaluate', 'homework_evaluate', 1, 1, 0, 0, '2020-03-28 05:20:29');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (89, 7, 'Evaluation Report', 'evaluation_report', 1, 0, 0, 0, '2020-03-28 10:56:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (90, 18, 'School Settings', 'school_settings', 1, 0, 1, 0, '2020-03-30 18:36:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (91, 1, 'Monthly Income Vs Expense Pie Chart', 'monthly_income_vs_expense_chart', 1, 0, 0, 0, '2020-03-31 07:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (92, 1, 'Annual Student Fees Summary Chart', 'annual_student_fees_summary_chart', 1, 0, 0, 0, '2020-03-31 07:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (93, 1, 'Employee Count Widget', 'employee_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (94, 1, 'Student Count Widget', 'student_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (95, 1, 'Parent Count Widget', 'parent_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (96, 1, 'Teacher Count Widget', 'teacher_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (97, 1, 'Student Quantity Pie Chart', 'student_quantity_pie_chart', 1, 0, 0, 0, '2020-03-31 08:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (98, 1, 'Weekend Attendance Inspection Chart', 'weekend_attendance_inspection_chart', 1, 0, 0, 0, '2020-03-31 08:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (99, 1, 'Admission Count Widget', 'admission_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (100, 1, 'Voucher Count Widget', 'voucher_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (101, 1, 'Transport Count Widget', 'transport_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (102, 1, 'Hostel Count Widget', 'hostel_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (103, 18, 'Accounting Links', 'accounting_links', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (104, 16, 'Fees Reports', 'fees_reports', 1, 0, 0, 0, '2020-04-01 16:52:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (105, 18, 'Cron Job', 'cron_job', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (106, 18, 'Custom Field', 'custom_field', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (107, 5, 'Leave Reports', 'leave_reports', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (108, 18, 'Live Class Config', 'live_class_config', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (109, 19, 'Live Class', 'live_class', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (110, 20, 'Certificate Templete', 'certificate_templete', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (111, 20, 'Generate Student Certificate', 'generate_student_certificate', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (112, 20, 'Generate Employee Certificate', 'generate_employee_certificate', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (113, 21, 'ID Card Templete', 'id_card_templete', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (114, 21, 'Generate Student ID Card', 'generate_student_idcard', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (115, 21, 'Generate Employee ID Card', 'generate_employee_idcard', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (116, 21, 'Admit Card Templete', 'admit_card_templete', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (117, 21, 'Generate Admit card', 'generate_admit_card', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (118, 22, 'Frontend Setting', 'frontend_setting', 1, 1, 0, 0, '2019-09-11 04:24:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (119, 22, 'Frontend Menu', 'frontend_menu', 1, 1, 1, 1, '2019-09-11 05:03:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (120, 22, 'Frontend Section', 'frontend_section', 1, 1, 0, 0, '2019-09-11 05:26:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (121, 22, 'Manage Page', 'manage_page', 1, 1, 1, 1, '2019-09-11 06:54:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (122, 22, 'Frontend Slider', 'frontend_slider', 1, 1, 1, 1, '2019-09-11 07:12:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (123, 22, 'Frontend Features', 'frontend_features', 1, 1, 1, 1, '2019-09-11 07:47:51');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (124, 22, 'Frontend Testimonial', 'frontend_testimonial', 1, 1, 1, 1, '2019-09-11 07:54:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (125, 22, 'Frontend Services', 'frontend_services', 1, 1, 1, 1, '2019-09-11 08:01:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (126, 22, 'Frontend Faq', 'frontend_faq', 1, 1, 1, 1, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (127, 2, 'Online Admission', 'online_admission', 1, 1, 0, 1, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (128, 18, 'System Update', 'system_update', 0, 1, 0, 0, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (129, 19, 'Live Class Reports', 'live_class_reports', 1, 0, 0, 0, '2020-03-31 09:46:30');


#
# TABLE STRUCTURE FOR: permission_modules
#

DROP TABLE IF EXISTS `permission_modules`;

CREATE TABLE `permission_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) NOT NULL,
  `system` tinyint(1) NOT NULL,
  `sorted` tinyint(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (1, 'Dashboard', 'dashboard', 1, 1, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (2, 'Student', 'student', 1, 3, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (3, 'Parents', 'parents', 1, 4, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (4, 'Employee', 'employee', 1, 5, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (5, 'Human Resource', 'human_resource', 1, 8, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (6, 'Academic', 'academic', 1, 9, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (7, 'Homework', 'homework', 1, 12, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (8, 'Attachments Book', 'attachments_book', 1, 11, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (9, 'Exam Master', 'exam_master', 1, 13, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (10, 'Hostel', 'hostel', 1, 14, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (11, 'Transport', 'transport', 1, 15, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (12, 'Attendance', 'attendance', 1, 16, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (13, 'Library', 'library', 1, 17, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (14, 'Events', 'events', 1, 18, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (15, 'Bulk Sms And Email', 'bulk_sms_and_email', 1, 19, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (16, 'Student Accounting', 'student_accounting', 1, 20, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (17, 'Office Accounting', 'office_accounting', 1, 21, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (18, 'Settings', 'settings', 1, 22, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (19, 'Live Class', 'live_class', 1, 10, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (20, 'Certificate', 'certificate', 1, 7, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (21, 'Card Management', 'card_management', 1, 6, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (22, 'Website', 'website', 1, 2, '2019-05-26 23:23:00');


#
# TABLE STRUCTURE FOR: reset_password
#

DROP TABLE IF EXISTS `reset_password`;

CREATE TABLE `reset_password` (
  `key` longtext NOT NULL,
  `username` varchar(100) NOT NULL,
  `login_credential_id` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `reset_password` (`key`, `username`, `login_credential_id`, `created_at`) VALUES ('22521db32fdeec373c138ff50125cf2927c78ea17972c73bfcd57b2a0aebb27e6e4e7ee63e441929dc4f9ed7a6e7ad65e487e3aa6c1e2fa764372ff3231359e4', 'alfaky', '2', '2020-07-15 16:11:15');


#
# TABLE STRUCTURE FOR: rm_sessions
#

DROP TABLE IF EXISTS `rm_sessions`;

CREATE TABLE `rm_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('001eb521fad5dd25eaec01a0175a30466224cff2', '62.100.211.135', 1608918463, '__ci_last_regenerate|i:1608918462;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/accounting/all_transactions\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('002717b33769e7594af5c0a9ae69903db1eed678', '197.210.55.72', 1610622230, '__ci_last_regenerate|i:1610622230;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('00591ae61a96a42eaea4ec291dbb2c95d698a1d8', '105.112.113.111', 1610912824, '__ci_last_regenerate|i:1610912824;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('009239befdf6758c1fa487f0484bce3c48d56018', '31.13.103.16', 1603367962, '__ci_last_regenerate|i:1603367962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('00cf1aca1a7e3329ea5fffc448703764463d7fbf', '197.210.71.57', 1610754637, '__ci_last_regenerate|i:1610754637;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('015c7884ea1fa354dfebb3fdf3e8f4c11ccd1dcf', '72.52.238.104', 1611663602, '__ci_last_regenerate|i:1611663602;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01dd5e35f3e6d34c263fb85ffbc3d42b9309a17e', '62.100.211.168', 1609065948, '__ci_last_regenerate|i:1609065946;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01e4228b10d3e9ebf25a83f5d79c347742e65ee1', '72.52.238.104', 1611659582, '__ci_last_regenerate|i:1611659582;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01ece9985da88b7f12d6d90068d11d79cec6a3c7', '197.210.227.133', 1610546757, '__ci_last_regenerate|i:1610546757;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:25:\"Message Sent Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('02ef8087429080f34b06b85ae41fdc3504f6cc36', '197.210.71.33', 1603924003, '__ci_last_regenerate|i:1603923839;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0364c823be48a459ab4b2d30b710a6602b964049', '197.210.227.133', 1610545458, '__ci_last_regenerate|i:1610545458;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('03e9668274275e1b02fe067568326a4c29c1eba8', '197.210.52.63', 1610545200, '__ci_last_regenerate|i:1610545200;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('03f21bb5bced7bd951da51e2283c12313c80dcaa', '197.210.71.226', 1611570703, '__ci_last_regenerate|i:1611570703;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04095bda81aae86f77d3ce98eee5483268fbde6c', '62.100.211.135', 1608918464, '__ci_last_regenerate|i:1608918463;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/accounting/all_transactions\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('041f18b83c99a6cdef3cc1b172a412f6353359f7', '197.210.53.111', 1603497195, '__ci_last_regenerate|i:1603497194;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04561a69f2c327329b0143c08bfd3e6ca5798a9d', '41.73.1.67', 1610670548, '__ci_last_regenerate|i:1610670413;name|s:12:\"Zainab Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"33\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"7\";loggedin_type|s:7:\"student\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('045bf2dbee3bbf916ba8c5795f502987192ea648', '41.73.1.71', 1611069822, '__ci_last_regenerate|i:1611069822;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0468732a5f62ff4ded00ffe67b4cae54812a6e92', '41.73.1.65', 1604670165, '__ci_last_regenerate|i:1604670165;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0479447ac5689f34396eb72140b04904704cd7b7', '72.52.238.104', 1611664141, '__ci_last_regenerate|i:1611664141;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0480b7649cd349531baedc551f3b632305c08958', '41.73.1.67', 1605794648, '__ci_last_regenerate|i:1605794648;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0493cf002e322fc8fcbb26ba889ee35bf8f90921', '72.52.238.104', 1611659761, '__ci_last_regenerate|i:1611659761;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04c38bdb4b28d91123be719505c2c4003c45392a', '41.73.1.67', 1610676469, '__ci_last_regenerate|i:1610676294;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04c64f3d23094e9358dffc22959a10c0c3bb63db', '41.73.1.65', 1604684739, '__ci_last_regenerate|i:1604684604;redirect_url|s:56:\"https://admin.acce-abuja.com.ng/portal/role/permission/9\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04efa680b48c60c85e84a02f304930cbf6dd8fb2', '41.73.1.73', 1610711549, '__ci_last_regenerate|i:1610711549;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:9:\"Mr Bashir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"28\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:0:\"\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0570dbc4741c744e0d06d0e17ab5cf0d572a218f', '31.13.103.117', 1603367962, '__ci_last_regenerate|i:1603367962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0598ebe3fd7f1b1fefbee14f1a2ae54fa101141a', '72.52.238.104', 1611664202, '__ci_last_regenerate|i:1611664202;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('05b9b8d21d257843a0aaee53d89448539185d4ae', '105.112.113.111', 1610908963, '__ci_last_regenerate|i:1610908963;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('05be0204282c7ea55838e0c52368dc149d586f1e', '105.112.116.9', 1610721737, '__ci_last_regenerate|i:1610721737;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('063459a44b2dbeb2e687a2fe711b4f350288204a', '105.112.120.85', 1610556437, '__ci_last_regenerate|i:1610556437;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('06816209420922e09b9460ff86727a5c8c90379b', '72.52.238.104', 1611661082, '__ci_last_regenerate|i:1611661082;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0685da854724e09a43de044351b0bb9b3de20fbe', '197.210.226.134', 1610545633, '__ci_last_regenerate|i:1610545633;name|s:25:\"Odunola bashirat temitope\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"19\";loggedin_userid|s:2:\"15\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('06bbc06d5b59719dcebef6ab97a0388c0da685a1', '178.62.82.141', 1605484016, '__ci_last_regenerate|i:1605484015;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('07263f4fabdbbfd31d7a452dcde941c1efd95843', '105.112.112.105', 1610904340, '__ci_last_regenerate|i:1610904340;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"3\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('072a3b6733108a15e326c32b814dde553d21d00f', '41.73.1.66', 1610918446, '__ci_last_regenerate|i:1610918446;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('075e963a577a98e76198b7d745711b56f3c47c57', '41.73.1.66', 1604668145, '__ci_last_regenerate|i:1604668145;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('07aba29b7125c96cb1e18d44e1d8df0b85e99013', '197.210.65.86', 1606566918, '__ci_last_regenerate|i:1606566917;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('07e3fb2ecf25c18d23ac5cf320abee0c6c5ea85a', '72.52.238.104', 1611664261, '__ci_last_regenerate|i:1611664261;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('07f3cf48a31c38b113afca86873a47bb04c2bd46', '41.73.1.74', 1603537450, '__ci_last_regenerate|i:1603537450;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('081f7f0355571d86b69e9d4f63d307d341dc49c4', '197.210.76.54', 1603300730, '__ci_last_regenerate|i:1603300730;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('08437e6589023e86c232c57347c2935abb1cb079', '197.210.76.110', 1611146025, '__ci_last_regenerate|i:1611146025;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('085eb21a225abb2e22e33f611cd3d91c3d8a4d29', '72.52.238.104', 1611659942, '__ci_last_regenerate|i:1611659942;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('08a5ec24c64f747ae9c4cc6aabacc55dd028fc02', '197.210.28.207', 1603335873, '__ci_last_regenerate|i:1603335872;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('08b48e3f8dbff0f8179e8e2f35b09d402bb73467', '41.73.1.73', 1608579895, '__ci_last_regenerate|i:1608579895;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('09749d36cdb5f907bcddb420ed95cb3adb6a468a', '197.211.53.132', 1603144093, '__ci_last_regenerate|i:1603144093;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('09837b6e3264512a8bb903a02f225482401c5ffb', '72.52.238.104', 1611664141, '__ci_last_regenerate|i:1611664141;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('098dfcf928a8e93ca2b8c11747a331f718aac4d0', '105.112.121.109', 1610530957, '__ci_last_regenerate|i:1610530957;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('09c2b65061e848e4d39698dfbed784748e9c82b0', '41.190.14.195', 1610540653, '__ci_last_regenerate|i:1610540653;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('09ea7f8b2139a73463597ac36ed39fbd1f1a8f45', '41.73.1.72', 1608419481, '__ci_last_regenerate|i:1608419481;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a79468c4edc991f1aba176ee659e624127f1e7e', '197.210.227.243', 1610546148, '__ci_last_regenerate|i:1610546148;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a9c5d0d9b9ad47b3e9430842bf2fe964a046f5a', '72.52.238.104', 1611663902, '__ci_last_regenerate|i:1611663902;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a9ce14a92b7fc8444227a280da4029dc81f4aa9', '72.52.238.104', 1611658982, '__ci_last_regenerate|i:1611658982;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b06ea193ddb9c101ee723eef4687614cb837634', '105.112.121.57', 1604468162, '__ci_last_regenerate|i:1604468161;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b2426c04c999030e36c45e51f7a1abf2bc443f5', '72.52.238.104', 1611663962, '__ci_last_regenerate|i:1611663962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b4283de79c5051011fd2377a645d6ff1917e3f6', '41.73.1.66', 1604663481, '__ci_last_regenerate|i:1604663481;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b44d6251f1e8a3dbaa1f09a8556df84a3d05da4', '197.210.227.243', 1610548336, '__ci_last_regenerate|i:1610548336;name|s:25:\"Odunola bashirat temitope\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"19\";loggedin_userid|s:2:\"15\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b766d7d864f4b5a5730bc25630c9943cff00f5d', '54.36.148.170', 1610784716, '__ci_last_regenerate|i:1610784716;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ba9f5b00421a935e396ef7d4a4ef784742048a3', '41.190.30.14', 1605177843, '__ci_last_regenerate|i:1605177843;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0be48d9067e7c0699dc6b61ee541725afff28f75', '72.52.238.104', 1611659942, '__ci_last_regenerate|i:1611659942;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0c1d05890be8b65c28da1b0f0e639cfceeb1becd', '197.210.70.162', 1603345597, '__ci_last_regenerate|i:1603345597;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0cdda35cdd57f89b535d3d7ac002702583fb7b57', '41.73.1.69', 1610716483, '__ci_last_regenerate|i:1610716483;redirect_url|s:50:\"http://admin.acce-abuja.com.ng/portal/student/view\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0cf196762d929038029fe74a11feaf2cadb181c1', '54.36.148.217', 1607161901, '__ci_last_regenerate|i:1607161900;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d3de3d433c1fb68ba006b42d878bb92b42eaa1e', '72.52.238.104', 1611660241, '__ci_last_regenerate|i:1611660241;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d4c774650a8520cc1d4d50d9a58e37b8929ca66', '72.52.238.104', 1611663242, '__ci_last_regenerate|i:1611663242;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d506c6feae66ff3b8ddc28b1524f2998d47d53d', '197.210.227.133', 1610546383, '__ci_last_regenerate|i:1610546383;name|s:25:\"Odunola bashirat temitope\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"19\";loggedin_userid|s:2:\"15\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d5617a4b906932b9c2279ce06bb6a3a443cfce1', '105.112.112.94', 1610493555, '__ci_last_regenerate|i:1610493436;redirect_url|s:54:\"https://admin.acce-abuja.com.ng/portal/library/request\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0dd359a683960c753d54f9c90ff243861507d5fd', '197.210.71.85', 1608497204, '__ci_last_regenerate|i:1608497007;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0debede34c398f5f6c907cf9a6248ea9d3c2a68e', '197.211.53.132', 1603144708, '__ci_last_regenerate|i:1603144708;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0e17a35b00e70ca02c40f9dfaed658449a819ff6', '197.210.227.243', 1610551665, '__ci_last_regenerate|i:1610551665;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0e88864f1028d298f35d138708462cc452a80b9a', '72.52.238.104', 1611662522, '__ci_last_regenerate|i:1611662522;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0e8d31776877552ac3311711c858cf6eeefbcbd3', '41.73.1.66', 1604667554, '__ci_last_regenerate|i:1604667554;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0eca72bbd2da11b16735ddc0d5e9eb190aee0cd3', '41.73.1.66', 1604667200, '__ci_last_regenerate|i:1604667200;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ee4a72fd331df8c105119fab2299444ab555641', '197.210.227.133', 1610547808, '__ci_last_regenerate|i:1610547808;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ef812d666175ff0724227891c7a6ee1b7b89e13', '197.210.70.156', 1610784815, '__ci_last_regenerate|i:1610784815;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f021c782ce3e20bb8bbed08444696d0428b52e6', '197.210.70.194', 1610627747, '__ci_last_regenerate|i:1610627741;redirect_url|s:49:\"https://admin.acce-abuja.com.ng/portal/live_class\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f33b7cf055b91d3ad3c945b1275268662eb6228', '72.52.238.104', 1611663122, '__ci_last_regenerate|i:1611663122;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f67b25465934c52f769a367af0e46f825477d62', '72.52.238.104', 1611659821, '__ci_last_regenerate|i:1611659821;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f94123cf19ee4586bd2048cd8fc99d1a26c6e1f', '197.210.65.201', 1605568993, '__ci_last_regenerate|i:1605568992;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f9653face9131a3d2e97ad055ca3a345ec4ba03', '197.210.226.134', 1610545644, '__ci_last_regenerate|i:1610545644;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f9f19013068483d1e167f10045161333bb7f5db', '72.52.238.104', 1611661142, '__ci_last_regenerate|i:1611661142;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0fabcbbfe446e9f5d37d219cd8335d723429b83d', '41.73.1.66', 1604669819, '__ci_last_regenerate|i:1604669819;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0fcb87cf83993ed2e16e8c106c5a33de200ab94e', '72.52.238.104', 1611661382, '__ci_last_regenerate|i:1611661382;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0fvsq90cd5ji9cnliidigmg38md0dh28', '41.190.14.129', 1594894494, '__ci_last_regenerate|i:1594894494;redirect_url|s:57:\"https://www.admin.acce-abuja.com.ng/portal/classes/edit/3\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0l58rf5jr0vu5gjobi9nss4s58ecvbck', '105.112.121.55', 1602500678, '__ci_last_regenerate|i:1602498187;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0mm07ekskmbjp0s7lv79nk9vt99u44nt', '41.73.1.75', 1601982512, '__ci_last_regenerate|i:1601982333;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0n975k6bsf3ssfiqhj1n19vp07gb9jrr', '41.73.1.76', 1596036526, '__ci_last_regenerate|i:1596036504;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0o95a6gmkov8grqo124i7tg1prieuk5j', '41.190.12.66', 1595375959, '__ci_last_regenerate|i:1595375690;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0okhca862behuj4ac4nel9ur853ifdnu', '41.73.1.68', 1602513749, '__ci_last_regenerate|i:1602512731;redirect_url|s:58:\"https://www.admin.acce-abuja.com.ng/portal/school_settings\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0rtdson5qj2f83ajpq2g7sgkj9jgbl92', '41.190.12.66', 1595376793, '__ci_last_regenerate|i:1595376517;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0s5m1libed683jk54g2djoses3uursec', '41.190.12.93', 1594824629, '__ci_last_regenerate|i:1594824498;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('108ae42b545c7069d34b20006bdaa01d72c84886', '197.210.77.127', 1611059542, '__ci_last_regenerate|i:1611059542;name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10bajr6dqadljk2bamlfj2hau4187s2p', '41.73.1.75', 1601977946, '__ci_last_regenerate|i:1601977718;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10e425befaf4ff39bb76751e48c8cef408ef1c98', '197.210.227.133', 1610545178, '__ci_last_regenerate|i:1610545178;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('111458072961192c0717be7f0b3f0bebf573da0c', '197.210.226.134', 1610546675, '__ci_last_regenerate|i:1610546675;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('11596b26514d1edf736b27ddc4e94054283761d0', '72.52.238.104', 1611658865, '__ci_last_regenerate|i:1611658864;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('118fc355a9667e53a80e6c45e3822db7ae7429c8', '41.73.1.75', 1605976409, '__ci_last_regenerate|i:1605976409;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('11c2705d270cc8af9dae9f7bc92de9cd0fd92d50', '197.210.227.168', 1610557922, '__ci_last_regenerate|i:1610557922;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('11c37f5a5f494f7d4b8cb7ba4ce9d8b85e1baade', '41.73.1.69', 1608725527, '__ci_last_regenerate|i:1608725527;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('11d23a3eaef92ca370c2e98f44781fec51c1b578', '62.100.211.135', 1608918200, '__ci_last_regenerate|i:1608918199;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/accounting/all_transactions\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('125b82361e01ce06c001dee6b3bc3d789d065478', '72.52.238.104', 1611662341, '__ci_last_regenerate|i:1611662341;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12a6d6f2baf5280636dce9a71aaec6ce02afb8b3', '105.112.113.61', 1610665407, '__ci_last_regenerate|i:1610665353;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12b5a41a8c32b9c56bb44e5bf527d224e58ae18f', '41.190.14.105', 1610535343, '__ci_last_regenerate|i:1610535343;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12e1673e1a81c8491c5e86c7342e32d8c5418ac3', '197.210.227.243', 1610548962, '__ci_last_regenerate|i:1610548961;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12ee4a6e2c197148d6f5d524766d6620b527f1a5', '72.52.238.104', 1611660481, '__ci_last_regenerate|i:1611660481;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12f2457c553f4c6d0ad329fb2d79784a1e9807dd', '54.36.148.139', 1609244465, '__ci_last_regenerate|i:1609244464;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('137a0c1d3c66e20742b8a2dec8ce808aa47462ef', '72.52.238.104', 1611660302, '__ci_last_regenerate|i:1611660302;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('13ae9e81d9fb43e3da4bfea02466a5374056119b', '129.56.66.121', 1611569288, '__ci_last_regenerate|i:1611569288;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('13c09d1a2dd7a8c23853692f4d9cdc16daae05aa', '41.73.1.74', 1603119636, '__ci_last_regenerate|i:1603119636;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('13ff7da6415fa4e77323b5dc8088e116ca6e4e46', '54.36.148.231', 1609758986, '__ci_last_regenerate|i:1609758985;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1425088f89464f6a7dab0e2718dfb1430ddfd043', '41.73.1.74', 1603452973, '__ci_last_regenerate|i:1603452973;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('14f4daed9d361af220082a69372fbb1cfb5f3469', '41.73.1.66', 1607504323, '__ci_last_regenerate|i:1607504321;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15394c18b12ea7329c07a55b836860e85ad8b372', '72.52.238.104', 1611662403, '__ci_last_regenerate|i:1611662403;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1559e90a9bd1e27052346b38c5165b2b404dbaf8', '31.13.103.20', 1603367960, '__ci_last_regenerate|i:1603367960;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15612d60f58b0368001c1c8b0b177fe986619bd8', '72.52.238.104', 1611660421, '__ci_last_regenerate|i:1611660421;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1599fcd31fcf3a17ab3552fd8cf9a9cb64fbef8d', '41.73.1.77', 1610733740, '__ci_last_regenerate|i:1610733596;redirect_url|s:50:\"https://admin.acce-abuja.com.ng/portal/attachments\";name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15a6504b3adeb4e3eebfe82475f7a526f52f0e5a', '197.210.55.86', 1610618878, '__ci_last_regenerate|i:1610618878;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15ad64b125784e1dce6e78e961feb6ee4099243e', '41.73.1.73', 1608574939, '__ci_last_regenerate|i:1608574939;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15fcba6386fa90aab36239d662593a0138754c16', '72.52.238.104', 1611663302, '__ci_last_regenerate|i:1611663302;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('16226af95b842d91eb58212e64a8efcaa6d649f6', '196.49.26.134', 1603968952, '__ci_last_regenerate|i:1603968853;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1669c7cfbf8914ae2cb29d14a2d4034efa6369df', '72.52.238.104', 1611661201, '__ci_last_regenerate|i:1611661201;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('168913efae000b97de507c0708de9c8f98756877', '107.178.238.51', 1608600452, '__ci_last_regenerate|i:1608600451;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('16a8da2b6590edf23df249e9dda5b450c5c19203', '72.52.238.104', 1611663182, '__ci_last_regenerate|i:1611663182;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('16bddd07688623063b054d805ba01f684a874d76', '66.249.64.40', 1609305983, '__ci_last_regenerate|i:1609305982;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('16c3acc64bdc3fbdc21583fe96c54ea9629d8f69', '197.149.127.197', 1608551360, '__ci_last_regenerate|i:1608551360;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('16c97feb0434003a3da45e885c884086d4be448e', '41.73.1.66', 1602589348, '__ci_last_regenerate|i:1602589348;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('16ecd476q54tgfrq87e16e172gh2d63e', '41.73.1.71', 1601372270, '__ci_last_regenerate|i:1601372161;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('16f5f97e848f88511dd36251b865672be9290ed0', '41.73.1.66', 1607536684, '__ci_last_regenerate|i:1607536571;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('17336a6500b27218059793b7de4c0711966f461d', '41.73.1.66', 1602588151, '__ci_last_regenerate|i:1602588151;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1797125e25ceaa4c27d7ee531491fd9efe8a618f', '197.210.226.134', 1610547466, '__ci_last_regenerate|i:1610547466;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('17e0cbb30a5856033340a27823414f5f4d6d2da7', '72.52.238.104', 1611662341, '__ci_last_regenerate|i:1611662341;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18326a48a05b207ab5741968369c0338d10b5802', '197.210.226.134', 1610546748, '__ci_last_regenerate|i:1610546748;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18e91b702411f53d684d532a36f27bc46a503659', '197.211.53.132', 1603144708, '__ci_last_regenerate|i:1603144708;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1977a582491b2344186dcb583f2de23595dc836b', '197.210.227.133', 1610545492, '__ci_last_regenerate|i:1610545492;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('19ce1db2143f5a2c843ba0f60e6667ed753157af', '41.190.14.195', 1610541739, '__ci_last_regenerate|i:1610541739;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1a2tfbi6ll6p7k78fmd6sp3lqu16c82l', '41.73.1.71', 1601386064, '__ci_last_regenerate|i:1601386018;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1a41f1fa6bf507d1689b3329c7c88dd3e1fd30d5', '41.73.1.66', 1604667174, '__ci_last_regenerate|i:1604667174;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ab926a63c6253cc80771329e727080f6c68d55d', '62.100.211.135', 1608918464, '__ci_last_regenerate|i:1608918464;redirect_url|s:59:\"http://admin.acce-abuja.com.ng/portal/payroll/salary_assign\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b2kdoj5reamva3q1ojrg2baei56q4jd', '41.73.1.71', 1601385063, '__ci_last_regenerate|i:1601384811;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b4ae2b6145a2b8cc20562ae43d9d8da3f83c929', '41.73.1.73', 1608574529, '__ci_last_regenerate|i:1608574529;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b4d931e01464dde9aee44e4b194d7ee3dfa5cc0', '197.210.53.228', 1610540672, '__ci_last_regenerate|i:1610540672;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b64561b869ae92162fb3c14be7dcf8531ba6789', '197.210.227.243', 1610546752, '__ci_last_regenerate|i:1610546752;name|s:21:\"Odachi Cosmas Ejiofor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b68640ab893d11dc90afe17f892d1c611b35177', '41.73.1.65', 1604680752, '__ci_last_regenerate|i:1604680720;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1bdea169ce14b62f0f5f434f63369e75c24ca50b', '197.210.55.86', 1610618206, '__ci_last_regenerate|i:1610617939;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1bfa75fb7b658e3f2fd8664b20b0d3dec7beb986', '107.178.237.28', 1606100792, '__ci_last_regenerate|i:1606100791;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1c669e6f0686e144d450a93f07cedefd30c25815', '197.210.70.215', 1610531390, '__ci_last_regenerate|i:1610531390;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1cc6ec51a7048337db79f7cee45ddf09e1982d1e', '105.112.116.167', 1610690567, '__ci_last_regenerate|i:1610690565;redirect_url|s:52:\"https://admin.acce-abuja.com.ng/portal/employee/view\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ced12d6439a309dcf1572fd6522c263a256ed26', '72.52.238.104', 1611658922, '__ci_last_regenerate|i:1611658922;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1d0cec75fb26e78d3e8f5276f2105a25fc949259', '197.210.227.243', 1610557826, '__ci_last_regenerate|i:1610557826;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1dd614c19c2c5f6c8f1bf0e8df8f63faf5c0df43', '72.52.238.104', 1611662882, '__ci_last_regenerate|i:1611662882;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1e26836753008192521cb4a6830783024b77e4d7', '72.52.238.104', 1611660841, '__ci_last_regenerate|i:1611660841;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1e6f86b9e7b276d512849f59917b240fd829f758', '197.149.127.196', 1603969137, '__ci_last_regenerate|i:1603969134;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1e75dcbf9972f7dbb551a2cec001d959e525395e', '197.210.227.28', 1610621411, '__ci_last_regenerate|i:1610621294;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1e9bc32c61c42b48b97a74f46a39d8c95d05e637', '31.13.103.7', 1603369624, '__ci_last_regenerate|i:1603369624;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1edcb51702e118895d6f4b3daf1049a4c8cd8840', '72.52.238.104', 1611662643, '__ci_last_regenerate|i:1611662643;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ee169b396fe1e691c20143795b63f0ef9f97c68', '197.210.77.35', 1610967199, '__ci_last_regenerate|i:1610967199;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1f08b27c1584b7e1302d73f0a28356482196939a', '105.112.116.199', 1610740121, '__ci_last_regenerate|i:1610740121;redirect_url|s:51:\"https://admin.acce-abuja.com.ng/portal/library/book\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1f0b1391e9d7fd6c241c4fdb753ff17406315cab', '197.149.127.196', 1611664446, '__ci_last_regenerate|i:1611664444;redirect_url|s:56:\"https://www.admin.acce-abuja.com.ng/portal/system_update\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1fa85a94b9e33f49bd149a0b2445c5f660324e63', '41.73.1.65', 1608718724, '__ci_last_regenerate|i:1608718723;redirect_url|s:63:\"http://admin.acce-abuja.com.ng/portal/accounting/expense_repots\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1fb298d136b57383d83b46da53ea09f3f0ba7060', '197.210.227.243', 1610546425, '__ci_last_regenerate|i:1610546425;name|s:23:\"Farida Yussuff Avosuahi\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"14\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1fdb744ca174805c1f9733b591303e42fdd2a892', '72.52.238.104', 1611661442, '__ci_last_regenerate|i:1611661442;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1fde16c884ddbcdbf0d84eb5bd3bedfa6c36a6d8', '41.73.1.66', 1602582281, '__ci_last_regenerate|i:1602582281;redirect_url|s:60:\"https://www.admin.acce-abuja.com.ng/portal/fees/invoice_list\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ff70550d87b1dba074b5daccccbbe8dd2e090ec', '41.73.1.65', 1604680869, '__ci_last_regenerate|i:1604680869;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1r0n0mu96pai2sscq4ekf3b8n0cf8ktq', '105.112.121.55', 1602498186, '__ci_last_regenerate|i:1602498186;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1u690se00snbektr447jehb6u4gil4s3', '41.73.1.71', 1601373304, '__ci_last_regenerate|i:1601373121;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('205d61jdssosms1pll9rj2emt17tq144', '41.73.1.68', 1594915449, '__ci_last_regenerate|i:1594915174;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('20be5084aa4dcd684a714f04a9925ad01f92271e', '197.210.226.134', 1610547875, '__ci_last_regenerate|i:1610547875;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('20da39bc45ab453219b54b2095d6b22bf293ff07', '197.210.71.173', 1610965970, '__ci_last_regenerate|i:1610965970;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"arabic\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2186bd19e1ea45e7196c52eb00951aa4b0a926c1', '197.210.52.113', 1603569966, '__ci_last_regenerate|i:1603569965;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2189bf843b785274b694cfe66bea2c7cc1993942', '72.52.238.104', 1611662762, '__ci_last_regenerate|i:1611662762;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('22223746d6024904c34d53bc6ff33d3b0d898f52', '197.210.227.243', 1610551977, '__ci_last_regenerate|i:1610551977;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:25:\"Message Sent Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2278a2663e6d0102c27fe51da33ef023ec9f8879', '41.73.1.67', 1610668773, '__ci_last_regenerate|i:1610668773;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('227a17af95852cbe44b46820f4655053f0f5beb4', '72.52.238.104', 1611663182, '__ci_last_regenerate|i:1611663182;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('22e6b8c24b85db47c13d08b65c4ae0edadf26299', '41.73.1.65', 1604674739, '__ci_last_regenerate|i:1604674739;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('230184d06454fc5c6c08fd2d8c76df3b049bd26f', '41.73.1.73', 1608576679, '__ci_last_regenerate|i:1608576679;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23034b959cec58de40e1f8f605960e6a23887947', '41.190.14.105', 1610532421, '__ci_last_regenerate|i:1610532421;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2317210c6d7b0f27b8471bddf36c0f81fa279450', '107.178.238.35', 1602652628, '__ci_last_regenerate|i:1602652628;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('233a12a98608afcf2c49e31aad6217c505b1a9a5', '41.73.1.74', 1603451311, '__ci_last_regenerate|i:1603451311;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23435101bc389284d943904216e0468ff53059e6', '197.210.227.243', 1610549147, '__ci_last_regenerate|i:1610549147;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2344b62060b1c410b3922f223b9d954ae5414a9c', '41.190.12.132', 1606207622, '__ci_last_regenerate|i:1606207622;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23878993edf3936d3d320135e2a45c48f351f33d', '197.210.71.74', 1610534632, '__ci_last_regenerate|i:1610534632;redirect_url|s:51:\"https://admin.acce-abuja.com.ng/portal/employee/add\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23f723c5fdaf8dd5e8dec98935875581cf11432b', '72.52.238.104', 1611659103, '__ci_last_regenerate|i:1611659102;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23ssbrs4usc86uk55ro8hpfsrq1r6l9i', '41.73.1.75', 1595860099, '__ci_last_regenerate|i:1595860098;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23vlq02fea65qp6r3dtd8agi83lhb119', '41.73.1.76', 1596032806, '__ci_last_regenerate|i:1596032804;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2416604c406800dd418fb84532e0390a9d705aa7', '62.100.211.168', 1609065994, '__ci_last_regenerate|i:1609065994;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('247d4fd123071f3e18f46d02d07fbaf88de97a95', '41.73.1.70', 1609445380, '__ci_last_regenerate|i:1609445377;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('24fae66960874083bad5022d7294a71030e93f12', '129.56.66.121', 1611568675, '__ci_last_regenerate|i:1611568675;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('24vbrd4ilpt2c8vseegd8n4dgr5pobj2', '41.73.1.75', 1595427260, '__ci_last_regenerate|i:1595427248;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25676c7093af0e2e81bacda9cd7edf2af34999ac', '41.73.1.73', 1610716685, '__ci_last_regenerate|i:1610716685;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25e1e9629d6910344704f0ea5801614c15bed052', '102.89.1.51', 1603304451, '__ci_last_regenerate|i:1603304451;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25lbblbkkieosu9k0g6u4kdc091otg2i', '41.73.1.72', 1602166119, '__ci_last_regenerate|i:1602166082;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('260d0dc3a4aecdc8a5a8e03f1b046683bf5886ba', '41.73.1.73', 1608573610, '__ci_last_regenerate|i:1608573610;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('260f992f2017f85ff405b31adc0166db58e48fef', '41.73.1.69', 1610714485, '__ci_last_regenerate|i:1610714485;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('262035760d76a9c8afd04cc3762f7f963621514f', '105.112.116.199', 1610723024, '__ci_last_regenerate|i:1610722978;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('264833066dc57c3fddbe85c25b563e621a572cbb', '72.52.238.104', 1611662163, '__ci_last_regenerate|i:1611662163;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2652d1d0ff7543962750b86a45dfdffbe44904af', '41.73.1.66', 1602585645, '__ci_last_regenerate|i:1602585645;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('269133eee62d035d4279392a47bcddc880b30c5f', '41.73.1.66', 1604669176, '__ci_last_regenerate|i:1604669176;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2692909b77b974bdfd79d62ced7cb138b38ea2ba', '197.210.226.134', 1610548395, '__ci_last_regenerate|i:1610548395;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('27044af45cb095fa0fe126e7c9e5da63a2f7325c', '72.52.238.104', 1611663242, '__ci_last_regenerate|i:1611663242;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('27585e9f21a90f549ff2098e7f5e54ea0da09580', '41.73.1.69', 1610713517, '__ci_last_regenerate|i:1610713517;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2773561fa3d63bd17cd3f95004f2a42ccc588fb6', '197.210.71.94', 1610533294, '__ci_last_regenerate|i:1610533294;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('27ee402918bc87692febd452c908f788bb890c45', '72.52.238.104', 1611661622, '__ci_last_regenerate|i:1611661622;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('280dbe26ebfe632475ad33bcc2153eb425e6cb46', '197.210.52.205', 1610537985, '__ci_last_regenerate|i:1610537985;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2821769a65b6fc5894526b5bcf0f679e08143665', '197.210.227.22', 1610567564, '__ci_last_regenerate|i:1610567564;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2842ec6cefd154cd9db1fc1652fcfc5933d9c7fd', '105.112.117.212', 1603307340, '__ci_last_regenerate|i:1603307340;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('286d161c2d046051c0c92e73cafae221ed8106e0', '35.203.252.113', 1606899977, '__ci_last_regenerate|i:1606899976;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2899371b5f04dd02d8113b65d43dd5986f0d1023', '197.210.71.223', 1603527646, '__ci_last_regenerate|i:1603527646;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('28bcb258755ae9578aab86ad816b7d43917c21f2', '197.210.227.243', 1610546047, '__ci_last_regenerate|i:1610546047;name|s:25:\"Odunola bashirat temitope\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"19\";loggedin_userid|s:2:\"15\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('29239f8dea7cc6b4514f09bcb3fef9d87957cbba', '72.52.238.104', 1611662882, '__ci_last_regenerate|i:1611662882;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('292f3e2916760fd31736f14232fe7966861c71f3', '105.112.112.119', 1611307113, '__ci_last_regenerate|i:1611306966;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2941cfd64636c24b4b9b8274c389912dd0ca2c49', '72.52.238.104', 1611663482, '__ci_last_regenerate|i:1611663481;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('298737229ae203f4ff9520e0e0be3ac32f36f6cc', '129.56.66.121', 1611567887, '__ci_last_regenerate|i:1611567886;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('29lv96g2skd1g5k6bngvo0srfad5sud3', '41.73.1.75', 1601893808, '__ci_last_regenerate|i:1601893678;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2a23c7d7f40b9889bed4a90bc462e213aafbbf45', '41.73.1.74', 1603118020, '__ci_last_regenerate|i:1603117917;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ade1d8d85da4c48b644f089ee75e505bfe4c44a', '197.210.227.22', 1610567146, '__ci_last_regenerate|i:1610567146;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b21a827b2eb04b8daf2e7155c8471df75c7d5e0', '197.210.226.134', 1610553319, '__ci_last_regenerate|i:1610553319;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b40314da35727f683f1adc6ec8087ef1fab077a', '72.52.238.104', 1611659821, '__ci_last_regenerate|i:1611659821;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b4dd996089fde3ed449b5a6ec5c0d43b061efd1', '72.52.238.104', 1611663061, '__ci_last_regenerate|i:1611663061;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b62771c519b3012faa92d2204d58cb1a579ae6f', '62.100.211.135', 1608918464, '__ci_last_regenerate|i:1608918463;redirect_url|s:64:\"http://admin.acce-abuja.com.ng/portal/accounting/voucher_expense\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2bbb67e0c52bb8d9e016bd87c23014faa083759b', '105.112.112.105', 1610908586, '__ci_last_regenerate|i:1610908586;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2bd0799f863d48af314a5ec81d29c41d3b5c78ae', '197.210.8.36', 1603381910, '__ci_last_regenerate|i:1603381910;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2bf8f48dc08a66d8273b61ce1f15552a68a75e08', '41.73.1.73', 1608578494, '__ci_last_regenerate|i:1608578494;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2c4813f8f1e2a2b7acd59f5d8c1a42e0418ca497', '197.211.53.132', 1603391725, '__ci_last_regenerate|i:1603391725;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2c96f79cdc3757e75015cf4068289e8d052be2e3', '41.73.1.66', 1604669102, '__ci_last_regenerate|i:1604669100;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ce52338b74d4fb486352a5d42ae4671c3473a5a', '41.73.1.67', 1610675949, '__ci_last_regenerate|i:1610675949;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d0d60626f6e3010332ea0330e42f36ae778aa3b', '72.52.238.104', 1611661261, '__ci_last_regenerate|i:1611661261;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d2f1b1de3c8f3b2a9f81a335925ef96f5662a0c', '72.52.238.104', 1611659402, '__ci_last_regenerate|i:1611659402;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d3cb0ea2e1b0ecebc6899cf9cb5fb3c50ea58c2', '197.210.226.134', 1610546427, '__ci_last_regenerate|i:1610546427;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d47a1d8bc1dfd071f4909caec78711581e4bb3c', '197.210.227.243', 1610545628, '__ci_last_regenerate|i:1610545628;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d4c44fa18bee164e9b285663a7c26eff7b04ab6', '197.210.55.115', 1606050859, '__ci_last_regenerate|i:1606050807;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d4c79c857373b2acb6a1a664bd385438ddf7937', '129.56.66.121', 1611569938, '__ci_last_regenerate|i:1611569938;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d5afd8d30a69221755a628aca5340d9f185529d', '197.210.227.133', 1610546983, '__ci_last_regenerate|i:1610546983;name|s:24:\"Oladebo abduljelil taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d6673e5ec9f4297d3d2bd8ba55868557016956a', '54.36.148.132', 1609261879, '__ci_last_regenerate|i:1609261879;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2dbcae52ab563a53c86bee7e092bf3b4d3f8c2ad', '197.210.76.217', 1605363645, '__ci_last_regenerate|i:1605363645;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2de5563bdcad53b7a4d4ad1ad5e61b2a0cad58a3', '41.73.1.68', 1606839569, '__ci_last_regenerate|i:1606839310;redirect_url|s:56:\"http://admin.acce-abuja.com.ng/portal/settings/universal\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2dece8d6162a23150ece7eac506a1ae7fb7b9405', '197.210.227.133', 1610545661, '__ci_last_regenerate|i:1610545661;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2df1dcfab62f262f49d820b21331b67d8e0b7f37', '72.52.238.104', 1611661982, '__ci_last_regenerate|i:1611661982;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2do0km16derf57qp3sqrje2gr8vcek48', '197.210.53.36', 1595514892, '__ci_last_regenerate|i:1595514826;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2e2b3f394df1ec67774f569a3cc9f29bdbcba91a', '72.52.238.104', 1611664202, '__ci_last_regenerate|i:1611664202;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2e661b95a1b602397aa098bdcc2fe0fde41b19a3', '197.210.77.181', 1610966642, '__ci_last_regenerate|i:1610966642;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2e832c95de447461db1873c5664cf4219cf2757a', '197.210.71.230', 1603481127, '__ci_last_regenerate|i:1603481076;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2eae7d8f4cbc886b52277997ab1d406f4e662d2c', '72.52.238.104', 1611661806, '__ci_last_regenerate|i:1611661806;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ef98bd7eebec11ab7592e58bb5c0d4d8b399e07', '72.52.238.104', 1611663061, '__ci_last_regenerate|i:1611663061;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2efa6c8a179f26ceb8e70ea397f9809b23f340cb', '72.52.238.104', 1611661382, '__ci_last_regenerate|i:1611661382;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2f5f6c15767fbb70441dcf928789b81e1bd9bf55', '107.178.238.35', 1602652625, '__ci_last_regenerate|i:1602652624;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2f7fe1ae30974cdffde13b819b000d1fdba6dc98', '72.52.238.104', 1611661022, '__ci_last_regenerate|i:1611661022;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ff8d21643800866b51f472a8cf5d7a82f5fd2c7', '41.73.1.69', 1610715380, '__ci_last_regenerate|i:1610715380;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ln6348fal7ahhos1fs9a3v50iq275j7', '41.73.1.66', 1602160938, '__ci_last_regenerate|i:1602160456;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2mo9gnocufjtro38v6t7pa5c8itsb6e9', '41.73.1.66', 1602159924, '__ci_last_regenerate|i:1602159834;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2njtkpr1a2l05gnh8m69hbn6lu2i0r7j', '41.73.1.75', 1601126606, '__ci_last_regenerate|i:1601126485;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2sij9mafsc1qqbk8ieo2f4oftfi70e7o', '41.190.12.220', 1594817530, '__ci_last_regenerate|i:1594817317;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2vqhrm515eik6gatct665eq001rev86n', '41.73.1.75', 1601978891, '__ci_last_regenerate|i:1601978119;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('307b26d4e7b0cd4d5fbd950098d64579535543e9', '197.210.227.243', 1610547568, '__ci_last_regenerate|i:1610547568;name|s:21:\"Odachi Cosmas Ejiofor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30aaedb558cbbb9231fae7b73f333f8ca0e4a0ab', '197.210.226.134', 1610546032, '__ci_last_regenerate|i:1610546032;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30b8pgnn9r9j5ep7l0udpvhdp35rkiff', '105.112.117.208', 1601298523, '__ci_last_regenerate|i:1601298510;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30dd2596a1b1981cf6574a4e07b4bcf94f16e350', '72.52.238.104', 1611659461, '__ci_last_regenerate|i:1611659461;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30ed48a57e134ca45898c39e2e1d479871168153', '41.73.1.65', 1604672313, '__ci_last_regenerate|i:1604672313;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('310b833cf5ddde72276adef7197ea2c662a97327', '41.73.1.77', 1610718671, '__ci_last_regenerate|i:1610718646;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('318721b6024b6dcc16400a84d4f98625c1ae5da2', '154.120.71.77', 1603886056, '__ci_last_regenerate|i:1603885926;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('31c6f56bf9a3c734984866eeb05b66683fe93f83', '41.73.1.67', 1610670819, '__ci_last_regenerate|i:1610670819;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('31d7e05548172c31217046b2d6a8e0cf91bfaad5', '197.210.227.133', 1610543548, '__ci_last_regenerate|i:1610543548;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('31fa2b050541a33e31fa6cbeab0e27af1d0305ad', '105.112.116.199', 1610722978, '__ci_last_regenerate|i:1610722978;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32c52itqlbjvnpusfcdcugb6tins819g', '193.51.224.134', 1601369898, '__ci_last_regenerate|i:1601369896;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32c89e1ae95c222d195db440646fd0cc0c9a7960', '197.210.70.226', 1609696265, '__ci_last_regenerate|i:1609696264;redirect_url|s:64:\"http://admin.acce-abuja.com.ng/portal/accounting/voucher_expense\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32f260276b45de7ecd8fd5a3248290ae29cb1fea', '72.52.238.104', 1611663242, '__ci_last_regenerate|i:1611663242;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32fb471bd515bd70c09b337b4e4264e5774dfdb6', '35.203.252.146', 1607313499, '__ci_last_regenerate|i:1607313499;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32nmr7u3pt20tp7o10752rpfc4pk0j6l', '41.190.12.93', 1594825865, '__ci_last_regenerate|i:1594825565;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('334af1bc54d05403615821dc1d4c41aa968b91c8', '197.210.227.133', 1610546741, '__ci_last_regenerate|i:1610546741;name|s:25:\"Odunola bashirat temitope\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"19\";loggedin_userid|s:2:\"15\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3367978798cabaf028c6a0e0cc11ef6426ebd24f', '41.190.12.179', 1604655893, '__ci_last_regenerate|i:1604655893;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('337c74b0f26443a37e50706162d1ff2e85205f1c', '107.178.232.177', 1609951801, '__ci_last_regenerate|i:1609951801;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('33e0ddeffcee14e2a2030220e16e8c684755f50f', '197.210.226.134', 1610548435, '__ci_last_regenerate|i:1610548435;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('33e662de650eea44b3aeca456b939065f669e429', '72.52.238.104', 1611660001, '__ci_last_regenerate|i:1611660001;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3520a3dd365cb5c6f60429fb3b5572aa0f5da596', '41.73.1.66', 1604669766, '__ci_last_regenerate|i:1604669766;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('352a7545d4b2c2df03e89c3571620b15c5a3ab2d', '72.52.238.104', 1611662941, '__ci_last_regenerate|i:1611662941;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('355e7d1d9d23ee17834bd433df849361b44ea598', '41.73.1.73', 1610711295, '__ci_last_regenerate|i:1610711295;name|s:11:\"Yusuf Bello\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"27\";loggedin_userid|s:1:\"5\";loggedin_role_id|s:1:\"7\";loggedin_type|s:7:\"student\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('355f56650f8896c99c6a68217a24062e841358ba', '41.73.1.65', 1603970978, '__ci_last_regenerate|i:1603970727;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('35u2mrorjc15keqige882d4g755vkple', '41.73.1.75', 1601895878, '__ci_last_regenerate|i:1601895856;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3610ab58b485af5cd9297fe11d402b4381149c5f', '197.210.71.173', 1610964139, '__ci_last_regenerate|i:1610964139;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('362bf47a4a3d051065dc1c2f8a9e4592c6c777fe', '197.210.55.72', 1610621826, '__ci_last_regenerate|i:1610621826;name|s:23:\"sherifat aliya keshinro\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"16\";loggedin_userid|s:2:\"12\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('364c67c96f5647b31e6893c1de8255b3d32a48a7', '41.73.1.65', 1604681026, '__ci_last_regenerate|i:1604680869;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('364c725af499b2b9f95a3591fca5f7c1d0b94f97', '72.52.238.104', 1611660722, '__ci_last_regenerate|i:1611660722;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('364d5c9969a08d856198d7b6698b7b220ff9f4e8', '197.210.226.134', 1610556787, '__ci_last_regenerate|i:1610556787;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('365780c004767f07b2e200029ff7964e5d852f4a', '41.190.14.60', 1604652261, '__ci_last_regenerate|i:1604652261;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3676cda57bf7fb96bddeb485c1b5089689cef6e3', '31.13.103.20', 1603367961, '__ci_last_regenerate|i:1603367961;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('367d99519b77cc4b5b98b60ee3e050815aa80079', '129.56.66.121', 1611568987, '__ci_last_regenerate|i:1611568987;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36886b30aa9c48cd7f1ad0cd6ebd8760e56a59b8', '62.100.211.135', 1608918219, '__ci_last_regenerate|i:1608918219;redirect_url|s:62:\"http://admin.acce-abuja.com.ng/portal/fees/student_fees_report\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36d314cd2c94632cdc748f7485f505e947b4abb0', '107.178.232.162', 1604325031, '__ci_last_regenerate|i:1604325030;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36f257db75be383e646e379e5998fa596f17c8de', '41.73.1.65', 1603969441, '__ci_last_regenerate|i:1603969441;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36f47baa0cda2499d9f88e380111808c7c435761', '41.73.1.66', 1611658741, '__ci_last_regenerate|i:1611658741;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('374c5ca6c16622c2b759a668dac7f325fe9d9b32', '66.249.64.40', 1609249879, '__ci_last_regenerate|i:1609249879;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('377c1b1185407ce11d3bb934ec7757ffbc8bdc58', '72.52.238.104', 1611660121, '__ci_last_regenerate|i:1611660121;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37ac64fbf52c7b1d74da5e14a91ff083c9d70eda', '41.73.1.69', 1610718256, '__ci_last_regenerate|i:1610718256;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37cf798830f1c5e00a2b395a36135c1f66cbff33', '197.210.77.212', 1607528018, '__ci_last_regenerate|i:1607527973;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37ee5ea56095d546399a1504c4fd91d2cf07333a', '72.52.238.104', 1611662702, '__ci_last_regenerate|i:1611662702;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('380b2c318e8ebacf9a12c9d72166d4d88d7f08fc', '173.208.130.202', 1605103886, '__ci_last_regenerate|i:1605103886;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('380bf209a944c58b8f27ab932d4e12d9f430b4f3', '72.52.238.104', 1611661681, '__ci_last_regenerate|i:1611661681;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('385b951dc2abf6fc063dd8b1d3a78a12d859e649', '197.210.227.133', 1610546425, '__ci_last_regenerate|i:1610546425;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('38a8df289a8822ca503d765fb87cee497715e12d', '41.73.1.78', 1610457901, '__ci_last_regenerate|i:1610457901;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('38d75020b6908b6077cb0e75c083ed4350801290', '62.100.211.135', 1608918219, '__ci_last_regenerate|i:1608918219;redirect_url|s:55:\"http://admin.acce-abuja.com.ng/portal/fees/invoice_list\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('38e24f14aa87a564e5668df6221c02582cf29cd2', '72.52.238.104', 1611660362, '__ci_last_regenerate|i:1611660362;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3956631a62bfd5424bcd4987bc199a870afcb52c', '197.149.127.196', 1604670623, '__ci_last_regenerate|i:1604670620;redirect_url|s:47:\"https://www.admin.acce-abuja.com.ng/portal/role\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('398951cbd2d89af1ee74f6735676e6cab126dcda', '197.211.53.150', 1608303479, '__ci_last_regenerate|i:1608303479;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39cc34d56748d12f6b6a335500608aec5d8ac816', '41.190.12.179', 1604652709, '__ci_last_regenerate|i:1604652550;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39efcfa0c5a4a9a1d8d94e56c724fce1904f047e', '197.210.227.243', 1610548615, '__ci_last_regenerate|i:1610548615;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39o8jnc234kh23176oh9i117gej5oq9c', '41.190.14.104', 1600238731, '__ci_last_regenerate|i:1600238730;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3a27abc5c0496a732b41c1c5b56cc4366cf8ee5c', '197.210.70.96', 1605971282, '__ci_last_regenerate|i:1605971256;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3a2b693d16ebfb28a1e5491c6aa972513632c5bc', '72.52.238.104', 1611659162, '__ci_last_regenerate|i:1611659162;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3a3d5e5b9ed862a344279e47f54ce78edf7a1253', '72.52.238.104', 1611660362, '__ci_last_regenerate|i:1611660361;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3a8166a1eff84cf93cd5bf86d70d09ec9c058626', '72.52.238.104', 1611661382, '__ci_last_regenerate|i:1611661382;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3a94909955143f5637700bf8a628b15408a465b0', '197.210.52.147', 1609625770, '__ci_last_regenerate|i:1609625770;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ab69fce432bf7e18bfe2cc18923bde8bf8f9150', '129.56.109.20', 1611143855, '__ci_last_regenerate|i:1611143855;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b01a8cf32d05c8f00505d608a1146f562106556', '197.210.227.28', 1610624157, '__ci_last_regenerate|i:1610624157;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b01b9ffcbe55d84ca840ae8c21d1f3c0899cd3d', '66.249.72.36', 1608851066, '__ci_last_regenerate|i:1608851038;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b53a6589789f821567c4fb42582d2bfed91b9bd', '54.36.148.90', 1606050204, '__ci_last_regenerate|i:1606050203;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b91d31984f4c215ca5203c0c2404266a92f80c1', '41.73.1.65', 1604680787, '__ci_last_regenerate|i:1604680770;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3bca82bfd0e791b565c9db80c41acc340668e554', '197.210.77.127', 1611066985, '__ci_last_regenerate|i:1611066985;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3bfdc1653a520508b5104a3f1f3fad5238066057', '169.159.69.220', 1606359023, '__ci_last_regenerate|i:1606359023;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3c239988cfe60e23075c29fdad60507b5d9ea804', '5.194.200.160', 1610598836, '__ci_last_regenerate|i:1610598796;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3c2cc0461d5ad3e1cfbfc632c6ca25b479de37e0', '197.210.227.243', 1610548678, '__ci_last_regenerate|i:1610548677;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3c3c0711cff8064a98be1c10699755effceaeee3', '72.52.238.104', 1611662941, '__ci_last_regenerate|i:1611662941;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3c6f38ebd003310ce2617ac37b62de2d0e70a870', '129.56.109.20', 1611144270, '__ci_last_regenerate|i:1611144270;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3c9e291782479a45e9be7221acb0582ffadb0014', '197.210.174.180', 1604849507, '__ci_last_regenerate|i:1604849506;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3cb2a133f21d08c98175ecfade1802a8af24502b', '197.211.53.132', 1603217806, '__ci_last_regenerate|i:1603217806;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3cfa0f9cdc6d7e2d97f20bbc1705fb12ec45e928', '72.52.238.104', 1611661561, '__ci_last_regenerate|i:1611661561;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3d26e71eb70d0dc9786de884ec33be8eb217f15b', '41.73.1.65', 1604680606, '__ci_last_regenerate|i:1604680398;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3d40b4e2a45293f29f28994b39d0617c86d70358', '197.210.53.193', 1610641164, '__ci_last_regenerate|i:1610640910;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3d5b3a480a7ea1f6ee82ab1bc5aa19fe912b877d', '107.178.238.51', 1608600450, '__ci_last_regenerate|i:1608600450;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3d8ed2a3d2b177fbeb7e357bec13621ea57f691c', '41.73.1.73', 1608554215, '__ci_last_regenerate|i:1608554215;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3daf9123666d226754ffde8466704a2e92c6f096', '72.52.238.104', 1611663002, '__ci_last_regenerate|i:1611663002;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3db484bf0e2cbe7da5f14cfdf4112a914389477e', '41.190.14.105', 1610533407, '__ci_last_regenerate|i:1610533407;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3dr0j5i10a4sdjr0s13v3329jibrvnq8', '107.178.238.52', 1602006859, '__ci_last_regenerate|i:1602006858;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3e7e386262036d6952bf7115431512d7c33c628b', '54.36.148.27', 1606010216, '__ci_last_regenerate|i:1606010215;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3f8838ddb2447bdd2eb4d9ca32f33659176c5b7f', '41.73.1.67', 1610668060, '__ci_last_regenerate|i:1610668060;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3f9f39c0d8a0e1ac5c1597349e36d3b864243eb6', '197.210.227.243', 1610545714, '__ci_last_regenerate|i:1610545714;name|s:21:\"Odachi Cosmas Ejiofor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3fdd2b8383c23740befc6d52e28c0c36c83bdaf5', '107.178.238.33', 1603646054, '__ci_last_regenerate|i:1603646054;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3gbv9b3g2rsdjki8s8q81qph2uh6786s', '105.112.114.93', 1600180768, '__ci_last_regenerate|i:1600180767;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3goei5migvejvs0923lrbei6277sspos', '41.73.1.75', 1601986570, '__ci_last_regenerate|i:1601986230;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3i6rnj6o12pa7mjtul704spgt3dt38qj', '41.190.14.7', 1599411146, '__ci_last_regenerate|i:1599410982;redirect_url|s:50:\"http://admin.acce-abuja.com.ng/portal/parents/view\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('401d2263572912503a2442a13abe04abbb8ca48a', '197.210.71.168', 1603701316, '__ci_last_regenerate|i:1603701315;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('40b9a2e031317600d6822fb180f19c63c7fe605d', '197.210.70.226', 1609696265, '__ci_last_regenerate|i:1609696264;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/accounting/all_transactions\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('40hlsj11uj18tj3egpf32pi8c9os73q3', '41.190.14.129', 1594896561, '__ci_last_regenerate|i:1594896472;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4145247f2f031cdf81540bc7a1fe1d09c1d25d12', '197.210.174.180', 1604849507, '__ci_last_regenerate|i:1604849506;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('419e0848e093c5108e8b6bbbccebf137f019ab83', '41.73.1.69', 1610718601, '__ci_last_regenerate|i:1610718601;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('41a68cf2580cd03299b8a900ec553ac15955ca72', '197.210.226.134', 1610547491, '__ci_last_regenerate|i:1610547491;name|s:20:\"ibrahim ahmed kayode\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"20\";loggedin_userid|s:2:\"16\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('427dln8s992r32keagl4urmlson0j2jb', '41.73.1.66', 1602152954, '__ci_last_regenerate|i:1602152182;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4289b5e918875dcb0fdc1a34ba03f30c87cd6a45', '105.112.114.121', 1604036991, '__ci_last_regenerate|i:1604036991;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('42b850c5ae31884f62e2dbe773ceadb6e6c51037', '107.178.238.31', 1605729533, '__ci_last_regenerate|i:1605729533;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('42bcc8964e0d3f16d74ceb3860c7f8317c2040a9', '107.178.232.162', 1604325030, '__ci_last_regenerate|i:1604325029;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('43143aa1a1aa3418c0a81b948d9ba41c06c17155', '105.112.120.117', 1604485961, '__ci_last_regenerate|i:1604485959;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4320a3c7d55700a4b3800b0b94610ee41a851fef', '41.73.1.66', 1610919785, '__ci_last_regenerate|i:1610919640;name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"2\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4329439ac4b109a140de3e7245c964105d1f6cce', '35.203.245.153', 1610870479, '__ci_last_regenerate|i:1610870479;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('439fc7f6ff12fd0b962d18f585b7e96389e56471', '197.210.227.169', 1610558009, '__ci_last_regenerate|i:1610557922;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('43bdc8d3a240fe0409e144effb28daac95d5d966', '41.73.1.73', 1608577179, '__ci_last_regenerate|i:1608577179;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4441d7d8e46ea2ff75bfd870cc79392256ade12e', '72.52.238.104', 1611660121, '__ci_last_regenerate|i:1611660121;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('446d46774c02d1162a588ee6cea661a18647c34b', '129.56.70.197', 1603463537, '__ci_last_regenerate|i:1603463537;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('448620b171572b4e1488875142c7a11fe2cf47f3', '105.112.124.33', 1611141108, '__ci_last_regenerate|i:1611141007;name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:0:\"\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('44f6b9088a957de81b3733826b98cfe55214b37a', '197.210.227.243', 1610547056, '__ci_last_regenerate|i:1610547056;name|s:25:\"Odunola bashirat temitope\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"19\";loggedin_userid|s:2:\"15\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4567nlh7ripj443tfhgt4dcue7lt1c18', '41.73.1.76', 1596032663, '__ci_last_regenerate|i:1596032476;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45e8affa68953f5f5fef2dee5b3edce3832f13a3', '197.210.55.72', 1610623855, '__ci_last_regenerate|i:1610623853;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45faf250a31df957684ce910409f28d38ec3142a', '129.56.112.139', 1611582093, '__ci_last_regenerate|i:1611582093;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45r3jgec1ro6sljtc1i9007ivpv5osb8', '41.73.1.66', 1602159238, '__ci_last_regenerate|i:1602159237;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45ti3nmufr8iai90vh7l52dkia8mnmht', '105.112.121.55', 1602498187, '__ci_last_regenerate|i:1602498187;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46060866029b965b8e74588a9800f5d3618cddb7', '197.210.76.110', 1611145600, '__ci_last_regenerate|i:1611145600;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4615d3568eded1249e02c1db16f521d202bbface', '72.52.238.104', 1611660781, '__ci_last_regenerate|i:1611660781;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('461dirgtvk40hs8682dqucj0pum99euk', '41.73.1.75', 1601984718, '__ci_last_regenerate|i:1601983838;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('469e1f4be245dc0e658af73279cdcca7b0b7aeee', '107.178.232.177', 1609951802, '__ci_last_regenerate|i:1609951801;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46bbf85b13f1f664b2a17f130e521fa76febb7ee', '197.210.70.96', 1610782855, '__ci_last_regenerate|i:1610782855;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46c6n17gusmn0oqt3a5npk17ap0refhf', '41.190.12.33', 1596227917, '__ci_last_regenerate|i:1596227916;redirect_url|s:59:\"https://www.admin.acce-abuja.com.ng/portal/student/category\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4766dead929de91d8cbab79ca0b771770ffe1183', '197.210.55.72', 1610624141, '__ci_last_regenerate|i:1610624141;redirect_url|s:52:\"https://admin.acce-abuja.com.ng/portal/employee/view\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('47713db5e57fb6c26a398900fc75d29c45bc873a', '41.73.1.70', 1604158753, '__ci_last_regenerate|i:1604158753;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('479701993cf64b60b31fbfb85538a7ed045b9dd4', '197.210.227.243', 1610545524, '__ci_last_regenerate|i:1610545524;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4818940d6a6652bf202d9fe936d2b432d5e004b2', '41.73.1.65', 1604679939, '__ci_last_regenerate|i:1604679939;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('48e924e085753a3f66fd4c3f15c407f349020458', '72.52.238.104', 1611659882, '__ci_last_regenerate|i:1611659882;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4904f0f75a0841809d840503c49219d62e167db6', '72.52.238.104', 1611662582, '__ci_last_regenerate|i:1611662582;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('493ad649e269142e0df04153962b66aa49188644', '107.178.239.219', 1607733286, '__ci_last_regenerate|i:1607733286;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4948047d80fbf34074e825c6f70ddca18a92c9b7', '41.73.1.65', 1603972740, '__ci_last_regenerate|i:1603972740;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4948d8e30754e2597617bd0353a347803d434d95', '41.73.1.65', 1608718724, '__ci_last_regenerate|i:1608718723;redirect_url|s:66:\"http://admin.acce-abuja.com.ng/portal/accounting/account_statement\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49834fe8685d17144628215213292634bc8259cd', '41.73.1.67', 1610676294, '__ci_last_regenerate|i:1610676294;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49de0aef771751a4c28c9cca1d2bdbef72bda763', '41.73.1.67', 1610669147, '__ci_last_regenerate|i:1610669147;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4a0cfd5d167eebf9ae1db3bfe03e1653385f5e58', '41.73.1.75', 1603718322, '__ci_last_regenerate|i:1603718322;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4a60e95d57c771f339adbbdcbf67f5b8b5212f98', '197.210.71.94', 1610534664, '__ci_last_regenerate|i:1610534664;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4a73e69817f2be0c3bc7fba39a62014e5af5823b', '197.210.54.250', 1610568785, '__ci_last_regenerate|i:1610568785;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4a8479a9575067525849d35ef300359702c4a585', '41.73.1.65', 1604671634, '__ci_last_regenerate|i:1604671634;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4a85c161362fad42dbb40befcffaf533bbaf5bc8', '197.210.53.58', 1610470205, '__ci_last_regenerate|i:1610470189;redirect_url|s:63:\"https://admin.acce-abuja.com.ng/portal/attendance/student_entry\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4aa054f7ce9de89f1bb68162bf8ff4a2ee2b383a', '72.52.238.104', 1611661022, '__ci_last_regenerate|i:1611661022;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4aa8466f7c5191e7714fb96d1cdf17543998465c', '197.210.227.243', 1610548432, '__ci_last_regenerate|i:1610548432;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ae85ac94655c771cdc327778cda8f97c9e592a9', '197.149.127.197', 1611655409, '__ci_last_regenerate|i:1611655407;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4af70fb9b3da691cbf18526c1f2e9b058e242f16', '129.56.62.149', 1611147805, '__ci_last_regenerate|i:1611147805;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4af99ab2b943c3d660c7c5f02f1132e5d5de9b66', '197.210.226.134', 1610542769, '__ci_last_regenerate|i:1610542644;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4afb71c0585b47743733dd3b350aafdeec361820', '197.210.70.192', 1610785955, '__ci_last_regenerate|i:1610785864;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4b47ee8f645041c815a91faf7827c5fadcebd7bf', '197.210.226.134', 1610548633, '__ci_last_regenerate|i:1610548615;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4bcc9ba45066c6621c464bc7e03b25999bf9baa9', '197.210.227.243', 1610547741, '__ci_last_regenerate|i:1610547741;name|s:24:\"Oladebo abduljelil taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c4b246a421f810c2860061ea66f781033df3051', '105.112.121.109', 1610534146, '__ci_last_regenerate|i:1610534146;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c9dlrucqtdql28jcolgo7req63e61u6', '154.73.81.5', 1600286479, '__ci_last_regenerate|i:1600286479;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4cbfde1b1d4e0a0151602d26e6c8d643a0b85d6b', '41.190.14.105', 1610533712, '__ci_last_regenerate|i:1610533712;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ce326f8398fa7980fe468b6b34d36d09cb4fd40', '197.210.226.134', 1610545199, '__ci_last_regenerate|i:1610545199;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4cfd6f2d7f97e002463221819fbcb4a25c013222', '41.73.1.75', 1604412265, '__ci_last_regenerate|i:1604412265;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4d0bcfb3ac636c5ac38b23624b032b36b729a02c', '105.112.112.62', 1610455029, '__ci_last_regenerate|i:1610455029;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4d1a7a692b444f1acad45ec9a064734edcafa2b2', '62.100.211.135', 1608918464, '__ci_last_regenerate|i:1608918464;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4d41603554895d96521c0d19ad1118da4b77fa7a', '197.210.70.194', 1610626003, '__ci_last_regenerate|i:1610626003;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4d437db17ca25214dcfaee09fae2d7a1f2d9bde3', '197.210.227.28', 1610622416, '__ci_last_regenerate|i:1610622230;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4da5103e9de669921577f17cb60f009bb6bdd28b', '105.112.120.85', 1610556620, '__ci_last_regenerate|i:1610556437;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4dc15e1948f2d6aa69165d006a809edb1d40c91d', '197.210.174.181', 1603995198, '__ci_last_regenerate|i:1603995060;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4e1dba9c498d876a5e4d0e456e3ed4460e3995e7', '66.249.64.40', 1609250480, '__ci_last_regenerate|i:1609250480;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4e4a71d328210a426da6e0489cfcad96d16975fc', '197.210.71.74', 1603962496, '__ci_last_regenerate|i:1603962496;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4e6a73cd937470b41806679d2dacf6595cccd340', '72.52.238.104', 1611662462, '__ci_last_regenerate|i:1611662462;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ecb646bbc01190766dd8034945f447be71594a5', '72.52.238.104', 1611660722, '__ci_last_regenerate|i:1611660722;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4f5554eae5b1fd44a6e03eedc52e2177df295cae', '197.210.227.133', 1610551255, '__ci_last_regenerate|i:1610551255;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4fe80c00eaec0527c18904f8ef72fd89a50bd605', '41.73.1.77', 1604075558, '__ci_last_regenerate|i:1604075557;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4fe9e97077ee68722d948d1eda69282af250a820', '41.73.1.65', 1608718724, '__ci_last_regenerate|i:1608718723;redirect_url|s:63:\"http://admin.acce-abuja.com.ng/portal/accounting/expense_repots\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ngi1kalah53mpk5obk518d2qgobh9ch', '41.190.14.129', 1594895053, '__ci_last_regenerate|i:1594895048;redirect_url|s:48:\"http://admin.acce-abuja.com.ng/portal/live_class\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4qndmlikebmlcqjillebk6o08n8ed6ip', '105.112.121.55', 1602500782, '__ci_last_regenerate|i:1602500679;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('500c0e293451ac2aa338614e043e29aaa050449f', '41.73.1.68', 1606850427, '__ci_last_regenerate|i:1606850427;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/attachments\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50371cedaed5615f75637c9da2323b78c70278f7', '41.73.1.65', 1604671465, '__ci_last_regenerate|i:1604671465;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('506ccb7038c7118f9a762c13cfab4c6dba50fc80', '197.210.226.134', 1610537004, '__ci_last_regenerate|i:1610537004;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50f6d4ec67a1c5d58b1a36a8520b015a0a938a4a', '54.174.58.230', 1605393116, '__ci_last_regenerate|i:1605393100;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('51098b26aa157b23c29d1c1c32050cd16dc0bdb6', '197.210.76.47', 1604340417, '__ci_last_regenerate|i:1604340417;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5112fb47dcae1c35c6673c89ea0d5d340cbe62f8', '197.210.71.75', 1610650660, '__ci_last_regenerate|i:1610650660;name|s:23:\"sherifat aliya keshinro\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"16\";loggedin_userid|s:2:\"12\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('511f59283f1ce1a4c81cbeb4f2dbd4f45f2d0a56', '72.52.238.104', 1611661861, '__ci_last_regenerate|i:1611661861;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5141f36a190f1a74a61869d1da68a2a073f4b11f', '41.73.1.73', 1608578493, '__ci_last_regenerate|i:1608578493;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5164af7dc8acca87588c99e84f265925528568b7', '197.210.71.75', 1610649901, '__ci_last_regenerate|i:1610649901;name|s:23:\"sherifat aliya keshinro\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"16\";loggedin_userid|s:2:\"12\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('51687b5973b567956f6eadf8526c76d2c98376c2', '197.210.76.237', 1610751793, '__ci_last_regenerate|i:1610751679;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5168ba8e79a699fa2403213d235ab7978872458a', '197.210.227.243', 1610547222, '__ci_last_regenerate|i:1610547222;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('51fdd54c60117712b930237c7c434cf53f72412d', '41.73.1.74', 1603118447, '__ci_last_regenerate|i:1603118447;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('52735eb06377a25cd058e24c191919a3de19b98c', '41.73.1.74', 1608580088, '__ci_last_regenerate|i:1608580064;redirect_url|s:44:\"https://admin.acce-abuja.com.ng/portal/award\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('52979729456e8deabfc1b9808cde1321212784bf', '72.52.238.104', 1611660302, '__ci_last_regenerate|i:1611660302;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('537cb4654e24c99a052357fcb2a4e53b27fb3285', '41.73.1.65', 1604680443, '__ci_last_regenerate|i:1604680443;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5399fe4a8636620a358e5fe251c4546f4638e99c', '41.73.1.72', 1605174017, '__ci_last_regenerate|i:1605174017;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('53d08cdeecb3f56643fb6a6807b6aa65ee1c4287', '197.210.227.113', 1603994047, '__ci_last_regenerate|i:1603994027;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('53fe6231ac654048d1745555f9a6c94625d39c21', '72.52.238.104', 1611664382, '__ci_last_regenerate|i:1611664382;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('54de52e3128ad265933b0702dca03b94063e8d36', '197.210.76.237', 1610751679, '__ci_last_regenerate|i:1610751679;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('550d24e2541fb801f32f78032942cb5961277569', '72.52.238.104', 1611664442, '__ci_last_regenerate|i:1611664442;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('552a4babdf1727f9a324f0ca65e70d779f94cd20', '197.210.71.75', 1610650902, '__ci_last_regenerate|i:1610650891;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('555e7739961f5ce03a20071bb23cdb2c7126d953', '197.210.226.203', 1605996622, '__ci_last_regenerate|i:1605996622;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('55e48ab8a884b0e178ac1bde92f1643720f85194', '105.112.69.79', 1604213532, '__ci_last_regenerate|i:1604213532;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('55vigdthl6jo6k62d4cpc4gs21m1vbq7', '41.73.1.75', 1595863217, '__ci_last_regenerate|i:1595862908;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('56645a020e1a0d830318810051b20f4d28817632', '41.73.1.78', 1610458210, '__ci_last_regenerate|i:1610458210;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5669aad657c1dbab770449a0d41272a99591b40a', '41.73.1.65', 1604671100, '__ci_last_regenerate|i:1604671100;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('56d6418b6ef66a805f04df1ba28276851f939362', '72.52.238.104', 1611661502, '__ci_last_regenerate|i:1611661502;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('56e2575a236e423f5c398dcc73d6772237ce6a23', '72.52.238.104', 1611659701, '__ci_last_regenerate|i:1611659701;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5752ab6afa978dc508b2c959e7c4e38480e21fcd', '62.100.211.135', 1608918200, '__ci_last_regenerate|i:1608918199;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/accounting/all_transactions\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('578c454b1e9305ce0598458ae4cf523cb30775f8', '41.73.1.74', 1603115654, '__ci_last_regenerate|i:1603115654;redirect_url|s:69:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/read\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('578f44a3420ba35c7cc4041b8248d71c12faa444', '72.52.238.104', 1611659281, '__ci_last_regenerate|i:1611659281;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57c22fb4f32bc6aa8f53470020ec4479d4d28f02', '197.210.70.192', 1610785554, '__ci_last_regenerate|i:1610785554;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57f7586e2406e7c2b24f8c5b54231a80f3c76e34', '41.73.1.75', 1603717710, '__ci_last_regenerate|i:1603717710;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57ha4vf7nv2908cmorrf9ej03dat5i4m', '41.190.12.220', 1594819659, '__ci_last_regenerate|i:1594819657;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5826cbcda822af92bd705cb84a723f0eb9fc6ce6', '72.52.238.104', 1611663362, '__ci_last_regenerate|i:1611663362;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('58b78f45c4c06cf018ca13acae5bfd04e85a7ea0', '197.210.71.57', 1610754931, '__ci_last_regenerate|i:1610754931;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:25:\"Message Sent Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('58ee3012daf72854cb916513f000827c723880eb', '35.203.245.151', 1606492450, '__ci_last_regenerate|i:1606492450;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('59078685f657491e947e009b00350114b7f4df60', '72.52.238.104', 1611660962, '__ci_last_regenerate|i:1611660962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('591192f285c9f73c73a0c81e974a0259c973afbe', '197.210.227.243', 1610548126, '__ci_last_regenerate|i:1610548126;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('59291d7003c82e779bda84d7afe6a98fa73e28fc', '41.73.1.65', 1603970727, '__ci_last_regenerate|i:1603970727;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('595fad7e28614902c876d56638c21919db651af9', '41.73.1.65', 1604685958, '__ci_last_regenerate|i:1604685906;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('59e1bd8a408f73aad160b5e8a10624bbd1f6aa05', '41.73.1.65', 1604672275, '__ci_last_regenerate|i:1604672275;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5a31c1e9362d59dfeb8faabcda1e38edbc4e3544', '72.52.238.104', 1611659222, '__ci_last_regenerate|i:1611659222;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5a63ef90176c1ac11fb9de90c95d0ef651abd9ba', '72.52.238.104', 1611663422, '__ci_last_regenerate|i:1611663422;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ac23c1262545e21b94e9aeca258f6343d6f4174', '41.73.1.66', 1611663642, '__ci_last_regenerate|i:1611663642;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ad0d568668d633bc8a347f8a8dc8d17d8b7eacf', '197.210.54.98', 1603994027, '__ci_last_regenerate|i:1603994027;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5aisfpphnhm52b428abqr44c4c7ogunv', '202.208.170.70', 1595853839, '__ci_last_regenerate|i:1595853837;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5b154afd0ad300d4bda04b563946390d2c0ca570', '197.210.226.134', 1610548951, '__ci_last_regenerate|i:1610548951;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5b87af582b854ec0daa5f52df39ff203b1aad72b', '105.112.113.222', 1603529042, '__ci_last_regenerate|i:1603528838;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5bc2f81016885da071892332864274dfffb1e6fd', '72.52.238.104', 1611663302, '__ci_last_regenerate|i:1611663302;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5bc4fce44a6bbfd2e38efecc6b3622f02f70c8dd', '105.112.71.134', 1604213532, '__ci_last_regenerate|i:1604213532;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5c15c69f434a7fdc32c97c2fc1de1f4d533f2771', '197.210.226.134', 1610547141, '__ci_last_regenerate|i:1610547141;name|s:23:\"Farida Yussuff Avosuahi\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"14\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5c1a29d70baf71ff81ce11c56c36fe7d140f9f88', '72.52.238.104', 1611661322, '__ci_last_regenerate|i:1611661322;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d1392abbb2292ce3db44c497834c15211e80817', '197.210.227.133', 1610545835, '__ci_last_regenerate|i:1610545835;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5dae80df8e5d18fdd0d7e32d4ce6657ec09b0551', '41.73.1.65', 1603972384, '__ci_last_regenerate|i:1603972384;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5db24822774c9855ed67ff6b7f70fb39cedcaa95', '197.210.227.133', 1610546898, '__ci_last_regenerate|i:1610546897;name|s:20:\"ibrahim ahmed kayode\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"20\";loggedin_userid|s:2:\"16\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5dc7d1f643988a1d91eadb049aef483354ae2c7e', '129.205.113.240', 1603895410, '__ci_last_regenerate|i:1603895410;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e0c4889723f187df1e384c600c8c4fc9546c080', '72.52.238.104', 1611663842, '__ci_last_regenerate|i:1611663842;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e4842d0bb13ab1e4078aa80dc72c58e2c1d668d', '41.73.1.66', 1604666785, '__ci_last_regenerate|i:1604666785;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e7703a05157a28c05028a161fe9417493d11647', '41.73.1.66', 1602583331, '__ci_last_regenerate|i:1602583331;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e950d06bb565e3aae101e2dcdf7d2ef8a671774', '72.52.238.104', 1611659342, '__ci_last_regenerate|i:1611659342;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5eba43151247016885d9e3720662e12ce23457c4', '72.52.238.104', 1611662042, '__ci_last_regenerate|i:1611662041;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ebbf8c04ca65ac5b778ae95cf9b61ed8ef53aab', '105.112.116.199', 1610722653, '__ci_last_regenerate|i:1610722653;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ed2112909bcfcea23607f8a11176028e6f99677', '41.73.1.73', 1608575688, '__ci_last_regenerate|i:1608575687;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5f54c40b871ce094999e974f82262cc6107ccf59', '72.52.238.104', 1611660602, '__ci_last_regenerate|i:1611660602;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5f5994431c91a91e8bac049a8d256840022c1362', '197.149.127.197', 1604666693, '__ci_last_regenerate|i:1604666690;redirect_url|s:70:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5f7a68ffd4afb96191af93bd8ec08d489980d532', '41.73.1.70', 1609445016, '__ci_last_regenerate|i:1609445015;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5fbdbd686f62adc9e1c4b382f717b5d8a25e2877', '41.73.1.74', 1603117917, '__ci_last_regenerate|i:1603117917;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ff15b9f085b60f354168785f8fa455664264337', '66.249.64.37', 1606276252, '__ci_last_regenerate|i:1606276251;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ffb451b5b33689708301f816435f4dae60bcdf6', '41.73.1.66', 1611664446, '__ci_last_regenerate|i:1611664298;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5gfqh84p0qhuavf8ou7mbjnsp0nqd5ck', '41.190.12.93', 1594825398, '__ci_last_regenerate|i:1594825188;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5hur90963ouus6i9fmaem3cf122160jk', '41.73.1.66', 1602580086, '__ci_last_regenerate|i:1602579991;redirect_url|s:71:\"https://www.admin.acce-abuja.com.ng/portal/card_manage/id_card_templete\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5mpte36e9tnn30u0kvm1j9g069v52kgc', '41.73.1.76', 1596033452, '__ci_last_regenerate|i:1596033162;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5sgkpmug2u85h3g5onsh2lf4hu6bt5ip', '41.73.1.75', 1595853755, '__ci_last_regenerate|i:1595853735;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5te1ncs73vicr9nefjmjc5lsblqg59qg', '41.190.12.66', 1595377381, '__ci_last_regenerate|i:1595377380;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('60109c95f3f025825d646e6a2849d08d631a7c8a', '197.210.227.133', 1610547062, '__ci_last_regenerate|i:1610547062;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6039da6a35f16002b306671dbde84e9ebbc1cad3', '72.52.238.104', 1611663422, '__ci_last_regenerate|i:1611663422;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('60ae2163f31ab608b714a941890ade30382d9fa5', '41.73.1.78', 1610458329, '__ci_last_regenerate|i:1610458210;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('60cf2b35db6bf6d248b2d8e48207804ed08d6b83', '197.210.55.86', 1610617057, '__ci_last_regenerate|i:1610617057;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('611257e8423e7ad8402eb71e023723296d1e55be', '41.73.1.74', 1603472620, '__ci_last_regenerate|i:1603472620;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('61233fee3dd9570a0445ca8888faf84820c98383', '41.73.1.74', 1603115992, '__ci_last_regenerate|i:1603115992;redirect_url|s:69:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/read\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('612bb415626e2a5781c14ac2310ce65620814434', '72.52.238.104', 1611659882, '__ci_last_regenerate|i:1611659882;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('615c81dd9893855dde2be8f32d23fdbf8cb95e53', '129.56.66.121', 1611569619, '__ci_last_regenerate|i:1611569618;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6160978f23ca5661727747c2313c9cef1ef4cba9', '197.210.71.154', 1611419500, '__ci_last_regenerate|i:1611419500;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6209a242758ce2eb48f406faa8230e62af1fb69e', '72.52.238.104', 1611659581, '__ci_last_regenerate|i:1611659581;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6258168a61ff85d745eb876d53b8eed119604164', '197.210.227.133', 1610547056, '__ci_last_regenerate|i:1610547056;name|s:21:\"Odachi Cosmas Ejiofor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('62a751589964d9ff4d615c0f0ca3e92a1932c994', '72.52.238.104', 1611661921, '__ci_last_regenerate|i:1611661921;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('62daadcfe018d037c027972bad67316248891d8a', '105.112.117.229', 1610485805, '__ci_last_regenerate|i:1610485805;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('62ea981f24cf0c1c9ed5b5cbb1fd3d174ff1b82c', '41.73.1.74', 1603453530, '__ci_last_regenerate|i:1603453517;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6337bd26161c9534869a9365a1af86b3a32e1a93', '54.36.148.58', 1607704450, '__ci_last_regenerate|i:1607704450;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('636e73f135a2b4b005f9d55224fffa3eb65f01bb', '197.210.227.133', 1610546035, '__ci_last_regenerate|i:1610546035;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('639ae4e7376c0072f6f24f439ea62190a2957b33', '72.52.238.104', 1611664022, '__ci_last_regenerate|i:1611664022;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('63b844e4768442a7c477feea4a367419bda47cf3', '72.52.238.104', 1611659222, '__ci_last_regenerate|i:1611659222;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('63bedf887b73333e1fd75e432f796b1e7b92cd51', '72.52.238.104', 1611660902, '__ci_last_regenerate|i:1611660902;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6426248ceafed7014edb315ddba4f43408d85778', '102.89.3.115', 1608232832, '__ci_last_regenerate|i:1608232747;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('642de5abebe32bff1f8c903105728f59b2ccfdd1', '107.178.238.49', 1603983639, '__ci_last_regenerate|i:1603983639;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6487892cbcc9a067177a2116546bfed41e95785f', '54.36.148.45', 1610598916, '__ci_last_regenerate|i:1610598916;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64d10f78a437a078bcedfff63530457cbe7dbbf0', '105.112.121.57', 1604468333, '__ci_last_regenerate|i:1604468161;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64d2896a287ca57ac0e6103c4f4a64bde3df28b6', '41.73.1.65', 1604685294, '__ci_last_regenerate|i:1604685294;name|s:29:\"Dr. Mohammad Kyari Dikwa, mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64e0dff1a170654ebc7dec0de35aca810598019e', '197.210.227.232', 1610567904, '__ci_last_regenerate|i:1610567904;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64e76f3fbc7f323ac6517918140cf69b7ceb18e6', '62.100.211.135', 1608918200, '__ci_last_regenerate|i:1608918199;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/accounting/all_transactions\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64f12765dee15377f3ce8546d2fabe094b2b0ee4', '105.112.112.62', 1610453679, '__ci_last_regenerate|i:1610453679;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64mihken5bf2a0cr2es73ot9b9hs9jt0', '41.73.1.75', 1601895855, '__ci_last_regenerate|i:1601895855;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('650cb184ef05983e13af5d5cf8b40e32f63d652e', '41.73.1.68', 1608995118, '__ci_last_regenerate|i:1608995118;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('65ko1qgbdrcufkmu5c1or623mg7o1nqh', '41.73.1.68', 1594910790, '__ci_last_regenerate|i:1594910641;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('66931d302b477fd06078eb12055b58dec618abd5', '41.73.1.66', 1602586737, '__ci_last_regenerate|i:1602586737;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('669b52c14ba1ef3a946a3e23030b46e6038da6dc', '197.210.55.72', 1610623675, '__ci_last_regenerate|i:1610623675;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('66a84d14ddc58a8c92e06325b3456ae817f12cb0', '41.73.1.72', 1605171241, '__ci_last_regenerate|i:1605171241;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('66d733c1858ae59da409358451395a7ba76f6723', '41.190.14.105', 1610530553, '__ci_last_regenerate|i:1610530553;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('670c3cc485520852aee58adfff8fed1c4d36d51b', '3.138.32.247', 1606804977, '__ci_last_regenerate|i:1606804976;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('675844a4e9e417336965390802c7be0af145e464', '72.52.238.104', 1611662702, '__ci_last_regenerate|i:1611662702;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('677c0ca8b9ca9e6015e493e2291065e4f9855234', '72.52.238.104', 1611662643, '__ci_last_regenerate|i:1611662643;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('677ebf8009a535c8abfe74bf7276238b8b29baf9', '105.112.229.71', 1610469216, '__ci_last_regenerate|i:1610469216;redirect_url|s:54:\"https://admin.acce-abuja.com.ng/portal/library/request\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67a1b3adaca649f9ead9c720218737df7b3a22f4', '41.73.1.73', 1608578193, '__ci_last_regenerate|i:1608578193;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67cb738594c4636f9e0fc461a0745401d69cf285', '197.210.55.86', 1610623034, '__ci_last_regenerate|i:1610623034;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67d4ee6982f94850b5428baffb6eb8fb72ae91e3', '41.73.1.73', 1608552547, '__ci_last_regenerate|i:1608552547;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67e52fc2046fd9b6e382262501864b66a2580a63', '41.73.1.73', 1608578494, '__ci_last_regenerate|i:1608578494;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('687826db95fb42a74eae580a9928f67a79c281fd', '72.52.238.104', 1611663541, '__ci_last_regenerate|i:1611663541;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68a316319373cad9cd9741d15967a381a0d71ddd', '197.210.46.141', 1603836824, '__ci_last_regenerate|i:1603836824;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68bec3395796b4c79a40dfcf01dd02a90ab2d987', '41.73.1.66', 1602585340, '__ci_last_regenerate|i:1602585340;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68cf5514a6ed0ed51637f3209bae7494d62f1cc1', '41.73.1.73', 1610712317, '__ci_last_regenerate|i:1610712317;name|s:29:\"Dr. Mohammad Kyari Dikwa, mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68fa76e26e6c359a137bde372a4bd37940311017', '72.52.238.104', 1611662762, '__ci_last_regenerate|i:1611662762;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68fd69ce99957836315b0ae1a7223b54ad8ca0c5', '72.52.238.104', 1611660241, '__ci_last_regenerate|i:1611660241;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6985695027a558f9a142bfec8d10d6b4b84a7b0f', '72.52.238.104', 1611663962, '__ci_last_regenerate|i:1611663962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('69d741e42fcccc6c64eaef9c5dbe6b2044e601ac', '41.73.1.67', 1610673798, '__ci_last_regenerate|i:1610673798;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('69ee478195f2acdcb65562cf7292f65d514fe56c', '105.112.70.59', 1603923953, '__ci_last_regenerate|i:1603923953;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('69fadce0a91f34eb0a8bbc9398b65c400c580253', '41.190.14.70', 1604704719, '__ci_last_regenerate|i:1604704719;redirect_url|s:46:\"https://admin.acce-abuja.com.ng/portal/profile\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6a1bd0865be68c5256f3b7ad029f2bb203938c11', '41.73.1.69', 1610714169, '__ci_last_regenerate|i:1610714169;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6a29a2ee5d3758dad37395ae76a19d5a3ebd7a67', '197.210.227.243', 1610547587, '__ci_last_regenerate|i:1610547305;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6a708402bf2e141f45460c4f02500daf592b41d8', '197.210.227.133', 1610547722, '__ci_last_regenerate|i:1610547722;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6a910010240b6c82a2b1df067571cdd547e7519f', '197.211.53.145', 1605715578, '__ci_last_regenerate|i:1605715577;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6adfdff58ba309f06a1dfe902b87db4ab96a867e', '197.210.226.134', 1610545631, '__ci_last_regenerate|i:1610545631;name|s:23:\"Farida Yussuff Avosuahi\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"14\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6b2f328faed21b924db352ab711400521f1684b2', '72.52.238.104', 1611662582, '__ci_last_regenerate|i:1611662582;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6b2fdbbcab50bb578bb67d0c0008f0cf13489de4', '72.52.238.104', 1611662462, '__ci_last_regenerate|i:1611662462;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6b68ed05bd24492c3fec7ad8b9cc7674f42c286c', '72.52.238.104', 1611661682, '__ci_last_regenerate|i:1611661682;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6bca04f9bf540207e86d1f61eb7b37bc59f4aa7a', '105.112.69.105', 1603834523, '__ci_last_regenerate|i:1603834523;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6bf63859799e94b161f698ea8e6a6a41130165af', '72.52.238.104', 1611660662, '__ci_last_regenerate|i:1611660662;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6c77024401f9d29742dbdd52afa8a69e0a47b3d7', '72.52.238.104', 1611659342, '__ci_last_regenerate|i:1611659342;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6d3e36653aabf5d666c29f779fac5aade88db110', '41.190.14.254', 1610497575, '__ci_last_regenerate|i:1610497481;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6db24de2be8727511d58f2822942850774cb2e82', '72.52.238.104', 1611663902, '__ci_last_regenerate|i:1611663902;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6e3db7c6864904f46db51c832cc7d5d1fb9b0485', '197.210.227.133', 1610548448, '__ci_last_regenerate|i:1610548448;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6e71ec5dcf402a3b13150c218f69298a9a196233', '72.52.238.104', 1611662522, '__ci_last_regenerate|i:1611662522;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6e9ebdf1261019357ae3d25c8dc433eb7d778e97', '129.56.66.121', 1611568221, '__ci_last_regenerate|i:1611568221;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6f1bf96fc82045542294a8acf1a2244d59da99db', '72.52.238.104', 1611662042, '__ci_last_regenerate|i:1611662042;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6f713146f4ff29c84fbf142755db3aae763349c0', '13.66.139.26', 1610969138, '__ci_last_regenerate|i:1610969138;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6fd4392bc1dfcba089af407c4d317814ad961690', '197.210.227.243', 1610556748, '__ci_last_regenerate|i:1610556748;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6gd753b4lnl78jt7rvsh0jn7b996lt9j', '41.73.1.66', 1602163770, '__ci_last_regenerate|i:1602163712;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6h62q39qksgbu8cp6hcaoqq8r2lv4te5', '41.73.1.71', 1601385551, '__ci_last_regenerate|i:1601385225;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6h7n75k9s1b5cbpq315n28s7f4trrfb6', '41.190.12.66', 1595377973, '__ci_last_regenerate|i:1595377972;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6h9tpo2hsccs28cr0iineq23pb8n6f5i', '41.190.14.26', 1595074100, '__ci_last_regenerate|i:1595073762;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6sipblds38blea459r69q261vfum0j15', '41.73.1.71', 1601379641, '__ci_last_regenerate|i:1601378455;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6ufq3hus02410ed0gk1ak9ctjbbkcbg6', '41.73.1.68', 1601468219, '__ci_last_regenerate|i:1601467919;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7020b50f33843007ea7fefc83ae8777f5b22340d', '197.210.77.118', 1603570219, '__ci_last_regenerate|i:1603570219;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7026747b95624a5603524de3d452d4874af79cfb', '107.178.239.200', 1603310808, '__ci_last_regenerate|i:1603310808;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7031cf23f5dc4bd58065f9197316babff7cb3b01', '197.210.71.74', 1610537127, '__ci_last_regenerate|i:1610537127;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7034b539bfe55a56ebb1ac857e62df5d4e17f18e', '105.112.70.59', 1603918575, '__ci_last_regenerate|i:1603918575;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7059403e6a73a89f2c8ae0d77a4a15140d0e1808', '129.56.66.121', 1611567887, '__ci_last_regenerate|i:1611567886;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('710385b4f16fea5d3c5a4a6fefe0235716b90d91', '41.190.14.105', 1610532820, '__ci_last_regenerate|i:1610532820;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('712cfb93d33906fd93506f76cbab70307b7eca5e', '72.52.238.104', 1611660182, '__ci_last_regenerate|i:1611660182;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7141c7509c7502153537034785419f9d65ccd2bb', '197.210.71.83', 1606139892, '__ci_last_regenerate|i:1606139892;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('715079c45501d2e23872a5a590734cf8ee0675e8', '197.210.227.133', 1610545650, '__ci_last_regenerate|i:1610545649;name|s:20:\"ibrahim ahmed kayode\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"20\";loggedin_userid|s:2:\"16\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('719b68436f7084e6d1680d40411b868ff2648355', '94.123.154.172', 1611440939, '__ci_last_regenerate|i:1611440932;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('71b9e978c73bf4aad032fa8bbe15285902f84bf0', '197.210.227.243', 1610548594, '__ci_last_regenerate|i:1610548594;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('71d4adcef6ec726d24a4183cdfd8b52732d13f22', '41.73.1.73', 1608575275, '__ci_last_regenerate|i:1608575275;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('71e9ed4f9f6971c080fb522753afd0b38b3dcf76', '72.52.238.104', 1611663542, '__ci_last_regenerate|i:1611663542;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('728bde0ec441199d616655887aee04008070cb4d', '72.52.238.104', 1611660781, '__ci_last_regenerate|i:1611660781;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('72d726f42f2de8bf3ee72cb2f032c07b4d5e0800', '197.210.71.94', 1610533986, '__ci_last_regenerate|i:1610533986;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('72d7f041d10e77fcba41755cfd53d2a4133c8471', '72.52.238.104', 1611659522, '__ci_last_regenerate|i:1611659521;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('72df5da947a5c02519fc6fca832cae2d939be1c9', '72.52.238.104', 1611661806, '__ci_last_regenerate|i:1611661806;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('73199a75ab2dc6481f8d4c8379927c5ae98405e3', '66.249.64.37', 1609480217, '__ci_last_regenerate|i:1609480206;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7327b19ce1544e121b336f36a14369e108e66c41', '105.112.113.62', 1610620532, '__ci_last_regenerate|i:1610620311;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('73634c11d81484aafd10708669b90d063660e56d', '197.210.226.134', 1610548573, '__ci_last_regenerate|i:1610548573;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('740e5a71c80dd12482b319e18031c0acd69dd35a', '72.52.238.104', 1611661082, '__ci_last_regenerate|i:1611661082;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('742f33ae564f976b05ff3294f90e6cba2e41897d', '72.52.238.104', 1611659702, '__ci_last_regenerate|i:1611659702;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('746a6b08d4ac3acdae1d0724da381ecc3893c0c0', '197.210.226.134', 1610547114, '__ci_last_regenerate|i:1610547114;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('747ea22f2c172d7bbadf54d7441d5fd0c8bae7ab', '72.52.238.104', 1611659162, '__ci_last_regenerate|i:1611659162;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('74a616f74db73ec3593ba41cef5db9465b311b5a', '41.73.1.66', 1602595311, '__ci_last_regenerate|i:1602595229;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('75e8da3fca325ee2fc2680bf5337a9a351a47f61', '41.190.14.105', 1610534586, '__ci_last_regenerate|i:1610534586;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('766180a7c0ae67acee5791c39ae9d115ae5095ec', '72.52.238.104', 1611660182, '__ci_last_regenerate|i:1611660182;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('766d53a2a9ee2118a6ff65d669c90c9d9a5a4dc0', '72.52.238.104', 1611659521, '__ci_last_regenerate|i:1611659521;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('769cf442eae573eededc7883af88694a1e7a3ff6', '72.52.238.104', 1611659041, '__ci_last_regenerate|i:1611659041;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('76ed229be2e31f9c69ac9a23cf4a71c075f049fc', '105.112.71.234', 1607621934, '__ci_last_regenerate|i:1607621934;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('76f2b7a0ae1e402d35063745e8547678f712508f', '129.56.62.149', 1611147893, '__ci_last_regenerate|i:1611147805;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('77076a3cb531f92f5356a515e239d081b6cebef2', '197.210.76.100', 1603381946, '__ci_last_regenerate|i:1603381946;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('773aa9fbb9f427455572aa16012573343f480e7d', '41.190.14.77', 1603642523, '__ci_last_regenerate|i:1603642523;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('774o2hltfgbsa0rnugbb8tr1osi4k5e9', '105.112.114.38', 1600175477, '__ci_last_regenerate|i:1600175348;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('77e04a56a30daedcecbc4142d841b6c768cc4418', '197.210.227.243', 1610548933, '__ci_last_regenerate|i:1610548933;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('77e812bd7eb36d85f9ecd7f786560777b6bfd42d', '197.210.227.243', 1610548451, '__ci_last_regenerate|i:1610548448;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('77f3cc36e6ed3b1219bf15dd718662def72b05b6', '41.73.1.67', 1610670413, '__ci_last_regenerate|i:1610670413;name|s:12:\"Zainab Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"33\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"7\";loggedin_type|s:7:\"student\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('781f753882c7429c54a5fe7b80029eb957e85a1d', '197.210.71.173', 1610967855, '__ci_last_regenerate|i:1610967854;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('782a3c82433d02431bfaaf0cc2058660f24eeefe', '72.52.238.104', 1611660362, '__ci_last_regenerate|i:1611660362;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('785c369abfd9b17cf8a28701e480d168ec78cf60', '72.52.238.104', 1611659222, '__ci_last_regenerate|i:1611659222;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('78845141912aa7e1a3755431d4dbc78574c2dd09', '129.205.124.170', 1605291075, '__ci_last_regenerate|i:1605291074;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('78d6r6fpd9j5f2l0nsqj3v6245ke6dc5', '105.112.114.180', 1598558760, '__ci_last_regenerate|i:1598558703;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/event/types\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('79074da4bd7f69c6b3888c66f79420db6fb9f3fc', '62.100.211.135', 1608918216, '__ci_last_regenerate|i:1608918216;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/accounting/all_transactions\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('796f6bca0d12871bc78926e0fafbce53a0228e3e', '72.52.238.104', 1611659162, '__ci_last_regenerate|i:1611659162;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('79a40fbe9f6d566196c83c2a41213b14ec33802d', '197.210.71.201', 1611232268, '__ci_last_regenerate|i:1611232260;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7a64fa13c881943b3af0670940a10be9e9617f2f', '41.73.1.77', 1610718553, '__ci_last_regenerate|i:1610718256;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7a853484fedca822656bf6141019efe80e412560', '41.73.1.66', 1604663928, '__ci_last_regenerate|i:1604663928;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ab7f98e65ea8f6516359e09c88a44096b72d2cd', '41.73.1.65', 1603968080, '__ci_last_regenerate|i:1603968080;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ace18925729aac8780cc9edda2d4aff6563aa80', '41.73.1.65', 1603973623, '__ci_last_regenerate|i:1603973623;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ae6d48acbfde64eb7dd52ba6129088197061b39', '41.73.1.67', 1610671191, '__ci_last_regenerate|i:1610671191;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ba66afafa0e73d8189254507644c279dc2ad93a', '41.73.1.66', 1607600549, '__ci_last_regenerate|i:1607600549;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7bb91d9f933c91ed532f059b3713bd61ce167eef', '41.190.14.105', 1610533855, '__ci_last_regenerate|i:1610533712;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7c6c80a7e45ea5696e4fa9ec36de6a12eead0914', '72.52.238.104', 1611664022, '__ci_last_regenerate|i:1611664022;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7c73e2b7aaf7fd83f5ba1495f55878b8a29d4178', '197.210.71.74', 1610538531, '__ci_last_regenerate|i:1610538531;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7c9640239de1e2a509a0f7d108112c8367a8707c', '72.52.238.104', 1611663782, '__ci_last_regenerate|i:1611663782;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7d0041d960e6de7c6e0d3e8d15f3a04ba6e05fb1', '66.249.66.134', 1604459134, '__ci_last_regenerate|i:1604459133;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7d38eacce33867e261d2d4769fea14f60968698b', '41.73.1.72', 1608419557, '__ci_last_regenerate|i:1608419481;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7d61be96680ea867639eb3277cacc2b9875b7a2e', '105.112.113.68', 1603344641, '__ci_last_regenerate|i:1603344641;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7d7bda0d6f9d176788ea8c1a5c50576a09673598', '72.52.238.104', 1611661806, '__ci_last_regenerate|i:1611661806;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7d85a664c1b4f6586b73d6bda38a408191ae55d8', '197.210.226.134', 1610539891, '__ci_last_regenerate|i:1610539891;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7dc078d72b00938191931c4106e9ba7d1dc74ab2', '72.52.238.104', 1611660541, '__ci_last_regenerate|i:1611660541;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7e5c581c55b73d93adddf695c08399d1f0280592', '41.73.1.65', 1603970316, '__ci_last_regenerate|i:1603970316;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7e68e70f037079801d234af4e6f0116bbb436d0f', '197.210.226.134', 1610546717, '__ci_last_regenerate|i:1610546717;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7e80e54cdf76fe83c5402f3180cd0fbe299dbdc8', '129.56.66.121', 1611575884, '__ci_last_regenerate|i:1611575883;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7eb8bab8b80bb48a1fec60933daae7257caeaa00', '41.73.1.71', 1603805191, '__ci_last_regenerate|i:1603805177;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ec2100a12d80ce66428dc9d69731045f0e1d4b7', '41.73.1.69', 1604580665, '__ci_last_regenerate|i:1604580503;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7f1b21b3bb37be8ad1519f56f6a8823b8a9505e2', '169.159.113.234', 1606302487, '__ci_last_regenerate|i:1606302487;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7f39dd36360af7c894701f9db0ca2690b2b0bc6f', '105.112.112.62', 1610456592, '__ci_last_regenerate|i:1610456415;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7f504798838a918cb0b01123224f4dfca38ff809', '197.210.71.74', 1610535422, '__ci_last_regenerate|i:1610535422;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7f5585bf4272aa0e21d44c83382eef577d4cd0d8', '105.112.113.68', 1603344641, '__ci_last_regenerate|i:1603344640;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7fb1ec2a02343ff9e2ea7c2186d1039c930ef4cd', '41.73.1.65', 1603971572, '__ci_last_regenerate|i:1603971572;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7fb983453a27f6f7f5a5fe91f0f6f63141db437c', '72.52.238.104', 1611660182, '__ci_last_regenerate|i:1611660182;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7fbb47c0031f0630ecaeb4c30a80d58198f197d2', '72.52.238.104', 1611664321, '__ci_last_regenerate|i:1611664321;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7kcac70ua07crv4nphng1p1o1kmert9h', '195.121.71.71', 1595853836, '__ci_last_regenerate|i:1595853836;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7klup6b9405o0ssj966r2kgl4mcbkl5f', '41.73.1.68', 1594907409, '__ci_last_regenerate|i:1594907219;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7lmhov3m1jdbcsdbug0mul5ek4gka3qh', '41.73.1.76', 1596036127, '__ci_last_regenerate|i:1596036127;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7oqncihrcigqpsk075j1t8gv69o89au9', '41.190.14.129', 1594895798, '__ci_last_regenerate|i:1594895497;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7pi4h7314d5minfoa8q1cpfcprs5p389', '41.190.12.106', 1597058310, '__ci_last_regenerate|i:1597058274;redirect_url|s:70:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7rneicsiga8b3ipiic69q5l9i1f4hsv2', '41.190.12.93', 1594823771, '__ci_last_regenerate|i:1594823469;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8052e9a5fe19ef3b06e11af5fc12d49e84938728', '41.190.14.29', 1603711335, '__ci_last_regenerate|i:1603711335;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80613299f7a4877945905cb898644fca8dd632d4', '197.210.70.215', 1610530999, '__ci_last_regenerate|i:1610530999;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8085c121c407f11a84ad1cb5f23c2f8824b80b54', '72.52.238.104', 1611659461, '__ci_last_regenerate|i:1611659461;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8097ar4pertn021i2sbae6pd5qqok9gk', '41.73.1.68', 1594913886, '__ci_last_regenerate|i:1594913700;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('809b7793a15239e07b6205bb77ffba2d02ce1943', '197.210.10.21', 1603649840, '__ci_last_regenerate|i:1603649839;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80b1e2feafe2ed4520331fc140c6d835357c4549', '197.210.77.109', 1606067746, '__ci_last_regenerate|i:1606067746;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80db333c4f9fcb684a755a3ede7d8cfd7d6c5171', '41.73.1.69', 1610717099, '__ci_last_regenerate|i:1610717099;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80f0aab9215cae3b320851d9d31896be6906a946', '72.52.238.104', 1611662522, '__ci_last_regenerate|i:1611662522;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80g7pvc4k9v4itq05mgc0k6h3deiltio', '41.190.14.70', 1594931998, '__ci_last_regenerate|i:1594931998;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('816ddea16ec7eeeb0dce27ab3da636736a55d5fc', '72.52.238.104', 1611663122, '__ci_last_regenerate|i:1611663122;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81b625g6hk8qa0nhqb3fhiod9hnogge9', '95.159.73.132', 1601369931, '__ci_last_regenerate|i:1601369919;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81bb7f8ae8630687e5c721af616569ba60308b3d', '41.190.14.40', 1604655895, '__ci_last_regenerate|i:1604655893;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81c8ab8c1aea567e49d8b75a45cfd64228da7675', '72.52.238.104', 1611659281, '__ci_last_regenerate|i:1611659281;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81da55308cd42fc7f8bebb7604cd073872f12e9e', '197.210.76.74', 1610542062, '__ci_last_regenerate|i:1610541767;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81ju5rdt5h77s9tctrvs2mld827r9qee', '41.73.1.68', 1594914269, '__ci_last_regenerate|i:1594914269;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8205b9245bada743fbc36985d87726cd0b5c7edc', '197.210.227.133', 1610548588, '__ci_last_regenerate|i:1610548588;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8228d0dd36a00525366dfded83c7284aa21126c5', '197.210.227.28', 1610620954, '__ci_last_regenerate|i:1610620954;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82568bc0058b1e073a5af6d651d3aaf73244e047', '197.210.227.243', 1610548255, '__ci_last_regenerate|i:1610548255;name|s:24:\"Oladebo abduljelil taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('829a5bf308b290296875dd05cd68accb204bee9c', '41.73.1.65', 1608718724, '__ci_last_regenerate|i:1608718723;redirect_url|s:62:\"http://admin.acce-abuja.com.ng/portal/fees/student_fees_report\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82a22bdf29d9911543efff8be49be4f9d951e08c', '197.210.52.171', 1610538001, '__ci_last_regenerate|i:1610537985;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82b147b023e2a23e2d52598b83edc19387a270f4', '105.112.124.33', 1611149285, '__ci_last_regenerate|i:1611149284;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82b4861b6584e33c77b3d4e70b00355a7396da66', '105.112.123.23', 1603973831, '__ci_last_regenerate|i:1603973831;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82ced0c11ddcbf0acf46e446d445b7ebfec2f004', '107.178.239.219', 1607733285, '__ci_last_regenerate|i:1607733284;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82e909c3e637055d206362a492be0f745f01fe64', '72.52.238.104', 1611664083, '__ci_last_regenerate|i:1611664083;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('83421ce28d36c73d1c7411788b397b858b980ab0', '107.178.236.15', 1611325197, '__ci_last_regenerate|i:1611325197;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8349af882ba52b16f18ad00f5bb35f8fa1ee227e', '107.178.238.49', 1603983641, '__ci_last_regenerate|i:1603983641;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('83556edde86ef4c00c4e1a8abec469264569b9d3', '107.178.239.209', 1605369672, '__ci_last_regenerate|i:1605369672;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8367d52ebb9f33aa0d38db5473848c503735a7c6', '41.73.1.66', 1604663158, '__ci_last_regenerate|i:1604663158;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('83b9416d49f8e480f4ee68f35543220f5cffd0be', '197.210.71.74', 1610535105, '__ci_last_regenerate|i:1610535105;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('83ffad18d60aa717ef4a5851553f480b70b8b7ca', '197.211.53.132', 1603217806, '__ci_last_regenerate|i:1603217806;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8474c328887b66463ac7e233ef44c5858461e70c', '197.210.227.243', 1610542644, '__ci_last_regenerate|i:1610542644;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('84f14828cddcaee1107930900bca49792829d11d', '105.112.228.216', 1610576753, '__ci_last_regenerate|i:1610576753;redirect_url|s:46:\"https://admin.acce-abuja.com.ng/portal/profile\";name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('85520edb06a217e2c5691c3034c04b0c559c0167', '66.249.64.38', 1609352208, '__ci_last_regenerate|i:1609352207;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8570d4caaea8bf7c9201a5e6e6826d5faf2a5b99', '197.210.52.199', 1606581657, '__ci_last_regenerate|i:1606581657;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('85a18aad9c5571554732fab5aaa322507e36393d', '72.52.238.104', 1611664382, '__ci_last_regenerate|i:1611664382;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('85e47b8de9882f0c69c735bd4b6337f6bf6acb77', '105.112.144.204', 1607119095, '__ci_last_regenerate|i:1607119079;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('85e9774368e3a85969e63a9b2aa58b8df00dce4c', '41.73.1.73', 1608578494, '__ci_last_regenerate|i:1608578494;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('85ec5af443adb092f771fb20b4fa81d1d74cbafe', '72.52.238.104', 1611662222, '__ci_last_regenerate|i:1611662222;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('860c92b78b1724f03cc5e243d824cd9f97e3f78b', '72.52.238.104', 1611659103, '__ci_last_regenerate|i:1611659103;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86105440f55862a2b8ee391c6a691e3cd9797752', '72.52.238.104', 1611660061, '__ci_last_regenerate|i:1611660061;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8618e0dbf90e3d2499f2a21d4cead10bcbc519f0', '72.52.238.104', 1611664382, '__ci_last_regenerate|i:1611664382;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('864da527b419b1a1a68d8dc1bac33d9a7a6ae7d1', '197.210.76.38', 1605298599, '__ci_last_regenerate|i:1605298427;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('865e927773320ae272cb1fb2e9cc3d33adbb77d7', '197.210.227.133', 1610548560, '__ci_last_regenerate|i:1610548560;name|s:24:\"Oladebo abduljelil taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86a837beee495503e5fb44b71cf28bcdd9b002f9', '41.73.1.71', 1605815176, '__ci_last_regenerate|i:1605815176;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86afdc814f8a7857f48ec44fb9d892faeceb5164', '197.210.226.134', 1610552603, '__ci_last_regenerate|i:1610552603;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86d3d8597d3ba606895b97a26f958330dbf2efde', '107.178.200.234', 1609047977, '__ci_last_regenerate|i:1609047976;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('87bc1a682c0ab006d254fa7b9d8d474ea6d180fe', '41.73.1.75', 1603197266, '__ci_last_regenerate|i:1603197179;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('87dab2411f485f0f2f68a578470f503df794df98', '197.210.53.58', 1610748114, '__ci_last_regenerate|i:1610748114;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('87e461ede333c87644a9bab714f714e47847c1b3', '72.52.238.104', 1611660061, '__ci_last_regenerate|i:1611660061;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88364f72744be92cc5c74cc9cf581ddf803a789e', '41.73.1.66', 1610919591, '__ci_last_regenerate|i:1610919591;name|s:5:\"kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"32\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8856818dd1ee558931852c9205b03bf79dbf4d2f', '41.73.1.65', 1608718724, '__ci_last_regenerate|i:1608718723;redirect_url|s:64:\"http://admin.acce-abuja.com.ng/portal/accounting/incomevsexpense\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('885f175c517f7cdbfaaebc3ee6d7d313ef129f06', '197.210.227.243', 1610547404, '__ci_last_regenerate|i:1610547404;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88abff8db0b0f5f98d38de3544f65511bee7a76c', '197.210.227.243', 1610548712, '__ci_last_regenerate|i:1610548573;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88au573oq5hr5bc2qj4q88as5ieuj3dp', '41.73.1.76', 1596036137, '__ci_last_regenerate|i:1596036127;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88c93f3cd01eecaaa9f5c70e9ca4759f10a6ded6', '196.49.26.134', 1602595216, '__ci_last_regenerate|i:1602595216;redirect_url|s:72:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/compose\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8905cf7fc9d36fcd66da977ec42fccaf1e8442ad', '197.210.76.116', 1610719035, '__ci_last_regenerate|i:1610719035;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8964af0bf3b3507d86351eab829910a87354dee8', '197.210.65.80', 1605799858, '__ci_last_regenerate|i:1605799858;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('89a58da36d2b21d9f2edddd5cf3c5d7961c1e14b', '72.52.238.104', 1611664083, '__ci_last_regenerate|i:1611664083;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8a44b43472dad314ce371b13b23254be6cfd3dab', '41.73.1.74', 1603117577, '__ci_last_regenerate|i:1603117577;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8a552b9eb9cbe98569745df754587d72e35c2c4b', '197.210.227.133', 1610545622, '__ci_last_regenerate|i:1610545622;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8a5d996c3f15c2c5aae17228e5c5b5414127be85', '197.210.71.226', 1611570245, '__ci_last_regenerate|i:1611570245;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8a62302662b6944b54f1d6735f67a514950531b0', '72.52.238.104', 1611663481, '__ci_last_regenerate|i:1611663481;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b0a31cd781af7a1fd2f6a7caa770b1064c4abfa', '72.52.238.104', 1611660662, '__ci_last_regenerate|i:1611660662;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b2a3b914ba5b55f5bbb6e097fcf81fbecfb9c37', '129.56.109.20', 1611143536, '__ci_last_regenerate|i:1611143536;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b5b6643b311bab9c6857fe9013eb78003448164', '41.73.1.65', 1603968081, '__ci_last_regenerate|i:1603968080;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b7101d5369e0a9eaba1322c3457255f6898b606', '41.73.1.69', 1610716139, '__ci_last_regenerate|i:1610716139;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b7c9622618aefa9976dc0356e1aa3439bc5f339', '41.73.1.74', 1603449675, '__ci_last_regenerate|i:1603449675;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b8935c8a0dfa7af6d5457e30938861f1bb3da94', '41.73.1.74', 1603116949, '__ci_last_regenerate|i:1603116949;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8c6fd9c4bf4960b7b0a32580167e60e7f14f897c', '105.112.112.250', 1610543707, '__ci_last_regenerate|i:1610543707;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8cfe1557b4e603bd4a8e68ce70232e84ae020d53', '72.52.238.104', 1611662102, '__ci_last_regenerate|i:1611662102;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8d98d55b9b57a5beb2502001cbf2dbd5af2b93f5', '72.52.238.104', 1611661922, '__ci_last_regenerate|i:1611661921;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8df31652f5ecdbe5b9208a97316de2b096a58680', '41.73.1.73', 1608645204, '__ci_last_regenerate|i:1608645193;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8e751a658b1df2e291e6cfdaab12c487c942e865', '72.52.238.104', 1611661442, '__ci_last_regenerate|i:1611661442;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8e89a2109e564945e554fb5fa18379e32ae94021', '13.66.139.69', 1611489931, '__ci_last_regenerate|i:1611489930;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8edf17cb01e735a5fdab858ef4305f1d325cc102', '72.52.238.104', 1611664083, '__ci_last_regenerate|i:1611664083;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ee028daf4437a2cd3997c28a89fc3edf6612bcc', '197.210.71.226', 1611571334, '__ci_last_regenerate|i:1611571334;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8el1ds7a55s9q9392aki7e23lc251bbm', '41.73.1.71', 1601377622, '__ci_last_regenerate|i:1601377617;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8f0fbe3183d7e662b8ed6afe0e7b1023dcdb4f45', '197.211.53.132', 1603313759, '__ci_last_regenerate|i:1603313759;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8f6196f7d600fae8f77efc1bb590bd932803d9d2', '72.52.238.104', 1611662282, '__ci_last_regenerate|i:1611662282;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8fa37b72305f4ca0b0e2ef719a914606fdc0d29d', '41.73.1.74', 1603452179, '__ci_last_regenerate|i:1603452179;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8gh5ob0gu4j94rm4pbecqgq6kbj8ltij', '105.112.117.197', 1601289549, '__ci_last_regenerate|i:1601289397;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ikbj5ber9l2kcdb8og4qju5prl5ge79', '41.73.1.66', 1602160953, '__ci_last_regenerate|i:1602160945;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8imli7krqunbdn5fek9c8muub7upleda', '196.49.26.134', 1602152221, '__ci_last_regenerate|i:1602152209;redirect_url|s:56:\"https://www.admin.acce-abuja.com.ng/portal/system_update\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8lqlq820plo29hb1f3b315asri93a373', '41.73.1.68', 1594905314, '__ci_last_regenerate|i:1594905214;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8mumt957p7klslu6mse3621o5oel62a6', '41.73.1.66', 1602154799, '__ci_last_regenerate|i:1602154578;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8n7oahds2at04vjon0i278gunims9t9f', '41.73.1.75', 1595425258, '__ci_last_regenerate|i:1595425023;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8u3s8puv87f7im9o2tnn200r5h7jlju5', '41.73.1.72', 1601111886, '__ci_last_regenerate|i:1601111882;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90023f4a69e550063a0b7d61f40369cf8587be70', '41.73.1.74', 1603451311, '__ci_last_regenerate|i:1603451311;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('900758f981eab3b1d2d349a7679b4dbc8aef1dae', '72.52.238.104', 1611663962, '__ci_last_regenerate|i:1611663962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9020c0fad7cb968d262e9e394a627e478cccdb79', '41.190.14.105', 1610539451, '__ci_last_regenerate|i:1610539451;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9036b0b5ceab0c64de8eb5a2a2c5b568e42de729', '72.52.238.104', 1611660903, '__ci_last_regenerate|i:1611660903;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('906c48328d8b46a3b3426deb6095ee183c050562', '197.210.71.37', 1610545254, '__ci_last_regenerate|i:1610545142;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9079386838606e6ba6163d16bec49548363dc6fa', '197.210.227.133', 1610545623, '__ci_last_regenerate|i:1610545623;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('907d8feac7c38bed578a0c9944d837909ea45127', '197.210.227.133', 1610548426, '__ci_last_regenerate|i:1610548425;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90b27b1824053c8d3291a37d127532b304319ba1', '72.52.238.104', 1611661861, '__ci_last_regenerate|i:1611661861;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90cb99851e9020e187f11b705cc8332732dd456b', '72.52.238.104', 1611661561, '__ci_last_regenerate|i:1611661561;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90f7292d0827c2319c277b6b1ecba2f87c9720d0', '105.112.125.17', 1603408399, '__ci_last_regenerate|i:1603408399;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90imqtro7dj2fs502plq1ngnbjn8sqqo', '41.190.12.230', 1599058733, '__ci_last_regenerate|i:1599058524;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('913d4d84d460ccbfc73dee5f106b781ed2b37d24', '72.52.238.104', 1611660841, '__ci_last_regenerate|i:1611660841;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('91493e01560caf7b0ae66781fd331c7f7f37a828', '41.73.1.65', 1604671775, '__ci_last_regenerate|i:1604671775;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9176fc0bebdb9a281d4d7bb8dbdcd98ab47e134f', '72.52.238.104', 1611662702, '__ci_last_regenerate|i:1611662702;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('91f51e0fbc2fd45f7d84f24da883549ff17b610e', '72.52.238.104', 1611660481, '__ci_last_regenerate|i:1611660481;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('920ef58e9bf652e94a303857983c1962ee74d7f5', '197.149.127.196', 1610534552, '__ci_last_regenerate|i:1610534550;redirect_url|s:47:\"https://www.admin.acce-abuja.com.ng/portal/role\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('926718ad1408cad1b80e258c07f7af68f9bc00e5', '197.210.76.96', 1605366562, '__ci_last_regenerate|i:1605366562;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('928be36a2d18a19e898d6a7ef35191f197e69135', '107.178.238.31', 1605729533, '__ci_last_regenerate|i:1605729533;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('929d16d5e97eb64298e93d3454a24ff2414d0dff', '41.73.1.65', 1603973154, '__ci_last_regenerate|i:1603973154;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('92ff4ecbc842052c92d6b8be9f127b8690606cf2', '41.73.1.75', 1603719933, '__ci_last_regenerate|i:1603719933;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93958c665e0e6dd902809a2c32f341b87f5bc000', '72.52.238.104', 1611661261, '__ci_last_regenerate|i:1611661261;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93c5e478b44959738f6608718c318f6e96eed59b', '107.178.239.209', 1605369671, '__ci_last_regenerate|i:1605369671;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93s2hnkghe2prcmd35ii2295nmo980lg', '41.73.1.68', 1594908715, '__ci_last_regenerate|i:1594908452;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9420dfd447bc611806236f94dd7bcf74307a128e', '72.52.238.104', 1611661082, '__ci_last_regenerate|i:1611661082;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9424e44e05e7e10770cab2a9fbbc1a53ece42520', '41.73.1.67', 1610674842, '__ci_last_regenerate|i:1610674842;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('94bbfc18e90aaa79678db8ee62edc156f677066d', '197.210.227.133', 1610548963, '__ci_last_regenerate|i:1610548951;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('94d0d3d5f81a10fd704b794ddcfbe9486a1c1bf3', '41.73.1.66', 1611659473, '__ci_last_regenerate|i:1611659473;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('94fn7prquqniajcgf57vlkla1bhp4pni', '41.73.1.68', 1601469772, '__ci_last_regenerate|i:1601469686;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9507b8eae4305a810db4902c78778551b99c095e', '41.73.1.75', 1610380775, '__ci_last_regenerate|i:1610380774;redirect_url|s:56:\"http://admin.acce-abuja.com.ng/portal/settings/universal\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9509cfe7ee8914dc6329a81c50abb49c029a6418', '72.52.238.104', 1611663842, '__ci_last_regenerate|i:1611663842;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('95862da4c4969797ff690d2b171e31c6df232d74', '197.210.227.133', 1610547263, '__ci_last_regenerate|i:1610547263;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('95a25264525bfca3ba246fefb44b94d69482f08e', '197.210.77.127', 1611057799, '__ci_last_regenerate|i:1611057799;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('95f0cebdf16bced9120dd57c37ac595e4a950714', '72.52.238.104', 1611663302, '__ci_last_regenerate|i:1611663302;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96302a3d937a9173d02565f8390e785450701d02', '197.210.227.133', 1610546824, '__ci_last_regenerate|i:1610546824;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('969e409855052edeb3ae3e5cce13075bb821599c', '107.178.200.220', 1608161637, '__ci_last_regenerate|i:1608161637;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96a7155f0c040c18983d196592ada21fa8b69db4', '72.52.238.104', 1611659103, '__ci_last_regenerate|i:1611659103;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96bae444660fa14dbc630f1d26977f9fbaa356b6', '41.73.1.73', 1608580004, '__ci_last_regenerate|i:1608579895;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9707f6f05a31453d2fcc3f635e3006988bb13166', '197.210.227.243', 1610548281, '__ci_last_regenerate|i:1610548281;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('97217f6911eae370a677a85cc80daa923941dbc1', '197.210.71.74', 1603960646, '__ci_last_regenerate|i:1603960646;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('978efa45bfa658932b942f87eb62a40119dfca19', '72.52.238.104', 1611661861, '__ci_last_regenerate|i:1611661861;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('979b4dfb07dad513873020c39791748737f0873a', '72.52.238.104', 1611662341, '__ci_last_regenerate|i:1611662341;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('979ddc04c2e87bba623395635c94b1a8427100c6', '72.52.238.104', 1611664262, '__ci_last_regenerate|i:1611664261;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('97adae3a7a749e09e4c64671a18edd4bff686c0f', '72.52.238.104', 1611664202, '__ci_last_regenerate|i:1611664202;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('983ccf899cf29b7e8a2cebcc7523fe3fe81cac59', '41.190.30.14', 1605177504, '__ci_last_regenerate|i:1605177504;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('984e5fcba177bcccdf7c6bafa715d7d1b15a568a', '197.210.227.168', 1610552300, '__ci_last_regenerate|i:1610552300;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('98544331655879504e7188ecce5a84ac41f8558a', '72.52.238.104', 1611664321, '__ci_last_regenerate|i:1611664321;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('985fdf5e1d4fb186b7fec554005b3aad4898b3f9', '129.56.66.121', 1611561030, '__ci_last_regenerate|i:1611561029;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('98e8b2e45c9d48ac560e6b26a8a4fb9c52f0aa64', '197.210.227.133', 1610547516, '__ci_last_regenerate|i:1610547516;name|s:23:\"Farida Yussuff Avosuahi\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"14\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('98lhabidqqu8ptft5mrmi9inpaupg1n1', '41.73.1.75', 1595427905, '__ci_last_regenerate|i:1595427744;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('990d7aee75416f190ed5c1cbe613da525ae2b565', '41.73.1.74', 1603118613, '__ci_last_regenerate|i:1603118613;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9918618761e34f796b9ce9b30aea1daf462acdd8', '41.190.14.209', 1604704719, '__ci_last_regenerate|i:1604704719;redirect_url|s:46:\"https://admin.acce-abuja.com.ng/portal/profile\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('994229b304d6a1bbe30c6dbe9e7bed0dc511a6ba', '72.52.238.104', 1611663362, '__ci_last_regenerate|i:1611663362;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9953dda4c821a5b0ce9331a73e3b89a2c2992146', '54.36.148.146', 1608739624, '__ci_last_regenerate|i:1608739623;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('99741d34b8035c71ae4ac6e06cdef52aa4354571', '72.52.238.104', 1611658922, '__ci_last_regenerate|i:1611658922;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('99f6e67780a1774e831841f49384a17e5b3edbc7', '72.52.238.104', 1611659402, '__ci_last_regenerate|i:1611659402;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9a08c5b8f9140b036473d6565b3bf30561053e50', '197.210.77.99', 1611057838, '__ci_last_regenerate|i:1611057799;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9a7b2aaeb6b0faede0bd7a347221e19ca5c5b2fa', '62.100.211.135', 1608918465, '__ci_last_regenerate|i:1608918464;redirect_url|s:45:\"http://admin.acce-abuja.com.ng/portal/payroll\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9aaa60c332848614d706ff2b8bb77266db4c25ce', '105.112.112.62', 1610454728, '__ci_last_regenerate|i:1610454728;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ab32ad93e0bf502fce8aab3060ffe9b606381ec', '62.100.211.168', 1609065995, '__ci_last_regenerate|i:1609065995;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ac86d24388c3938504c0b1097921fe8e115f8d6', '41.73.1.73', 1608574221, '__ci_last_regenerate|i:1608574221;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9b42fdfffdd1eb95423ba3be92bfd29e273b6616', '197.210.76.25', 1603979998, '__ci_last_regenerate|i:1603979998;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9b5781b434ae5507a9903bda3bae29b8d3961002', '72.52.238.104', 1611661741, '__ci_last_regenerate|i:1611661741;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9b790d756900700faf2fde67b3ffcc6f68f987e7', '197.210.226.134', 1610545635, '__ci_last_regenerate|i:1610545635;name|s:24:\"Oladebo abduljelil taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bdc28f4253f4b7d050ac4735c62b1fc1523f4ee', '72.52.238.104', 1611663661, '__ci_last_regenerate|i:1611663661;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bfd6hn0aqj7png83lo4jq2tst47dq0i', '105.112.117.197', 1601289198, '__ci_last_regenerate|i:1601289076;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c32ece5170415e4d127309a686ebaaef30bd3de', '197.210.70.97', 1603812668, '__ci_last_regenerate|i:1603812668;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c51f5dfbaaf29e73811abeabad033ba0257b534', '41.73.1.65', 1604679962, '__ci_last_regenerate|i:1604679939;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c646fdb6b8288141dd6f16fadbc32ec8d757dea', '107.178.236.15', 1611325197, '__ci_last_regenerate|i:1611325197;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c692cd1cde9dbc66d8fc99f85b9ddedfa2e6e3d', '197.210.227.133', 1610546446, '__ci_last_regenerate|i:1610546446;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c6b6ca983fb7b9d20e8218de0eda173b9707cb9', '72.52.238.104', 1611662643, '__ci_last_regenerate|i:1611662643;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c6c1dc707b712197366ef74b09cc6609c801916', '72.52.238.104', 1611659582, '__ci_last_regenerate|i:1611659581;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c983ad648aa87f247f3d46eb4e65343da604336', '41.73.1.66', 1602590312, '__ci_last_regenerate|i:1602590312;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9cef9037108fa58f584665277427c259a0a84d8c', '66.249.66.132', 1603163500, '__ci_last_regenerate|i:1603163500;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9cmaukigm4vmnomckeasa01c4qh7mp4j', '41.190.14.129', 1594844896, '__ci_last_regenerate|i:1594844895;redirect_url|s:53:\"http://admin.acce-abuja.com.ng/portal/employee/view/3\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9d3c7b173f6a2383df5590e9ae89d13d9f79845a', '66.249.72.133', 1605491518, '__ci_last_regenerate|i:1605491518;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9d4c30d786452662d2d13687e1d3b2ef959e8bfd', '129.56.66.121', 1611575883, '__ci_last_regenerate|i:1611575883;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9d62dda026c64cb9942243af62cf8a9c8b4e76c0', '35.203.252.148', 1610410929, '__ci_last_regenerate|i:1610410928;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9daf1c046bca1aae520a4fd3a9a2244eda1050c9', '54.36.149.83', 1606603425, '__ci_last_regenerate|i:1606603425;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ee77f805199cc2dc2deb0f60819d881dcb36407', '197.210.70.215', 1610531777, '__ci_last_regenerate|i:1610531777;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f3518955e714987671d581c7a7f29f73b1c03e2', '197.210.55.86', 1610623853, '__ci_last_regenerate|i:1610623853;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f8b74665260672a88605c1b66c91b5ddbbb017a', '41.73.1.65', 1604682071, '__ci_last_regenerate|i:1604682069;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9fo7rd2ge53f5mudnvlcig50h4avp3ll', '41.73.1.75', 1595856007, '__ci_last_regenerate|i:1595856005;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ki3fdel63aqott25ddmcrmhafias8g0', '41.73.1.66', 1602163269, '__ci_last_regenerate|i:1602163068;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9oq5qq7v8724g9oesdlmgja6gmu0941j', '41.73.1.66', 1602155329, '__ci_last_regenerate|i:1602155324;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9po8o9g3p0h6mf0j166r09lj10u4psuv', '41.73.1.68', 1594916944, '__ci_last_regenerate|i:1594916944;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9qe0j49802jta6cnq9v0rsti99lrvnte', '41.73.1.71', 1601372360, '__ci_last_regenerate|i:1601369634;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9qmmkklbvurqlohq2j7p4k3p64klsj1b', '41.190.12.220', 1594818875, '__ci_last_regenerate|i:1594818841;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9rbas17s7ssq4f17s6k9331394pu6ono', '41.73.1.72', 1601112758, '__ci_last_regenerate|i:1601112757;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9sd00s5i1comlai7im4p821ad6icsnbt', '41.73.1.68', 1594915653, '__ci_last_regenerate|i:1594915567;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a00dc5558b825779cbcd90984ea624d907695fc6', '197.210.174.254', 1604040298, '__ci_last_regenerate|i:1604040298;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a019f556970fc4c9525616b3c0e549502baad9f0', '54.36.149.24', 1607572518, '__ci_last_regenerate|i:1607572518;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a02ac100e733afcdcfce0762a4e3d7515a4b4c44', '72.52.238.104', 1611660001, '__ci_last_regenerate|i:1611660001;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0b54197093b886d4ab26326cf951a25c2bca77f', '197.210.227.133', 1610547877, '__ci_last_regenerate|i:1610547877;name|s:21:\"Odachi Cosmas Ejiofor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0d77c93ceffb32cb830d091a0e8d7b16bc673ae', '41.73.1.69', 1610716487, '__ci_last_regenerate|i:1610716487;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0e39ac38fc5e4fb5b5ae02a1c69f23b7c570924', '41.190.14.206', 1604897186, '__ci_last_regenerate|i:1604897185;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0ef3a6fd63a21c658b0f2e5b36a78347f9b743c', '72.52.238.104', 1611663721, '__ci_last_regenerate|i:1611663721;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0ql3rii7rrm63aq36m1sr4aaqonvvvu', '129.56.31.36', 1601596054, '__ci_last_regenerate|i:1601596022;redirect_url|s:45:\"http://admin.acce-abuja.com.ng/portal/payroll\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a14db6811f0130e3836416853319c3dd2ba50cff', '197.210.227.133', 1610546340, '__ci_last_regenerate|i:1610546340;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a1957591728bae2cb6b38e3ce41444d90fe1e2ab', '197.210.227.243', 1610546039, '__ci_last_regenerate|i:1610546039;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a19fbda3776b7a53080e0c0cca29fa2b1df2cd78', '129.205.113.196', 1610958529, '__ci_last_regenerate|i:1610958480;name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"2\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a1bddff062d8e1110f993b3df1d3f48c9bf165d7', '72.52.238.104', 1611663902, '__ci_last_regenerate|i:1611663902;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a1c17d538d5acd984ae9715200ea84fe1af7b69f', '72.52.238.104', 1611664022, '__ci_last_regenerate|i:1611664022;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a1df646343ea89d0193c2bf1efba9dfffc88d09c', '197.210.53.110', 1610750045, '__ci_last_regenerate|i:1610750045;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2024ed8cc93b8ee92906f570e4ea41a874a73e3', '197.210.226.134', 1610546048, '__ci_last_regenerate|i:1610546048;name|s:20:\"ibrahim ahmed kayode\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"20\";loggedin_userid|s:2:\"16\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a227954a16fc556599765c95f885eecc22e61084', '105.112.112.62', 1610455372, '__ci_last_regenerate|i:1610455372;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2345d193e4df87a0c9cd3d4355e53e1f50f0774', '197.210.76.20', 1605364593, '__ci_last_regenerate|i:1605364593;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a25ac748d3ddf625b9da6af2e337a15ddcd3c7e1', '3.140.192.26', 1609408706, '__ci_last_regenerate|i:1609408705;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a26g05u8cr50d47863tncm5os099o548', '41.73.1.75', 1601894215, '__ci_last_regenerate|i:1601894214;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a28uk38stb3umjbpp232dpbjlqohagtt', '41.73.1.75', 1595856005, '__ci_last_regenerate|i:1595855634;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a296kibdtus1gtak222s4643cmajocvu', '41.73.1.75', 1601981955, '__ci_last_regenerate|i:1601981613;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2b0f947598013cdaf433c3b68f8abc8ad7be5d9', '41.73.1.67', 1610674254, '__ci_last_regenerate|i:1610674254;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2db3bb66791cf7ed80eed916ff10a41e73f8062', '62.100.211.135', 1608918220, '__ci_last_regenerate|i:1608918220;redirect_url|s:53:\"http://admin.acce-abuja.com.ng/portal/fees/allocation\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2f813e4443a4c349cc41d5d54e36c689610d617', '197.210.226.134', 1610548329, '__ci_last_regenerate|i:1610548329;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a32254c7a450121cb4bf5e3fc96d2e3122f9e9a1', '197.210.227.243', 1610546757, '__ci_last_regenerate|i:1610546757;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a32b815633e9f3079d63218868a0a8c1b8dda27c', '82.145.223.107', 1610981163, '__ci_last_regenerate|i:1610981162;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a33789159ec7837a3ac22450a22ee65e5eba51ae', '41.73.1.72', 1608418648, '__ci_last_regenerate|i:1608418648;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a352e5c991ba95b49430afe55d5f76fa190caf36', '197.210.71.168', 1603701316, '__ci_last_regenerate|i:1603701315;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a39b8c6b533551d54068b400db8eb3b20455cb7b', '72.52.238.104', 1611660722, '__ci_last_regenerate|i:1611660722;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a39bfda95272aafd970325682efcc77104e4177d', '129.205.113.196', 1610814434, '__ci_last_regenerate|i:1610814432;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3c7834e362d1db107f212ef6ad01293657aa07a', '197.210.226.134', 1610540329, '__ci_last_regenerate|i:1610540329;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3caa20699d6646d5427e6d8cfaa4f789232514c', '62.100.211.135', 1608918218, '__ci_last_regenerate|i:1608918217;redirect_url|s:62:\"http://admin.acce-abuja.com.ng/portal/fees/student_fees_report\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3f06c8fa3ebe97100ec6e18212fe662af1b0d51', '72.52.238.104', 1611661622, '__ci_last_regenerate|i:1611661622;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3vcn4hg19cj9hhn4qf926baaj7n2qpt', '41.73.1.66', 1602164468, '__ci_last_regenerate|i:1602164468;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a422f768e1e357469057899933145c727ed76c6a', '72.52.238.104', 1611662222, '__ci_last_regenerate|i:1611662222;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a45b7043ec0bb0978d66892a8b6a410bdf989db8', '197.210.226.134', 1610546371, '__ci_last_regenerate|i:1610546371;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a46254190bb7c28c39cacf6cbda425035c2e824b', '105.112.229.71', 1610470189, '__ci_last_regenerate|i:1610470189;redirect_url|s:63:\"https://admin.acce-abuja.com.ng/portal/attendance/student_entry\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a4967954dd6f74bb09e5c4172dc3bdc09c290b6b', '72.52.238.104', 1611659642, '__ci_last_regenerate|i:1611659642;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a4b7d3dc0299412b73ca65f537bc847352b397e8', '197.210.70.56', 1610742069, '__ci_last_regenerate|i:1610742069;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a524d8f04e17fb4f2471ff7d52e2e50f1f00bab5', '13.66.139.26', 1610805277, '__ci_last_regenerate|i:1610805277;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a54ff5c9a968e05f35f8ed4b5cfc8ec34b5ebae3', '105.112.120.60', 1603483426, '__ci_last_regenerate|i:1603483426;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a57003e9db3cc55597c08c966cf1557e0193d37e', '41.73.1.67', 1610670097, '__ci_last_regenerate|i:1610670097;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a5d13970dd436ef0ea729f01e43a78347a278a43', '41.190.12.71', 1606120450, '__ci_last_regenerate|i:1606120449;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a5m9cfbqmkhfia1tk2p9avnb2joaak4f', '41.73.1.75', 1595427058, '__ci_last_regenerate|i:1595426914;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a614ed69b253cf9fb902914216f3d437306af495', '105.112.124.76', 1608985751, '__ci_last_regenerate|i:1608985731;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6491ee019f444fa1acf1dab255c36219731491f', '41.73.1.66', 1607591697, '__ci_last_regenerate|i:1607591697;redirect_url|s:42:\"http://admin.acce-abuja.com.ng/portal/role\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a65297e895e37cc147a51dff9c42dc9c9b66c710', '41.73.1.65', 1604679241, '__ci_last_regenerate|i:1604679241;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6765d9dd27767c41b20a86bc51d823a4150a596', '72.52.238.104', 1611663422, '__ci_last_regenerate|i:1611663422;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6a59ed7b70e049a2114cc3fa59cf09b7fdf96d4', '41.73.1.71', 1606056674, '__ci_last_regenerate|i:1606056674;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6dea64a1eb840445b317b3f089913ce64b1a4b9', '105.112.117.62', 1610960625, '__ci_last_regenerate|i:1610960624;redirect_url|s:49:\"https://admin.acce-abuja.com.ng/portal/live_class\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a72b623dde1cfa9533ac337f33b63ecffd219e2e', '13.66.139.26', 1611131952, '__ci_last_regenerate|i:1611131952;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a750bca0aca54427bf545e9c2b9a8a007452ea3b', '72.52.238.104', 1611660302, '__ci_last_regenerate|i:1611660302;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a75ed510d6b819407c121250871de39b70b5983d', '41.190.12.179', 1604652639, '__ci_last_regenerate|i:1604652639;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7d9d91ea33115b71e6176ca424c4818c8ceab08', '105.112.121.109', 1610534455, '__ci_last_regenerate|i:1610534455;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7e73e17dd66a80796bbed789ef776f8cf365b10', '105.112.121.109', 1610526248, '__ci_last_regenerate|i:1610526248;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a85dd443e6f6415e25d132ea79c8a89aff647591', '72.52.238.104', 1611660421, '__ci_last_regenerate|i:1611660421;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a85fc758e6c73eaf37443b07fa5d858b75698372', '72.52.238.104', 1611659642, '__ci_last_regenerate|i:1611659642;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a898d4efee5036736f55e7fb7be03cb3695c3bdd', '197.210.71.154', 1611425999, '__ci_last_regenerate|i:1611425874;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a9359c53642ce1db30b5a6d63071c451aa5f7cdf', '41.73.1.65', 1603971572, '__ci_last_regenerate|i:1603971572;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a98ea57c5b4b8a9f153b11fe01ef95c6e07f0dd8', '197.210.71.154', 1611425874, '__ci_last_regenerate|i:1611425874;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a99f80b0f4a6aec3620d8a730e90ac82ce02bdd0', '41.73.1.69', 1610717638, '__ci_last_regenerate|i:1610717638;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a9de053adff3e276bb33a7bb922a4e28ddecf353', '197.210.227.243', 1610546036, '__ci_last_regenerate|i:1610546036;name|s:21:\"Odachi Cosmas Ejiofor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a9dee6d26238d6f45b5f3206472a16d22caff3fa', '129.56.112.139', 1611653244, '__ci_last_regenerate|i:1611653243;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa087834510c3bd8334d5a0ff19872374f43b56b', '72.52.238.104', 1611662941, '__ci_last_regenerate|i:1611662941;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa714b47da3cf14a02d8e9e4e63cefaafccee531', '72.52.238.104', 1611661261, '__ci_last_regenerate|i:1611661261;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aac2dcb51dbb4fe2541ce65196b2d45c5200671c', '41.73.1.70', 1603281098, '__ci_last_regenerate|i:1603281097;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aairlsgheb7mobio83vte9g8jlomb2ga', '41.190.12.66', 1595374987, '__ci_last_regenerate|i:1595374738;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ab0f98d423cec65a9aef7edca59a50a55130131d', '197.210.227.243', 1610548877, '__ci_last_regenerate|i:1610548877;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ab213daf81e8405ab7bf168736d7adf0d665e27c', '197.210.70.226', 1609696265, '__ci_last_regenerate|i:1609696264;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ab2rmne247jttnhp65ohr67h0qen8u0b', '41.73.1.75', 1595854550, '__ci_last_regenerate|i:1595854550;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ab34ae24ce2423ee8c73bf76dd9178bd32cc6c16', '72.52.238.104', 1611662102, '__ci_last_regenerate|i:1611662102;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ababd1c1fef53a4cc0de186828b7f79a506a5c3a', '62.100.211.135', 1608918215, '__ci_last_regenerate|i:1608918215;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/accounting/all_transactions\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('abcfef54873b22cc9001bf2d209f26d8ce17664e', '197.210.52.149', 1603382552, '__ci_last_regenerate|i:1603382552;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('abf8f169b7bd5dc22caa02f85ce3daa48faff5f9', '197.210.76.210', 1611649962, '__ci_last_regenerate|i:1611649961;redirect_url|s:55:\"https://admin.acce-abuja.com.ng/portal/fees/due_invoice\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ac23739a83113e3d1e6e4a2b62ef0a1190129869', '72.52.238.104', 1611661741, '__ci_last_regenerate|i:1611661741;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ac2c299cfeff56c95456c9853d245691bfe40613', '197.210.227.133', 1610548556, '__ci_last_regenerate|i:1610548555;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad03ad4d774010795434e7c0100f83c89162111c', '72.52.238.104', 1611663002, '__ci_last_regenerate|i:1611663002;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad0e957f3557e0145ddc441379276cddf5bf2508', '72.52.238.104', 1611661142, '__ci_last_regenerate|i:1611661142;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad2993edba59711cd6f9bddbdb147e59be2e74e0', '72.52.238.104', 1611662821, '__ci_last_regenerate|i:1611662821;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad43a8004456bd40a6c8033ef53f0ecc87cbeb1e', '107.178.200.220', 1608161638, '__ci_last_regenerate|i:1608161638;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad5db7307d8d01c5bb0d0b978060e25ae621a421', '107.178.239.200', 1603310810, '__ci_last_regenerate|i:1603310810;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad9284459fa5e4677835b0ada1e001b8404436c6', '41.73.1.70', 1609445016, '__ci_last_regenerate|i:1609445015;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad999c136d6f73e8ef2842ed1d2d809c0c3434d5', '72.52.238.104', 1611659522, '__ci_last_regenerate|i:1611659521;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ade6cf644eb086e885aa585809fa5b4f93c58619', '197.210.70.192', 1610785864, '__ci_last_regenerate|i:1610785864;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('adu03775luo60vm2j97gtpbuck9epclu', '41.73.1.71', 1601379938, '__ci_last_regenerate|i:1601379641;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ae906f0e4d9b968ce908be3e651da9abc8189a8d', '105.112.125.224', 1610711266, '__ci_last_regenerate|i:1610711257;redirect_url|s:46:\"https://admin.acce-abuja.com.ng/portal/profile\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aef69bbc98ab2fd33cbef99482607512a911a370', '197.210.76.110', 1611146026, '__ci_last_regenerate|i:1611146025;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('af17a8bcc846011c183c87e1109b5545a3d871b3', '197.210.227.243', 1610546041, '__ci_last_regenerate|i:1610546041;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('af623987b8fc30bfdcaa144c1a9a01707b66c0da', '41.73.1.65', 1608718724, '__ci_last_regenerate|i:1608718723;redirect_url|s:62:\"http://admin.acce-abuja.com.ng/portal/accounting/income_repots\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('af76908d54c23bd60ac8584b35277e4f2bc26beb', '197.210.76.110', 1611144676, '__ci_last_regenerate|i:1611144676;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('afon6jnvui7fpna5lshhg3macva0d918', '41.73.1.68', 1594908347, '__ci_last_regenerate|i:1594908113;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ao9upef8s8fb019ffl8ckhsrvnscv40s', '105.112.114.38', 1600176011, '__ci_last_regenerate|i:1600175804;name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"1\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('asbfq5fa5ju1d0ro05prnhpoknf0dbah', '41.73.1.75', 1601114858, '__ci_last_regenerate|i:1601114597;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('av3dm6ha1l1dahbes5591lmc4on62iga', '41.190.12.222', 1600282938, '__ci_last_regenerate|i:1600282938;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('avbu41dq9i8g8h727kvsquce6ootoi1d', '41.73.1.75', 1595424832, '__ci_last_regenerate|i:1595424555;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b02b2348d27ff176bce8e111aa96dbc44fe02ca4', '41.73.1.71', 1605815176, '__ci_last_regenerate|i:1605815176;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b0774fd3a67f4c188567eb96bcbcb9ed26378b1e', '62.100.211.135', 1608918221, '__ci_last_regenerate|i:1608918221;redirect_url|s:53:\"http://admin.acce-abuja.com.ng/portal/fees/allocation\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b07efa3d8d9c7202634f30f82e84aa3116668d29', '197.210.53.100', 1603366542, '__ci_last_regenerate|i:1603366542;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b0abe3ad53eeb7552848fb0da617f15b512c96bb', '72.52.238.104', 1611660602, '__ci_last_regenerate|i:1611660602;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b0c490cbcbc764ce3c3dd5d35384fd0756f33f0c', '72.52.238.104', 1611663481, '__ci_last_regenerate|i:1611663481;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b15669fc0b57b30e761cf0263eee1811b4a31e95', '72.52.238.104', 1611659883, '__ci_last_regenerate|i:1611659883;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b20ce4ed061a3534cad1a0ba29450e4fcdfb7c7b', '41.73.1.73', 1608556233, '__ci_last_regenerate|i:1608556232;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b20d99d501cec0b1930801194fd71f24a237f8d7', '35.203.245.151', 1606492451, '__ci_last_regenerate|i:1606492451;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b25206bbfec9e85caf1f4202962e75e4904f372c', '41.73.1.77', 1610733596, '__ci_last_regenerate|i:1610733596;redirect_url|s:50:\"https://admin.acce-abuja.com.ng/portal/attachments\";name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b286d34e7c4ff2cb504a8d4045914f07224ed191', '178.162.156.42', 1609400494, '__ci_last_regenerate|i:1609400493;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2b729a560dab001943ebce358ee35960452fe45', '41.73.1.73', 1608552917, '__ci_last_regenerate|i:1608552917;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2ec31d0a57a1af5c4ee6033860bed8da1c51057', '105.112.120.85', 1610556189, '__ci_last_regenerate|i:1610556189;name|s:24:\"Oladebo Abduljelil Taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b365bce178747f7933cc3cb32e41f05a58084872', '41.73.1.67', 1610675175, '__ci_last_regenerate|i:1610675175;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b38236ccd1652ebf8ca8de341d8abfcf1af80457', '197.210.55.86', 1610621398, '__ci_last_regenerate|i:1610621398;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3d60efcf896dfed7ef50463ecf582690cbf505c', '72.52.238.104', 1611664442, '__ci_last_regenerate|i:1611664442;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3da34d8a80ed9fa40b3d6c6a40c8d3efad0836c', '105.112.112.94', 1610493054, '__ci_last_regenerate|i:1610493054;redirect_url|s:54:\"https://admin.acce-abuja.com.ng/portal/library/request\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3dde895e5db26f6e340c461ee80252120932ff1', '41.73.1.74', 1603118491, '__ci_last_regenerate|i:1603118425;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b41ea5787af55e88d45121bb43bef05750702f63', '72.52.238.104', 1611660541, '__ci_last_regenerate|i:1611660541;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b43096411acb8162e7d653813a21e0e6396ca2af', '102.89.0.219', 1603304451, '__ci_last_regenerate|i:1603304451;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b440be56c8e388f7a2dae2683f278c37013bb482', '72.52.238.104', 1611659942, '__ci_last_regenerate|i:1611659942;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b48c4bb899d7393ca148476489eef24685c1b990', '197.210.76.83', 1611066985, '__ci_last_regenerate|i:1611066985;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b4d4f52d41ac14a133adca746860993ea9f11e36', '31.13.103.117', 1603367962, '__ci_last_regenerate|i:1603367962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b4f17699f055372660fe90186f4baa1b1226aaba', '66.249.72.136', 1605523350, '__ci_last_regenerate|i:1605523348;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b4f9d339e27a1120615c4d00d48c034dc4f2ac4d', '107.178.239.204', 1609497709, '__ci_last_regenerate|i:1609497708;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b4fd810bd0d7045e869e7376437e60a3cd75fa7e', '72.52.238.104', 1611662282, '__ci_last_regenerate|i:1611662282;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b50c77936e7550ab50d56029cf6eacab1e19de2f', '66.249.66.132', 1603163529, '__ci_last_regenerate|i:1603163529;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b52de2620eca685142b5a3038ccf243e1ba3cd93', '129.205.113.196', 1610545228, '__ci_last_regenerate|i:1610545228;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b541e6677ba9754d8ff5c68d5064a07d47069028', '72.52.238.104', 1611659281, '__ci_last_regenerate|i:1611659281;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b54c1a50f48a2346536f65d21101f1e45277b307', '72.52.238.104', 1611661741, '__ci_last_regenerate|i:1611661741;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b55100a7a55f5437d3a9cb2e4ec5a596d5e84d67', '72.52.238.104', 1611662042, '__ci_last_regenerate|i:1611662041;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b5a01710e4a43dbbf09a20418d1c4c488f7eedc8', '41.73.1.66', 1604666355, '__ci_last_regenerate|i:1604666355;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b5f3d9bbf3b7ad59a907cef73ecd6f7eb9e0e2a1', '72.52.238.104', 1611664141, '__ci_last_regenerate|i:1611664141;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b680b4def39f87cfaa858862bc5179e60792a0d4', '107.178.237.26', 1602979489, '__ci_last_regenerate|i:1602979489;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b6aa686ff5f9508bcedfad2f66c4ab7036cbbf3b', '105.112.230.103', 1610745426, '__ci_last_regenerate|i:1610745426;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b6cbed6e577e2295046379ae34dd039a6c5ffbc7', '41.73.1.73', 1608556234, '__ci_last_regenerate|i:1608556232;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b701e57e878e22f84417ef1702cd9d3a6369cd44', '197.210.227.169', 1610558096, '__ci_last_regenerate|i:1610558096;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b703595660b9b0cdcba13ed34a25b32508d90dda', '197.210.226.134', 1610547008, '__ci_last_regenerate|i:1610547008;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b72ba14401712b7b1ae62f33b343382d26e10e5f', '41.73.1.66', 1604669485, '__ci_last_regenerate|i:1604669485;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b73d1b5f28585501f348faafc22e1d9837d9c4fe', '197.210.76.77', 1610966338, '__ci_last_regenerate|i:1610966338;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"arabic\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b791dcc749afa390d3391972656412ca251cdda4', '72.52.238.104', 1611660061, '__ci_last_regenerate|i:1611660061;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b79ml7mg80o0jbglgaonprculf2u9kvi', '154.120.125.216', 1601452325, '__ci_last_regenerate|i:1601452325;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b8094c509cf818c5bd6c9dc0add5918f876da427', '102.89.0.186', 1610746647, '__ci_last_regenerate|i:1610746647;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b82ffc6e448fb6b4bd8167b93f601689253fcae3', '41.190.14.105', 1610539007, '__ci_last_regenerate|i:1610539007;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b841b90382e24823382e453e0a1d7a5c536e9e69', '197.210.53.246', 1605363971, '__ci_last_regenerate|i:1605363971;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b8711c21e99a00576c00cf215e0d2483bf7f357e', '102.89.1.60', 1610618414, '__ci_last_regenerate|i:1610618413;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b897c82d1b66abfc79397c174d2278ec7cc61167', '105.112.113.111', 1610912508, '__ci_last_regenerate|i:1610912508;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b8flh8dinssvdooc656gbnk2i597eb6l', '197.242.124.130', 1594855582, '__ci_last_regenerate|i:1594855582;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b91bu9hgf8ir4hv50am7fval10gi9ija', '41.190.12.66', 1595374691, '__ci_last_regenerate|i:1595374405;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b9c2477d969f0c04ad61b8fa0aff0fdd1712b3a0', '197.210.227.133', 1610546120, '__ci_last_regenerate|i:1610546120;name|s:23:\"Farida Yussuff Avosuahi\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"14\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b9f9ecc8ac1fab4c2c855248692d0c6e6ff45309', '197.210.52.151', 1611308271, '__ci_last_regenerate|i:1611308271;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba2c7dde621a87dbf5f25de08cc0b368071b5b8d', '41.190.14.77', 1603642524, '__ci_last_regenerate|i:1603642524;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba5f5749cba3136868062edb24815b6c196b7954', '105.112.124.236', 1610789852, '__ci_last_regenerate|i:1610789852;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"2\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba7bd3cef6c9d202cf8679715b395b0a4ce593bb', '72.52.238.104', 1611660241, '__ci_last_regenerate|i:1611660241;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba9d5vu3sh4q6lhi41brmmn5pudqc8q8', '41.73.1.76', 1599140274, '__ci_last_regenerate|i:1599140048;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bac5b428a7205e0ac7aa1d05926b74e7ec2a75ad', '197.210.71.23', 1603305035, '__ci_last_regenerate|i:1603304953;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bad69f649618caaa87dbb62e755b8b9b179e038c', '72.52.238.104', 1611663782, '__ci_last_regenerate|i:1611663782;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bafed69abd78d9e1b6be5a2e525bd49f549dc7d1', '35.203.245.153', 1610870480, '__ci_last_regenerate|i:1610870479;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bb08cce7c6d80bc56d81df565d73a2568f6491ba', '72.52.238.104', 1611662282, '__ci_last_regenerate|i:1611662282;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bb33047cd196213ed872e611d85de1a233b1137f', '197.210.227.133', 1610542321, '__ci_last_regenerate|i:1610542320;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bb4bfa2f6378b03f8a79dc51e4ad92485dbbe7a1', '41.73.1.66', 1611664298, '__ci_last_regenerate|i:1611664298;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bba88bd4c753ba8e0c91e28a8c2c6b8e5601740f', '72.52.238.104', 1611661561, '__ci_last_regenerate|i:1611661561;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbab4b85a64bb3d1c505a2413650ba83f1518320', '72.52.238.104', 1611659041, '__ci_last_regenerate|i:1611659041;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbae736958d5189f1fa2bc921f32f15cb8f0aea0', '41.73.1.66', 1610918699, '__ci_last_regenerate|i:1610918699;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbc4c969f324ad0d96232282e093b57ebeaf66f3', '41.73.1.66', 1610919455, '__ci_last_regenerate|i:1610919455;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbceb0fc00b05a813b2b7ca91da327480785acfd', '197.210.77.110', 1603832373, '__ci_last_regenerate|i:1603832267;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbe01781f0324b3f149cb6ee85a3f0e0e1d2a535', '41.73.1.73', 1608577684, '__ci_last_regenerate|i:1608577684;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bc0b9d61f262e35d8d60ddbcf7b08921706d4d3e', '197.210.227.243', 1610557102, '__ci_last_regenerate|i:1610557102;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bc33d08dcbb21d4b93348e6b5878d5a5310a79c8', '41.73.1.66', 1611315597, '__ci_last_regenerate|i:1611315597;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bd3cdc7d80e98be30b1f8db9d2664d464653344c', '105.112.112.250', 1610543756, '__ci_last_regenerate|i:1610543707;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bd3f73b41ba7aedbf009215c870e6b66a307db7d', '197.210.227.168', 1610556467, '__ci_last_regenerate|i:1610556467;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bd643f5328eb808c5155303451ba98c39a616c6e', '105.112.113.68', 1603344641, '__ci_last_regenerate|i:1603344640;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bde8f64ed0c381695123a38aa1dbb39a30dcc04c', '41.73.1.72', 1605174228, '__ci_last_regenerate|i:1605174159;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('be093ca4ab30434a16090a70e98c52c00b900a03', '41.73.1.74', 1603450856, '__ci_last_regenerate|i:1603450856;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('be1745497fe443287fac4ec2dfc0f9527dbb1c67', '31.13.103.4', 1603369624, '__ci_last_regenerate|i:1603369624;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('befa3bf158f17ceb41bd2a77ca20c4352270bfe1', '41.190.14.105', 1610538703, '__ci_last_regenerate|i:1610538703;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('befd42aae963a82ea989d95ace351ae40c4a3ee5', '72.52.238.104', 1611664261, '__ci_last_regenerate|i:1611664261;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf00078d452eef8ea5c15c591695b901c677d1ed', '105.112.121.109', 1610526901, '__ci_last_regenerate|i:1610526901;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf0f0453631fa86063384c5d73789a05408668f6', '72.52.238.104', 1611663002, '__ci_last_regenerate|i:1611663002;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf312031eef6f3491bb2cce4e276b5a0843d33f6', '197.210.227.133', 1610547054, '__ci_last_regenerate|i:1610547054;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf5be37fc0a0c35a3af88e39af8849291f4f06ae', '13.66.139.22', 1608047356, '__ci_last_regenerate|i:1608047355;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bfe8a0e50f903820f9297fbc91ad85c76d10b1d2', '197.210.227.133', 1610546317, '__ci_last_regenerate|i:1610546317;name|s:24:\"Oladebo abduljelil taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bg0j8h70tqqcnn5d75m75ci6npkdlhjg', '41.73.1.75', 1601893317, '__ci_last_regenerate|i:1601892282;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bh3362nbctv3brgier46bfv261496fnt', '41.190.14.26', 1595074177, '__ci_last_regenerate|i:1595074101;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bp9lb5fqh8lvv107uqvsjckon2huhtp0', '41.73.1.75', 1595857512, '__ci_last_regenerate|i:1595857510;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bsr3gq9b36ks2spdgn359khiuhpitric', '197.149.127.197', 1601596027, '__ci_last_regenerate|i:1601596027;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c065eca4e96adfb5c52f11f12608d4ffb9a7c14c', '72.52.238.104', 1611662582, '__ci_last_regenerate|i:1611662582;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c0f171b7f506682a7a221470e05f93679e2fb595', '41.73.1.66', 1604667547, '__ci_last_regenerate|i:1604667547;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c0f5c97a384af54921c0985aa4871ef643b0fa71', '72.52.238.104', 1611660962, '__ci_last_regenerate|i:1611660962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c12415af16f134d4a388f8cd91727ca2019238d1', '41.73.1.75', 1603717403, '__ci_last_regenerate|i:1603717403;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c12cdb15ecb2a5ac27fc7098867fe07b9da03081', '41.73.1.77', 1610719372, '__ci_last_regenerate|i:1610719372;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c13180f2161bc1061b71f7aa6a86460aa8f01576', '72.52.238.104', 1611662403, '__ci_last_regenerate|i:1611662402;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c13b5ff9b8fab6c04469b77edcd46883677a3558', '105.112.113.111', 1610911346, '__ci_last_regenerate|i:1610911346;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c215590308f0e08d696dae348d0fdc8b9c4af6f6', '72.52.238.104', 1611663061, '__ci_last_regenerate|i:1611663061;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c2973ba5759dc5832963b93beb6b13f008efa8bc', '72.52.238.104', 1611659761, '__ci_last_regenerate|i:1611659761;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c323e99128940e2ecbc02efd1f85e20b10b4d77f', '197.210.227.243', 1610557430, '__ci_last_regenerate|i:1610557430;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c370792878d972377d7f541d91ef1cd68f85c487', '197.210.227.243', 1610541984, '__ci_last_regenerate|i:1610541984;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c3gb3nqs3sqi7n84j6tseuvm8ggc31pp', '41.190.14.72', 1597054903, '__ci_last_regenerate|i:1597054839;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c440efa21699f6993cc0a26cf9c505b7ca80c7f0', '197.210.70.18', 1610719035, '__ci_last_regenerate|i:1610719035;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c45a31f2408c8fa66900505cccaf2c7f0f2335cb', '105.112.230.98', 1610745621, '__ci_last_regenerate|i:1610745426;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c49b872822c4360736fab1823e4464e05a2d4196', '197.210.76.82', 1610541767, '__ci_last_regenerate|i:1610541767;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c4bbb099f81a54c5e68d063441908172af200a65', '197.210.227.243', 1610548254, '__ci_last_regenerate|i:1610548254;name|s:23:\"Farida Yussuff Avosuahi\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"14\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c4be3630409d3dfaabee898b3f235935426fcfe8', '13.66.139.26', 1611055670, '__ci_last_regenerate|i:1611055669;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c5123063c1516a541c36082fa7c6a209c99affda', '197.210.226.134', 1610547321, '__ci_last_regenerate|i:1610547321;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c5e273d88ca10130cf7ac9968cb4b36d4753a13a', '105.112.113.215', 1603470503, '__ci_last_regenerate|i:1603470240;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c5f6ca8b63c7f4a4b94d2aa4556fa2c669934bfa', '62.100.211.135', 1608918221, '__ci_last_regenerate|i:1608918221;redirect_url|s:54:\"http://admin.acce-abuja.com.ng/portal/fees/due_invoice\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c63c7b6c0dab3bd48fe4ad90993c7f7f612b285d', '197.210.53.148', 1610541313, '__ci_last_regenerate|i:1610541313;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c659a2da72191219469cdd4de4e9702fad6b7448', '72.52.238.104', 1611663122, '__ci_last_regenerate|i:1611663122;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c67be031c6e0f27d9857c99bf221f6238725316a', '72.52.238.104', 1611663721, '__ci_last_regenerate|i:1611663721;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c680301e3a4d9666c2af8ab3c8564ccadeed176e', '72.52.238.104', 1611660481, '__ci_last_regenerate|i:1611660481;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c69e042c7bb314f042a543059100bebbbdc8166f', '197.210.77.127', 1611066212, '__ci_last_regenerate|i:1611066212;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c6cb2e3a1598320bc47828abb8794d4e868888fa', '41.73.1.77', 1610721964, '__ci_last_regenerate|i:1610721962;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c6d3606df7f0e99dab02802c406316798c41327e', '41.73.1.76', 1607104630, '__ci_last_regenerate|i:1607104630;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c76da5cfec0f9c0924d1640c39f4ccb276c28e00', '41.73.1.73', 1608576184, '__ci_last_regenerate|i:1608576184;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c7782aea979817d7aa43744ca4afd0d3b661b1bc', '41.190.30.14', 1605176599, '__ci_last_regenerate|i:1605176599;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c7f9c2e086c8d44432634455fd52694b47c57bb5', '105.112.117.229', 1610486695, '__ci_last_regenerate|i:1610486695;redirect_url|s:54:\"https://admin.acce-abuja.com.ng/portal/library/request\";alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c80551e22f772d301ad5aced6c6c5a2e4ff6fe8e', '41.73.1.68', 1606585855, '__ci_last_regenerate|i:1606585855;redirect_url|s:56:\"http://admin.acce-abuja.com.ng/portal/settings/universal\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c806663870e46bfe087dfa5586ae8de7fd689c5c', '72.52.238.104', 1611663842, '__ci_last_regenerate|i:1611663842;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c8249974be24da1e1934d90887bb3036ddb55233', '197.210.76.77', 1610966946, '__ci_last_regenerate|i:1610966946;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c826a43bfe4e6eaebc2b4241a5091959911a868a', '72.52.238.104', 1611660662, '__ci_last_regenerate|i:1611660662;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c8c019267b9e227caab8ad0287dae7d0af469c6a', '72.52.238.104', 1611661681, '__ci_last_regenerate|i:1611661681;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c8co704d75uepsmgqifvss24bg8o6qks', '41.73.1.75', 1601981027, '__ci_last_regenerate|i:1601981027;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c918282ae84197c2466745358da81cb74b5cc3d9', '107.178.238.33', 1603646053, '__ci_last_regenerate|i:1603646053;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c92abb3b84f133a4deb851a1a656d759ccec6ff2', '197.210.227.133', 1610546353, '__ci_last_regenerate|i:1610546353;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c94bf4844377ce623d18c8009f7d0a8803d661f2', '197.210.227.243', 1610546137, '__ci_last_regenerate|i:1610546137;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c985426c59b006800d8f966a5d59537ee6ab6c58', '41.73.1.65', 1603973955, '__ci_last_regenerate|i:1603973955;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c9bff20970e214a04296c336b81dcaf0f5f0f241', '41.73.1.69', 1608725527, '__ci_last_regenerate|i:1608725527;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca10ef996fd0042587b9fa69e52a2d82cfdfba7c', '66.249.66.136', 1603163426, '__ci_last_regenerate|i:1603163425;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca27b4f94fe1b847318201b87b8d020ef4ec1071', '197.210.226.134', 1610540842, '__ci_last_regenerate|i:1610540842;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca8a3f001d0ab08da65fcefb09883f6cb31011a2', '107.178.237.26', 1602979488, '__ci_last_regenerate|i:1602979488;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('caa785318948777ef4c6dcadef979205b42c0392', '105.112.124.236', 1610790208, '__ci_last_regenerate|i:1610790208;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"2\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cac6eb189fe1e71ca2b0cd51734bf37293875767', '72.52.238.104', 1611662882, '__ci_last_regenerate|i:1611662882;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cb1d3b437c072e2a4f62e415ec056ca680bf3232', '197.210.54.134', 1603555878, '__ci_last_regenerate|i:1603555682;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cb50c40149e85a3a0e94a2b07e998c4877e2c99f', '41.73.1.65', 1608718724, '__ci_last_regenerate|i:1608718723;redirect_url|s:62:\"http://admin.acce-abuja.com.ng/portal/fees/student_fees_report\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cb8fa310be195d100b14723e14e59c887b4d64a4', '41.73.1.73', 1610718397, '__ci_last_regenerate|i:1610718397;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cbe2b6f95cd413fb0aebb05fa00619a44c58c112', '129.205.124.170', 1605291075, '__ci_last_regenerate|i:1605291075;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cbeec50f160dfbc7209ed4c352fa82575924c146', '41.73.1.74', 1603116536, '__ci_last_regenerate|i:1603116536;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cc84414124cea2d08b49173d6cdc2479798e8eb8', '72.52.238.104', 1611661322, '__ci_last_regenerate|i:1611661322;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cc99b1f64d24c35ab0b04a0c0d1f66e89587338b', '197.210.65.77', 1604234300, '__ci_last_regenerate|i:1604234299;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cc9ecbd92c1cd46699dcd37731a557d6c575dfef', '197.210.226.134', 1610547387, '__ci_last_regenerate|i:1610547387;name|s:25:\"Odunola bashirat temitope\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"19\";loggedin_userid|s:2:\"15\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ccd7fe99a3403788244c8de914ee375ce307cd88', '72.52.238.104', 1611662402, '__ci_last_regenerate|i:1611662402;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cd0258a4d651a7072cfe882d8e0e50b1f39649db', '105.112.124.236', 1610790224, '__ci_last_regenerate|i:1610790208;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"2\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cd53db83b18b7534f472c35e9834bb01e4fc229c', '197.210.53.148', 1610540028, '__ci_last_regenerate|i:1610540028;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cda7irjeb47m36lml9qfr3av5fqvu6el', '41.190.14.129', 1594896103, '__ci_last_regenerate|i:1594896061;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cdb96bc843f080e53f97f051193cd97931b2a2fa', '72.52.238.104', 1611660001, '__ci_last_regenerate|i:1611660001;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cdda284d1b34d4a2050a71edbd1ff7e6821c8d44', '41.73.1.65', 1604670773, '__ci_last_regenerate|i:1604670773;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cddaa95542689ce0b3ca15dc072e32d09f153926', '41.73.1.68', 1606839310, '__ci_last_regenerate|i:1606839310;redirect_url|s:56:\"http://admin.acce-abuja.com.ng/portal/settings/universal\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cde8u4hg4971uibs52p3238q49cmj5ev', '105.112.121.55', 1602503903, '__ci_last_regenerate|i:1602503638;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ce54c5785aa60af185956c23344026160baa84b7', '197.210.53.178', 1603548818, '__ci_last_regenerate|i:1603548756;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ce69f0b82d7186807d14cb17357c70700d0d788d', '41.73.1.70', 1603285031, '__ci_last_regenerate|i:1603284916;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cebcf155dfd2327afb42c323d3ecaf5c7a710ce0', '72.52.238.104', 1611661982, '__ci_last_regenerate|i:1611661982;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cec06c4a1016e5af14fce1217bfd76b4ef6056bc', '41.73.1.65', 1604684534, '__ci_last_regenerate|i:1604684371;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cee4b8a25f7213a196986c24e6027a278fc149e8', '105.112.117.229', 1610487890, '__ci_last_regenerate|i:1610487890;redirect_url|s:54:\"https://admin.acce-abuja.com.ng/portal/library/request\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cesc50lomep2bk9pd1ovpitmp7i439p2', '41.73.1.75', 1597492052, '__ci_last_regenerate|i:1597492051;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cf19afab0c3d809027f8749561f3c0f7c7173e2e', '197.210.227.28', 1610618254, '__ci_last_regenerate|i:1610618254;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cf24b7bc7568543ae15fcd218c03a8df39f7da69', '41.73.1.65', 1604680957, '__ci_last_regenerate|i:1604680945;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:10:\"Umar Sanda\";logger_photo|s:36:\"b7c3a3cbccb9215506163355c4e086fb.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"5\";loggedin_userid|s:1:\"5\";loggedin_role_id|s:1:\"5\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cf567a5d4451fcaf9967141acd813da863b236f3', '197.210.77.130', 1603382648, '__ci_last_regenerate|i:1603382552;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cf89c972880b44d2243416ef5b22486fa03f90da', '62.173.36.14', 1604413053, '__ci_last_regenerate|i:1604413016;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cfa8ec11c945215beb992ae2b08faa6ab75de648', '72.52.238.104', 1611663602, '__ci_last_regenerate|i:1611663602;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cfddc70fd32592d87b31e9107597a15f0e69a291', '72.52.238.104', 1611661322, '__ci_last_regenerate|i:1611661322;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cff3b352ebfead1ab204bdf775a6e072e5bbce01', '197.210.53.246', 1605364907, '__ci_last_regenerate|i:1605364907;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d00a3887fbd6557021aefa3f23dce183686e547e', '197.210.227.133', 1610548537, '__ci_last_regenerate|i:1610548537;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d01e73a226eb14631605aa836511b52a4f08bd9e', '197.210.226.134', 1610546383, '__ci_last_regenerate|i:1610546383;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d04f4acbcc68d5622747b6d7410420a81d94d55d', '72.52.238.104', 1611659761, '__ci_last_regenerate|i:1611659761;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d08c0f92e780f976d3f3d6356236e52e73e335e8', '72.52.238.104', 1611662163, '__ci_last_regenerate|i:1611662163;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0b23bd564051b4814b3072ff5b498739251572a', '31.13.103.10', 1603369623, '__ci_last_regenerate|i:1603369623;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0e336edaa2e9df15d9316b4c41564d84ed52b97', '41.73.1.77', 1610721962, '__ci_last_regenerate|i:1610721962;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0e4313ab8e6f964e4853969e40e8b622c2f0515', '41.73.1.67', 1610675582, '__ci_last_regenerate|i:1610675582;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d10fae1daac06132e62b87fab1b279224ba56a72', '197.210.227.243', 1610548350, '__ci_last_regenerate|i:1610548350;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d14c0cd7b24a076e57bbcd74c5466c3ef79d8a10', '105.112.76.188', 1609611753, '__ci_last_regenerate|i:1609611753;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d16b13599569955ac30d0d578a73579a8753f61d', '72.52.238.104', 1611660602, '__ci_last_regenerate|i:1611660602;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d1b5a83aaf1458ec0aecef08a42a9f928ff3aecf', '66.249.64.37', 1606243776, '__ci_last_regenerate|i:1606243776;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d1u5j9be9drt406v533qa1q05551j65n', '41.73.1.75', 1601986575, '__ci_last_regenerate|i:1601986571;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d233eb3a37c947421512d4d9f7fa0a6cbd0864d1', '129.205.113.197', 1610524370, '__ci_last_regenerate|i:1610524332;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d25c910b615ccf1945ac2c345ba16326cc384f42', '72.52.238.104', 1611663362, '__ci_last_regenerate|i:1611663362;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d2962f506d68f0655ccb1ba118ca59b490471aa1', '41.73.1.70', 1609445016, '__ci_last_regenerate|i:1609445015;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d2ab9e32287b687a47d2fb7e672d997a327909bb', '197.210.70.23', 1606200665, '__ci_last_regenerate|i:1606200664;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d2bbed81e9c3d7b4a3184bb96688de6ac6858121', '197.210.76.20', 1605364283, '__ci_last_regenerate|i:1605364283;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d3077b36f42d2685955e62ca142cfa0322ccd240', '41.73.1.70', 1604160227, '__ci_last_regenerate|i:1604160187;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d35aa4ccdeb120b0298ce0768ac800777801ad15', '197.210.70.215', 1610531684, '__ci_last_regenerate|i:1610531679;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d3c5c95b9499b0f04348e95d9e4368f6e93ff7bb', '41.73.1.65', 1604670077, '__ci_last_regenerate|i:1604670077;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d3e7b399a5f31c4a3030b353d574ca585d6c225e', '197.210.226.134', 1610547465, '__ci_last_regenerate|i:1610547465;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d3f0497cba8595f08ae7cbf677d1ac99f52ec65d', '72.52.238.104', 1611661442, '__ci_last_regenerate|i:1611661442;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d46646d90032c3f7b429f7e051329287d11d56be', '72.52.238.104', 1611661022, '__ci_last_regenerate|i:1611661022;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d47a9fb098d6fc803b3c97095b3428a0eea9148a', '13.66.139.26', 1610913438, '__ci_last_regenerate|i:1610913438;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d4996673bf2da203b847e4fd686111197003cafc', '197.210.52.17', 1605363210, '__ci_last_regenerate|i:1605363210;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d4a36fbaf7af432a9f44e63fb7fc724d135ad711', '144.76.6.230', 1605123977, '__ci_last_regenerate|i:1605123976;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d4s2slqne6q2ktuk0sjho2ef2sha1kas', '41.73.1.66', 1602162722, '__ci_last_regenerate|i:1602161809;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5131fdcc7d198cccac676403da6b4c533628f7c', '41.190.12.179', 1604652980, '__ci_last_regenerate|i:1604652980;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:25:\"Message Sent Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d51a9f9496fd9871d86f39c06d0851f9bb6f8b27', '72.52.238.104', 1611662163, '__ci_last_regenerate|i:1611662163;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d554ac65246f88cd8c84fbb261602df10814d956', '41.73.1.69', 1604580505, '__ci_last_regenerate|i:1604580503;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5808ebc1e8075f673df8bfc3dd2a0db3c4f19cc', '105.112.121.109', 1610532396, '__ci_last_regenerate|i:1610532396;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5ba1567908304bcb847115e173fc1d3e6752b15', '54.174.54.12', 1605393116, '__ci_last_regenerate|i:1605393095;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5fdfbcf163f5eb72c239fa3c6879bcaab63f3be', '197.210.71.173', 1610967854, '__ci_last_regenerate|i:1610967854;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d60f5b70c4b1230e12ef8ecfc180aae1f8fa1a33', '105.112.117.86', 1603621563, '__ci_last_regenerate|i:1603621563;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d62c953a0d7e6622a83fe2461f1434869a788121', '72.52.238.104', 1611660421, '__ci_last_regenerate|i:1611660421;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d66hqk9lb3e5f95lld2ae7k0s55kl005', '41.73.1.68', 1594906106, '__ci_last_regenerate|i:1594906104;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d6ac20e77534959638f4ad3a24c6e74b3f222ea8', '197.210.77.94', 1603324205, '__ci_last_regenerate|i:1603324123;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d6ee27430c466fcf9d7847b41ad1bda5b66fa13e', '197.210.71.74', 1610536497, '__ci_last_regenerate|i:1610536493;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d72a5c7b59d89e8edd834e2fbf5767077fdb7be0', '197.210.226.103', 1605367725, '__ci_last_regenerate|i:1605367725;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d731341a76950366f60a9143f4ee1d9b1888d29a', '41.73.1.66', 1602595120, '__ci_last_regenerate|i:1602595120;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d75beedb39cc93c46e9da228960eafa76e42a824', '197.210.227.243', 1610549632, '__ci_last_regenerate|i:1610549388;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d779cc5ec7ce8396a1c268a3b1e0698dc6d42507', '72.52.238.104', 1611661201, '__ci_last_regenerate|i:1611661201;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d798022bc69c8b811781e55b30fd5773e4db39e7', '41.73.1.65', 1603975226, '__ci_last_regenerate|i:1603975226;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d79b5726314fe3ae88b69389779cd6d35ca16f5b', '197.210.55.86', 1610619072, '__ci_last_regenerate|i:1610618878;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d7d14203e02b78edf3ed9d3b60eeece3fc5a3aa1', '197.210.227.243', 1610546453, '__ci_last_regenerate|i:1610546453;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d8486563de0041abeafacc85607e81c2400fff62', '197.210.226.134', 1610556267, '__ci_last_regenerate|i:1610556267;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d84936fa490c53aa1b36358574df5f4f3ae2d080', '62.100.211.135', 1608918467, '__ci_last_regenerate|i:1608918466;redirect_url|s:59:\"http://admin.acce-abuja.com.ng/portal/payroll/salary_assign\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d8c407106fd060f631b1928d338deea4df81416c', '41.190.30.14', 1605177913, '__ci_last_regenerate|i:1605177843;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d90fd6a16c3a1f058053fd6b2039fe8dc5d25959', '72.52.238.104', 1611662222, '__ci_last_regenerate|i:1611662221;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d917f2831d45c528ade33d924905ff20cbb13a4b', '129.56.112.139', 1611641153, '__ci_last_regenerate|i:1611641153;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d93f8833b3c28bd6c2050988dc8c92d737982e5f', '41.73.1.66', 1610919030, '__ci_last_regenerate|i:1610919030;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d9acc7a99b815505f3d7e302b9194def67baea87', '72.52.238.104', 1611658922, '__ci_last_regenerate|i:1611658922;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da32dc8573b28ebf81830477ded8476a3ee8260a', '41.73.1.75', 1603720128, '__ci_last_regenerate|i:1603719933;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da5a4668ef1d45d183db3a5237a0aab57faaa717', '197.210.53.118', 1611308271, '__ci_last_regenerate|i:1611308271;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da5ddb7f01618c40f9a680919712c2d780bb0a5e', '41.190.14.161', 1607515129, '__ci_last_regenerate|i:1607515129;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da7ortobc26l4k2sv7cu3htmu6srfaoj', '41.73.1.68', 1594914880, '__ci_last_regenerate|i:1594914613;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da82d55b804d8fdea85238e370bbbc99a436167a', '72.52.238.104', 1611661982, '__ci_last_regenerate|i:1611661982;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dacb8401b4c4787690ad5cd16fc3b0dff02298cd', '197.210.227.243', 1610547004, '__ci_last_regenerate|i:1610547004;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dacbe8b3573a4408cacbf2fc3a03e64b1d24fb6d', '197.210.227.28', 1610624036, '__ci_last_regenerate|i:1610624036;name|s:23:\"sherifat aliya keshinro\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"16\";loggedin_userid|s:2:\"12\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('daef39h2ehme5hoc2pv70gqa42nn1uit', '154.120.125.216', 1601452332, '__ci_last_regenerate|i:1601452325;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db83cd95bf6f55c672f36b42326aa1551209dd1d', '197.211.53.150', 1606577881, '__ci_last_regenerate|i:1606577881;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dba6f43f778e1d0b83d34810b1f1d073554af3ab', '72.52.238.104', 1611659041, '__ci_last_regenerate|i:1611659041;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dbb24f1cada5ad0ef00fba0797790f7ccf8998de', '54.36.148.231', 1609100266, '__ci_last_regenerate|i:1609100265;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dbdmbs7mgbbmq673orfc1arscvltlg88', '41.73.1.76', 1596035419, '__ci_last_regenerate|i:1596035162;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dbf22610aef7f81864de411a0a60aa84b65f5f21', '41.73.1.66', 1602582282, '__ci_last_regenerate|i:1602582281;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dbfcb851f0f1a2b452cbc5d4290ec2252203c74c', '197.210.227.243', 1610541651, '__ci_last_regenerate|i:1610541651;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc38f5a1dd471623c618b4b08c7049dca444f627', '197.210.55.86', 1610622561, '__ci_last_regenerate|i:1610622561;name|s:23:\"sherifat aliya keshinro\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"16\";loggedin_userid|s:2:\"12\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc87014a22b99689c99167617d75af579cfcee25', '31.13.103.4', 1603367962, '__ci_last_regenerate|i:1603367962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc8f79f1d4d7175673cc47983005c275266e3b63', '105.112.72.161', 1606832046, '__ci_last_regenerate|i:1606832045;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dcdc1e072058c754abf79e4ec9bc74a5e599337c', '197.210.70.207', 1611352040, '__ci_last_regenerate|i:1611352039;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dd47a99b60293e7720bd2457dbb116fc9cb81f4f', '72.52.238.104', 1611663182, '__ci_last_regenerate|i:1611663182;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddf629f7d360fc92f343ad42b8347ac0830dec0d', '66.249.75.168', 1610219415, '__ci_last_regenerate|i:1610219414;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddf9129221231ce06d1e071b55483563d25d88cc', '72.52.238.104', 1611661201, '__ci_last_regenerate|i:1611661201;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('de0661c711616fe18fedf11040b6804dec7cbf88', '129.205.113.196', 1610545233, '__ci_last_regenerate|i:1610545233;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('de0b2bfcc6f7e5ca7e08d45be2af5ff2820d825e', '41.73.1.73', 1610710954, '__ci_last_regenerate|i:1610710954;name|s:11:\"Yusuf Bello\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"27\";loggedin_userid|s:1:\"5\";loggedin_role_id|s:1:\"7\";loggedin_type|s:7:\"student\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('de7bfd399939b6b16541eb8d1f13bc8b6bf5d910', '66.249.72.34', 1608850791, '__ci_last_regenerate|i:1608850791;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('decbf72e73956a93883f1e07c8368f79fc3fe4ab', '197.210.71.74', 1603962672, '__ci_last_regenerate|i:1603962496;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('df6a0a413430732a048290b9860e4323f12efa08', '62.100.211.135', 1608918464, '__ci_last_regenerate|i:1608918464;redirect_url|s:52:\"http://admin.acce-abuja.com.ng/portal/advance_salary\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfa58b280f1ef8662a70a062f0d0e3dd4aaff5f2', '72.52.238.104', 1611659461, '__ci_last_regenerate|i:1611659461;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfd8351e689fdd25e2c64fdae4bb71febf4b2c9d', '54.36.148.179', 1610272843, '__ci_last_regenerate|i:1610272842;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dkcbam9ba5c1tbaahl4e24nai9aevsgo', '41.190.12.220', 1594819660, '__ci_last_regenerate|i:1594819658;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dm2meankpcbm36r9ut6nnv0q94ltfpff', '41.73.1.75', 1595863426, '__ci_last_regenerate|i:1595863221;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dpdvvc2765dgefi56fms3t8kl1b39u4h', '41.73.1.75', 1595426740, '__ci_last_regenerate|i:1595426567;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dquchmh9hm4r1bi12dhcf797gd2hjmc9', '105.112.114.38', 1600177331, '__ci_last_regenerate|i:1600177107;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('drfa879lnhnmi3stn66nnimp99gphrat', '41.73.1.71', 1601381079, '__ci_last_regenerate|i:1601380905;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dvf318njjontksi2c70l6pjrlgaqifth', '41.73.1.75', 1601891907, '__ci_last_regenerate|i:1601891190;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0149cf4309ae78f713f08de342751ff2907c684', '72.52.238.104', 1611660781, '__ci_last_regenerate|i:1611660781;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e022166628abc3d2230e80490bc8881f5fdc761f', '41.73.14.242', 1610719766, '__ci_last_regenerate|i:1610719766;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0769c9cef034d3f959fa835732587eed205248c', '107.178.237.28', 1606100792, '__ci_last_regenerate|i:1606100792;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0ea4be6f37a443c51204779429d5b4d6b3c1072', '41.73.1.74', 1603473763, '__ci_last_regenerate|i:1603473763;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0ec441dc14ec088cfbf0fb7da6196d2642d49ff', '72.52.238.104', 1611663782, '__ci_last_regenerate|i:1611663781;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0ef4725cdbfb41cb7618b3ca26f7acc36d3d318', '197.210.174.180', 1604849752, '__ci_last_regenerate|i:1604849506;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e11bc79260c02aa9867b813a79a2a33017a434fb', '41.73.1.66', 1610919700, '__ci_last_regenerate|i:1610919455;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e1610a459bb9a4891eb01361c0d5b50da7d68f8e', '35.203.252.156', 1605018051, '__ci_last_regenerate|i:1605018051;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e17796a2e0e9202f128e2df8e534865bfd32685d', '105.112.123.98', 1609789204, '__ci_last_regenerate|i:1609789170;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e1ca1d6d4c2c9e34740a423d0c2eb44b22eb3c58', '54.36.148.46', 1611296303, '__ci_last_regenerate|i:1611296302;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e21clg9tit1n4bu4j17hersm1n17r9li', '105.112.113.10', 1600779170, '__ci_last_regenerate|i:1600779146;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e2316e59b3403ac54fdcf9cecee49f315c6facf7', '35.203.252.146', 1607313502, '__ci_last_regenerate|i:1607313502;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e248957158fcad175a5426a60c7a34f5017e2f4b', '41.73.1.70', 1604160187, '__ci_last_regenerate|i:1604160187;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e25b3a421224dcbfcaabc3e00b9efc055fd9b3cf', '197.210.55.126', 1605368007, '__ci_last_regenerate|i:1605367725;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e28a9c5cf5c2b63029a9ccdf404340155ac3e93e', '72.52.238.104', 1611664442, '__ci_last_regenerate|i:1611664442;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e292a8a30f6d3d93b9fcb6dd4d3324a5bc4c0774', '197.210.227.243', 1610556142, '__ci_last_regenerate|i:1610556142;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e2svsbv8060ncn3a4unranehuho9m1pv', '41.73.1.71', 1601375694, '__ci_last_regenerate|i:1601375694;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e34f60753c353be529562209f35a85a5cd4b3b8a', '72.52.238.104', 1611664321, '__ci_last_regenerate|i:1611664321;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e350c4ab88653f6b819b807a1e708d83bdb7fde0', '107.178.200.234', 1609047978, '__ci_last_regenerate|i:1609047978;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e42e47d7dc4bc1591becc19cee577d66ad33d0e6', '72.52.238.104', 1611660962, '__ci_last_regenerate|i:1611660962;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e4453e5370e1f542ae637073ce226679c978d2c0', '72.52.238.104', 1611663721, '__ci_last_regenerate|i:1611663721;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e4bc3bb8f13c3201a257dc8ebc917309bca23c86', '105.112.120.251', 1603545914, '__ci_last_regenerate|i:1603545914;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e5253f08b366171aa1c351b02d8a1ceeb9e4bc2b', '105.112.120.85', 1610556558, '__ci_last_regenerate|i:1610556558;name|s:24:\"Oladebo Abduljelil Taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e52e4c4a71e3edcbc7d380492ccaef4594feb48a', '72.52.238.104', 1611663661, '__ci_last_regenerate|i:1611663661;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e585f7b1971dcc7b3640536b637c3ea623241480', '197.210.226.134', 1610546735, '__ci_last_regenerate|i:1610546735;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e5a1c2e175306ef91e75f5286b2ad533e571d448', '72.52.238.104', 1611662462, '__ci_last_regenerate|i:1611662462;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e5a33f60b0abb07b80ce2abd00be6ebf12d06508', '72.52.238.104', 1611662762, '__ci_last_regenerate|i:1611662762;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e5c19d63580162654d8d8e83c7287e61140b671b', '41.73.1.65', 1603975230, '__ci_last_regenerate|i:1603975226;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e629ea3d7a017da2dc43e7a962ec4e361b62fa7e', '197.210.53.89', 1610747013, '__ci_last_regenerate|i:1610747013;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e63ft287uc4j1rk2jg5ja6uh8ii8n6k8', '41.73.1.68', 1602514079, '__ci_last_regenerate|i:1602513759;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e69e7ab6mg3a4fgi67hol97c0hk8l7jh', '41.73.1.75', 1601124360, '__ci_last_regenerate|i:1601124285;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e69ec970d7696082eb6c28db36f121247025314b', '197.210.76.110', 1611144977, '__ci_last_regenerate|i:1611144977;name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"1\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e6d9909485e692ff52b55d62d936b677d56c4f88', '35.203.252.156', 1605018050, '__ci_last_regenerate|i:1605018050;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e71326464e0f58b92c8752df7b67ef47edad09be', '41.73.1.65', 1604680443, '__ci_last_regenerate|i:1604680443;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7321312a087ad32d8cf79e29ec0dade2ccf9254', '41.73.1.66', 1602587846, '__ci_last_regenerate|i:1602587846;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e761f37e3dce017a62feae6ef30ef5f42bbe13b5', '197.210.227.243', 1610546451, '__ci_last_regenerate|i:1610546451;name|s:20:\"ibrahim ahmed kayode\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"20\";loggedin_userid|s:2:\"16\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7acaf38c511ec4317ce13e56f16b98f3a95e711', '197.210.227.133', 1610550868, '__ci_last_regenerate|i:1610550868;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7cab17efef48ab727466a0bafc755a4d2f1301f', '105.112.123.5', 1609576541, '__ci_last_regenerate|i:1609576521;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7ccdcc2e5b3dd60035c2e149dddcfe1d9a02daf', '31.13.103.19', 1603367960, '__ci_last_regenerate|i:1603367960;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e81fa160dfbd545bf020308b58908e3384e2b051', '72.52.238.104', 1611659702, '__ci_last_regenerate|i:1611659702;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e84329ef674bf2c8ee323e797374dd1c8254f333', '31.13.103.3', 1603367960, '__ci_last_regenerate|i:1603367960;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e86a0edc7b419aaa45aaa25492719194276ed8b3', '197.210.71.75', 1610650207, '__ci_last_regenerate|i:1610650207;name|s:23:\"sherifat aliya keshinro\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"16\";loggedin_userid|s:2:\"12\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e86d31c8484a1e5337a005d20eafae0c3d878e3c', '105.112.108.25', 1607621934, '__ci_last_regenerate|i:1607621934;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e87a5aaf7ef995fabf5cbad86fafdfbb79abd25a', '72.52.238.104', 1611659402, '__ci_last_regenerate|i:1611659402;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e8cc0b2f8240980e25037db3d5aa0f24d0a1ff5a', '41.73.1.65', 1604679971, '__ci_last_regenerate|i:1604679971;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e91dfe36596818b61427469280cd82b1adef0368', '66.249.73.230', 1611638849, '__ci_last_regenerate|i:1611638849;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e96d792ca290af9c5c552ada19018efd755b918e', '41.73.1.70', 1609445377, '__ci_last_regenerate|i:1609445377;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e986baf51150a694c911e71e3ff86f689c7f09e6', '197.149.127.196', 1603115039, '__ci_last_regenerate|i:1603115039;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ea045a78377087d9d9bf72c1f146c61c1b1d54de', '197.210.227.133', 1610545648, '__ci_last_regenerate|i:1610545648;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ea54c948064c3a4a2182cd8a1b078b4fac0ee7d7', '62.100.211.135', 1608918222, '__ci_last_regenerate|i:1608918221;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/fees/reminder\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ea68876b20ef9664b78f66e2856d3fe92cbdf908', '105.112.116.250', 1604143508, '__ci_last_regenerate|i:1604143333;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ea79d53ebdc3a80eaaf4764c659bf1a55a3b802d', '197.210.227.133', 1610548346, '__ci_last_regenerate|i:1610548346;name|s:20:\"ibrahim ahmed kayode\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"20\";loggedin_userid|s:2:\"16\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eac229c7cc278b550d98d2681098793757d5402f', '41.73.1.74', 1603119765, '__ci_last_regenerate|i:1603119636;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eadb635b9174a9447e23754412f286dbe7d557e0', '41.73.1.65', 1604673842, '__ci_last_regenerate|i:1604673842;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb207d4c847834986c20e616a4677526e6ccc338', '197.149.127.196', 1608554227, '__ci_last_regenerate|i:1608554225;redirect_url|s:70:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb5449d75a13721742ad6e46ae36b9e347c7d50c', '40.77.167.63', 1609625706, '__ci_last_regenerate|i:1609625706;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb7570ab09d56c0ba455bcf7a483c9e228e55096', '41.73.1.73', 1608551971, '__ci_last_regenerate|i:1608551971;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb7c84fe8bb4ce738f599c665a6760d3a3c8a121', '197.210.227.243', 1610546436, '__ci_last_regenerate|i:1610546436;name|s:21:\"Odachi Cosmas Ejiofor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb89c7898d9ff3537fbc8ebead4e3adf8535f621', '72.52.238.104', 1611659342, '__ci_last_regenerate|i:1611659342;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb9d9694dad017cbc317457ae27abbe6bfba7b5d', '197.210.77.127', 1611059560, '__ci_last_regenerate|i:1611059558;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eba9f107097c6876218715dd42b81d19819ca8e1', '105.112.228.216', 1610576756, '__ci_last_regenerate|i:1610576753;redirect_url|s:46:\"https://admin.acce-abuja.com.ng/portal/profile\";name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebda94fdeb8f84ef168e3678636c98218c9aa8b8', '107.178.239.202', 1604668866, '__ci_last_regenerate|i:1604668866;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebf52f11cf05f5e4cc32ea541a85cb3ad751d613', '41.190.14.105', 1610532080, '__ci_last_regenerate|i:1610532080;redirect_url|s:51:\"http://admin.acce-abuja.com.ng/portal/system_update\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebkc17ubd7athq7mef1c6ie2h5df0oth', '41.73.1.71', 1601378454, '__ci_last_regenerate|i:1601378453;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebmj4e3275tmh6vrvcg60dvlfll7p0kj', '192.99.100.98', 1595514591, '__ci_last_regenerate|i:1595514590;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ec3tvseo8tpojbmj1ip09ji1qlcnbl6c', '41.190.12.86', 1599070531, '__ci_last_regenerate|i:1599070472;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/event/types\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ec52d1cee22d58023efe969b1dc924fd0d925eff', '197.210.227.243', 1610548325, '__ci_last_regenerate|i:1610548325;name|s:21:\"Odachi Cosmas Ejiofor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"8\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ec52efebd6b03bcb40ec3a25e07cd32f0e5208ef', '197.210.46.141', 1603837000, '__ci_last_regenerate|i:1603836825;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ec5ec8878f1cf26564abcdd643e86698278312a9', '72.52.238.104', 1611661502, '__ci_last_regenerate|i:1611661502;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ec7de20f19412ce5b728f796b412a1abf018431e', '72.52.238.104', 1611661622, '__ci_last_regenerate|i:1611661622;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ecc31b3db006dc5af92b18b0792d30f34ca084e2', '197.210.226.134', 1610545943, '__ci_last_regenerate|i:1610545943;name|s:24:\"Oladebo abduljelil taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ecde52cc76d48caa1df6518566ae100c05b2d759', '105.112.123.19', 1603310711, '__ci_last_regenerate|i:1603310711;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ed5ce3c7b74e630bf445296c23808e1bc487e476', '197.210.227.133', 1610546735, '__ci_last_regenerate|i:1610546735;name|s:23:\"Farida Yussuff Avosuahi\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"14\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ed7bae706c7095fc2651cd6f18da86aa983912dd', '72.52.238.104', 1611660121, '__ci_last_regenerate|i:1611660121;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('edb4df46b06db073f3b8ba0be33b27f434ec0d58', '107.178.239.204', 1609497708, '__ci_last_regenerate|i:1609497708;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('edca142e77a3359a15ff0e19f6c50ddf06f9f36e', '41.73.1.73', 1608551670, '__ci_last_regenerate|i:1608551670;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('edcdc5fae8ca10fd0f47fa8f4523bbe794272f16', '197.210.70.215', 1610534280, '__ci_last_regenerate|i:1610534280;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('edd32565d54ffa8e8ff82d4757cc24f0620d52ad', '41.73.1.77', 1610718602, '__ci_last_regenerate|i:1610718602;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ede08569fe60e6ab5a10a9c21224acf9329cd06a', '105.112.112.94', 1610492511, '__ci_last_regenerate|i:1610492511;redirect_url|s:54:\"https://admin.acce-abuja.com.ng/portal/library/request\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ede98d872dd1082a541b37519aca321ad36d6832', '197.210.227.133', 1610546029, '__ci_last_regenerate|i:1610546029;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ee1974f4f006f0199291ce7c0cfb65f5cd42ca1f', '41.73.1.66', 1611655403, '__ci_last_regenerate|i:1611655403;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ee52432ed42b13af0f3ccbf678a191a4ff861b69', '41.73.1.75', 1603718635, '__ci_last_regenerate|i:1603718635;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ee6374622bafb71e4db4e3a180b8f2cd5340bfa6', '72.52.238.104', 1611661502, '__ci_last_regenerate|i:1611661502;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ee7e8fb4f3e814f204ef18272725261dc7d16db5', '72.52.238.104', 1611662821, '__ci_last_regenerate|i:1611662821;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eee14cb89662f7c7933630ffee8df7fb4f2b315d', '197.210.70.215', 1610532979, '__ci_last_regenerate|i:1610532979;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ef0a13e563fa04d8abcc3f49f75b9c89c24f6c16', '41.73.1.65', 1604671098, '__ci_last_regenerate|i:1604671098;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ef8054022212cec94fb6a9b5ae3f654ff684afc4', '41.73.1.74', 1608580064, '__ci_last_regenerate|i:1608580064;redirect_url|s:66:\"https://admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ef8f4c2c4aca68a8641fe8b25d4621fa1b7a424f', '41.73.1.71', 1605543527, '__ci_last_regenerate|i:1605543526;redirect_url|s:54:\"https://admin.acce-abuja.com.ng/portal/dashboard/index\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('efc962b3a967d8ecd4eb6178f1745fb0b0da4b94', '105.112.124.236', 1610783946, '__ci_last_regenerate|i:1610783946;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('efcc865c59eb86ec05f87954cfbc9403d103c9e1', '72.52.238.104', 1611663661, '__ci_last_regenerate|i:1611663661;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('efe2bb244c01e6094428a8140cba4571200cdc9f', '197.210.77.99', 1611063429, '__ci_last_regenerate|i:1611063429;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('egn3nn1vogbu32k5gk0eqhlfre9i42q3', '41.73.1.68', 1594913262, '__ci_last_regenerate|i:1594913196;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eh1u28odmnn53rs7k2emmdg6p4ra19fu', '41.190.12.220', 1594818042, '__ci_last_regenerate|i:1594817749;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('en9nffcaacv76vogr9jkmk6aaljrj3ap', '41.73.1.72', 1602166503, '__ci_last_regenerate|i:1602166457;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('epi3giq547q7ugqib6mi0c6qdj8fnacn', '41.73.1.66', 1602163017, '__ci_last_regenerate|i:1602162724;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eq9p03hp98qaof3v1q1hcmv23jgm2gs2', '37.170.83.176', 1597171097, '__ci_last_regenerate|i:1597171097;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eqgh1e4sangs9i4nor2dd5mr9ats709a', '41.190.12.66', 1595375689, '__ci_last_regenerate|i:1595375389;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f024c0ce641f514b07e5112204723e3d2b7ea647', '72.52.238.104', 1611658982, '__ci_last_regenerate|i:1611658982;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f032d5ce4705c8c84906a964019d1830579d7ece', '41.73.1.69', 1610715015, '__ci_last_regenerate|i:1610715015;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f04d9ee176d623aecd1d6422d4aa8d677b905da3', '197.210.71.74', 1603961333, '__ci_last_regenerate|i:1603961333;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f09bf0c8fceec7041e2e2ded5c7243c8919cd39a', '72.52.238.104', 1611660541, '__ci_last_regenerate|i:1611660541;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f09c9f1e8232c9c9d807e3eb7c14265f08df4c48', '197.210.55.86', 1610622192, '__ci_last_regenerate|i:1610622185;name|s:23:\"sherifat aliya keshinro\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"16\";loggedin_userid|s:2:\"12\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0db4381d584c91ac6923c81035b5e8da3c15fb0', '105.112.112.250', 1610543381, '__ci_last_regenerate|i:1610543381;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0f10dac96add9b500ca65ed75c63c35a0c86f56', '197.210.227.22', 1610568425, '__ci_last_regenerate|i:1610568425;name|s:23:\"Yusuf Muhyideen Abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f12d7e1c742f948c542244a85b71775f3d33a7da', '105.112.116.199', 1610722086, '__ci_last_regenerate|i:1610722086;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f13abab448de83d2a608762f46a8d13818147b9b', '197.211.53.132', 1603621100, '__ci_last_regenerate|i:1603621099;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f144809b8a7071234146d3b173c1f12048bff9e7', '41.73.1.66', 1607591697, '__ci_last_regenerate|i:1607591697;redirect_url|s:42:\"http://admin.acce-abuja.com.ng/portal/role\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f1d6915648f1359c6bd01646196d5ef9ee3ec3d7', '41.73.1.65', 1604670682, '__ci_last_regenerate|i:1604670682;name|s:28:\"Dr. Mohammad Kyari Dikwa mni\";logger_photo|s:36:\"bc7ea18eba0efea4df0ea9f469120f1c.jpg\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"9\";loggedin_userid|s:1:\"6\";loggedin_role_id|s:1:\"9\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f1f656e4974c15b6ca4764e75fa3e39cbc51d06a', '197.210.226.134', 1610545846, '__ci_last_regenerate|i:1610545846;name|s:23:\"yusuf muhyideen abolaji\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"18\";loggedin_userid|s:2:\"14\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f20dcaf8c4661813b96e47314aa81f4f3e9d0583', '197.210.71.74', 1610534633, '__ci_last_regenerate|i:1610534633;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f28126325bbbe156351f49f1485691486708fdd7', '197.210.227.243', 1610547733, '__ci_last_regenerate|i:1610547733;name|s:25:\"Odunola bashirat temitope\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"19\";loggedin_userid|s:2:\"15\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f292d2d48c41fbd24a95a2483051fba7a3746666', '197.210.227.133', 1610546698, '__ci_last_regenerate|i:1610546698;name|s:31:\"emuejeraye mefogune okponafagha\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"17\";loggedin_userid|s:2:\"13\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f29fa63aaf46c9a0a22009e06a920a35397e1dd8', '41.73.1.66', 1611315612, '__ci_last_regenerate|i:1611315597;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f32c6c547b237a5c79764daab29cdb427aa3cbc0', '72.52.238.104', 1611663603, '__ci_last_regenerate|i:1611663603;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f33a085af1ec92b5e147d16a0370f94b466bb78b', '197.210.226.134', 1610548360, '__ci_last_regenerate|i:1610548350;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3472630ab3356e5dd20e0fa96c943340113395e', '197.210.227.133', 1610547875, '__ci_last_regenerate|i:1610547875;name|s:29:\"Abdulkadir rafiyat Abduljelil\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"15\";loggedin_userid|s:2:\"11\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f34a9cd8e98438ca2a9d0c0c7cda88b82262eefd', '41.73.1.77', 1610718819, '__ci_last_regenerate|i:1610718819;name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3db8ce8d954a873fc2fdc55150d5072cd8233df', '41.73.1.65', 1603969879, '__ci_last_regenerate|i:1603969879;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3f3cf27fe8a3524841f40d6d6016d3600431b6b', '72.52.238.104', 1611661142, '__ci_last_regenerate|i:1611661142;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3f832faf0bbd9a60c5310f1701d274c303abc35', '105.112.76.188', 1609611754, '__ci_last_regenerate|i:1609611753;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3fea61d380113b4e4c762f8e8010a8349f0c588', '41.73.1.67', 1610670257, '__ci_last_regenerate|i:1610670257;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f406b2e24e8808a1b658a3d91b18d0e55f71441b', '197.210.76.25', 1603979998, '__ci_last_regenerate|i:1603979998;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f43e88f4cbf508fb41636f9e5a9ffba61bca5cb7', '41.73.1.74', 1603453517, '__ci_last_regenerate|i:1603453517;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f460f97bc9ffb381fbd38a8c4ec50aab7d946cf1', '41.73.1.65', 1604680969, '__ci_last_regenerate|i:1604680931;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f4ba703ac3d4ac51c7be75f8eff8a2030ae0c7b8', '66.249.72.136', 1607513492, '__ci_last_regenerate|i:1607513492;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f4d5689fa1e7133a9994e3bfe00a715622eee53c', '197.211.53.132', 1603313759, '__ci_last_regenerate|i:1603313759;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f500f18c8883beee5a553a604c161f404c4b18bf', '197.210.70.56', 1610742994, '__ci_last_regenerate|i:1610742994;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f5f72e3eb29019d200134a781f4080562cc44f71', '105.112.121.109', 1610536510, '__ci_last_regenerate|i:1610536510;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f5iard9s7o9h4oii2js530pknj6qdvgb', '41.73.1.72', 1602167914, '__ci_last_regenerate|i:1602167819;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f622df6bd8bbc115fbdc35b85b8eda3759c6f4ec', '105.112.113.111', 1610912825, '__ci_last_regenerate|i:1610912824;name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6381bf37b8a37d24bb63a3bbb5dca7f15e1d025', '41.73.1.70', 1604157414, '__ci_last_regenerate|i:1604157414;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6a160215f4a779116860d29fd13e1beda104acc', '197.210.71.173', 1610967717, '__ci_last_regenerate|i:1610967445;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:23:\"muhammad muhammad nasir\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"22\";loggedin_userid|s:2:\"18\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6a877766111f8a0b3873e27c734771163a53e03', '41.190.14.195', 1610540045, '__ci_last_regenerate|i:1610540045;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6db6a36f2b1d65be248f7cf5b323f9c89608dcd', '13.66.139.26', 1610724195, '__ci_last_regenerate|i:1610724195;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f773d3c8c359d16884d9ab6d62805f5ffe10dfd2', '129.205.113.196', 1610545233, '__ci_last_regenerate|i:1610545233;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f7c2083ed8a471fae8e160d5f7f80b92672f1646', '197.210.53.58', 1610748890, '__ci_last_regenerate|i:1610748890;name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f7fed5738742a2373072a1099b3dfc391483e65c', '41.73.1.69', 1610716483, '__ci_last_regenerate|i:1610716483;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f81066df0520f0606a54c4118d6f83bc5127c16e', '72.52.238.104', 1611658982, '__ci_last_regenerate|i:1611658982;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f85169fa9a4f5d95ab6d4a913265eba4b6af950b', '41.73.1.75', 1603197179, '__ci_last_regenerate|i:1603197179;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f85fq2lmbhovol9fnvuga1tl8pd1on6r', '105.112.116.25', 1600270538, '__ci_last_regenerate|i:1600270376;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f8b2a5fd5a362d2af802bcd361e0bd8fe8163054', '54.36.148.227', 1608238544, '__ci_last_regenerate|i:1608238544;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f91a3280f4552120c8b7c043b1c65ab489cce299', '102.89.0.86', 1610743569, '__ci_last_regenerate|i:1610743569;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f9366385615d48cb9eed01018b4a493ff716140a', '72.52.238.104', 1611661921, '__ci_last_regenerate|i:1611661921;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f96bdc281f0e6dcee1f5f95b4ba25c8f774f5162', '5.194.200.160', 1611403962, '__ci_last_regenerate|i:1611403866;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f977d8cde70e68d419173ef8593c70fcf6483f68', '72.52.238.104', 1611660841, '__ci_last_regenerate|i:1611660841;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f9be2b129a98630fc4e1b33438768360b5519326', '105.112.112.94', 1610493436, '__ci_last_regenerate|i:1610493436;redirect_url|s:54:\"https://admin.acce-abuja.com.ng/portal/library/request\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa035eacdd38e1e7886bbd4af03ffe5cc76fbd27', '197.211.53.132', 1604342539, '__ci_last_regenerate|i:1604342539;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa81d61bb63512fee468d6d1ba6030c34ae575da', '105.112.112.62', 1610456415, '__ci_last_regenerate|i:1610456415;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fac43d46be5bf407586f761e8b279519ffe92376', '35.203.252.113', 1606899977, '__ci_last_regenerate|i:1606899977;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('faf6ce7cf9a7e9a97f26a3105bffcdb857c61f68', '107.178.239.202', 1604668866, '__ci_last_regenerate|i:1604668866;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fb35972nh9jtd1a3629lnqhfqkv2uuj1', '41.190.14.129', 1594894494, '__ci_last_regenerate|i:1594894494;redirect_url|s:58:\"https://www.admin.acce-abuja.com.ng/portal/dashboard/index\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fb38bbeefb096fe4ae00e4dc853cf6f6c89f044e', '197.210.55.86', 1610617491, '__ci_last_regenerate|i:1610617491;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fb4f61405e3bffd27017d46b4fc9eb9ab3c2f4bf', '31.13.103.7', 1603369624, '__ci_last_regenerate|i:1603369624;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fb723a27b3242498a7dba11ec9fab053c4049444', '41.73.1.67', 1610673445, '__ci_last_regenerate|i:1610673445;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fb84e2807a36d2abdeac58b8ae16f535484d8ead', '41.73.1.66', 1602589967, '__ci_last_regenerate|i:1602589967;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbb91d707d8cb9b0c26c7adca6f6d44937cd7499', '197.210.71.57', 1610754980, '__ci_last_regenerate|i:1610754931;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:13:\"mukhtar asiya\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"23\";loggedin_userid|s:2:\"19\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbffd8eab0d58ca117f4120628b3739b862a8849', '72.52.238.104', 1611663542, '__ci_last_regenerate|i:1611663542;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbh2ddrqgh58id5usr3avd6mlhak0a84', '94.20.252.68', 1601369917, '__ci_last_regenerate|i:1601369900;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fc0788c75426023083691279ac5705843345f567', '72.52.238.104', 1611659642, '__ci_last_regenerate|i:1611659642;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fc1ef721bcf555da8f42d1e84b05028c9bac4707', '35.203.252.148', 1610410926, '__ci_last_regenerate|i:1610410926;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fc26d8e892516ff1a6b541f300eea3153bf9e1e4', '197.210.227.133', 1610548596, '__ci_last_regenerate|i:1610548596;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fc5023788bed1c0027e8f2edec7e6c7963dbad52', '197.210.52.171', 1610539116, '__ci_last_regenerate|i:1610539116;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fc7819a6ada16489f8fd9b5138c53399e8fc3156', '72.52.238.104', 1611662102, '__ci_last_regenerate|i:1611662102;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fc8a29a193cc76ec168343b9978a00bcbb785c0d', '197.210.53.148', 1606857928, '__ci_last_regenerate|i:1606857928;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fd0b0170ecf53b7c6e03b13fd0b3b514fbbbb137', '41.73.1.65', 1603971311, '__ci_last_regenerate|i:1603971311;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fd2f88a4fa56906c254711031e002932c8822ae3', '72.52.238.104', 1611659821, '__ci_last_regenerate|i:1611659821;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fd46843390e5aa715f83acd75b6d222588c9d23d', '41.73.1.65', 1604670472, '__ci_last_regenerate|i:1604670472;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fd54523311e268f51c49e6a4c851799668ca2d12', '105.112.121.109', 1610529872, '__ci_last_regenerate|i:1610529872;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fd669f92a0d8ec91f512bb8af04e8f983ca983cb', '105.112.121.109', 1610530583, '__ci_last_regenerate|i:1610530583;redirect_url|s:48:\"https://admin.acce-abuja.com.ng/portal/dashboard\";name|s:12:\"Alfaky Bello\";logger_photo|s:36:\"d2716a265b93ba536f2cc3bf9a176141.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fdf79f52dfd90e6f555b70917e3a1e3940d7d149', '197.210.71.57', 1610754637, '__ci_last_regenerate|i:1610754637;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fe1be74d68b9ac42e22eb8665bf0d7b93843dcff', '197.210.226.134', 1610546115, '__ci_last_regenerate|i:1610546115;name|s:21:\"Nwosu Osinachi Victor\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"13\";loggedin_userid|s:1:\"9\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fe9f606e57d1d88119a37993a1410b97f26724a9', '105.112.120.85', 1610556558, '__ci_last_regenerate|i:1610556558;name|s:24:\"Oladebo Abduljelil Taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('feb8ef7825154aa8419a76ca0b9cf9f4f165dac4', '197.210.227.243', 1610546667, '__ci_last_regenerate|i:1610546667;name|s:24:\"Oladebo abduljelil taiwo\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"21\";loggedin_userid|s:2:\"17\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('febea4eacff7525fce06cf8870f6f98ce3e8315d', '72.52.238.104', 1611660903, '__ci_last_regenerate|i:1611660903;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fec927baa8438bcb858122ec8f8708411c2b9b9f', '197.210.70.215', 1610530982, '__ci_last_regenerate|i:1610530982;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ff2cbf2f8ec89a0b00ecc119a39b7efa44357373', '41.190.14.195', 1610540349, '__ci_last_regenerate|i:1610540349;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ff579051928e210861b8f9e4c7e175888fef8c1a', '197.210.226.134', 1610555789, '__ci_last_regenerate|i:1610555789;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ff62445692d8458f3fa1260c0eb995898c9e79b9', '197.210.227.133', 1610547369, '__ci_last_regenerate|i:1610547369;name|s:22:\"Maryam Magaji Muhammad\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"7\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ff76cfcb3ef98346260de36175665d551f9a957c', '41.73.1.66', 1611657561, '__ci_last_regenerate|i:1611657561;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ff9bdbde589e03a7a9b01ed1805c7713a8cefbd1', '72.52.238.104', 1611662821, '__ci_last_regenerate|i:1611662821;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ff9c5233286e378609ffcd62090df688ebaa073c', '105.112.112.138', 1603355484, '__ci_last_regenerate|i:1603355483;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ffda07d7042bca2ec8c053091605a33292476e40', '41.73.1.74', 1603115350, '__ci_last_regenerate|i:1603115350;redirect_url|s:69:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/read\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ffe32a3aded1b6ee332dfffa248c2fad9236e52f', '41.73.1.65', 1604682070, '__ci_last_regenerate|i:1604682069;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fk5s4g76rvq4iu8vhhupi77caatc8pfj', '41.73.1.71', 1601385906, '__ci_last_regenerate|i:1601385651;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fkhkkj1vm5rms3pl3hb2g0a9drmtg9hk', '41.73.1.66', 1602156481, '__ci_last_regenerate|i:1602156480;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fr2filfaqjaf06fblhjj6fn4b9ncu2ua', '41.190.14.129', 1594897481, '__ci_last_regenerate|i:1594897479;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('frms6t4foud4erru365m9t2mk5jbc7pp', '41.190.14.178', 1597163820, '__ci_last_regenerate|i:1597163819;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fsq6jh8khttep8baj4ctifmuv1nqhjk0', '105.112.117.208', 1601299748, '__ci_last_regenerate|i:1601299719;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g0j4qlu3gb7oesi9j46dbha2emb5n2of', '41.73.1.75', 1601980931, '__ci_last_regenerate|i:1601980645;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g6ji0psrbftrpqgvsvbhi2mlll7mqj2v', '41.73.1.71', 1601384797, '__ci_last_regenerate|i:1601382863;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gfl2h9ffivn2if5e5n2mo5j47utg26l4', '41.73.1.71', 1601378455, '__ci_last_regenerate|i:1601378453;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ghfkhkne2nefm2hq064eu3bodbm9uiq7', '41.73.1.75', 1595860958, '__ci_last_regenerate|i:1595860955;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gla9grt2u4vqo8r0pa9mtinkcip0htm0', '41.190.14.51', 1595188737, '__ci_last_regenerate|i:1595188650;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gmol1vhr390r5tutcsj5kqv2v6fgvbaf', '41.190.12.93', 1594822623, '__ci_last_regenerate|i:1594822622;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('go4cj5hdo45296gqsg6cm1lfo6vaarbb', '129.56.37.209', 1599123968, '__ci_last_regenerate|i:1599123967;redirect_url|s:50:\"http://admin.acce-abuja.com.ng/portal/homework/add\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gr202uh21rksvrhn0vui0jn2on4gherb', '197.149.127.196', 1602152631, '__ci_last_regenerate|i:1602152629;redirect_url|s:56:\"https://www.admin.acce-abuja.com.ng/portal/system_update\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h07inbe01otmajru1jopqanlo2a8osge', '41.73.1.68', 1594909153, '__ci_last_regenerate|i:1594908984;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h0nrti5jbf717qkhc1ge9sh87d5khlor', '193.212.4.37', 1601370719, '__ci_last_regenerate|i:1601370716;redirect_url|s:53:\"https://www.admin.acce-abuja.com.ng/portal/accounting\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h253rms3d9t5urkdkbri14doaiqia45j', '41.73.1.75', 1595854976, '__ci_last_regenerate|i:1595854974;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h82h4tjj77kf0ibv03cds1ucipoqavda', '41.190.14.129', 1594894570, '__ci_last_regenerate|i:1594894494;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hbbelsq5irdqsbusjii133glfct1c005', '41.73.1.68', 1594911387, '__ci_last_regenerate|i:1594911086;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('he0c1e14ago5npuh9rtacquoctgsptme', '35.203.245.180', 1601688884, '__ci_last_regenerate|i:1601688884;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('he2r2j8nljlsgepmh5mhd9d3da1vjpli', '105.112.114.93', 1600185556, '__ci_last_regenerate|i:1600185287;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hedchcmnofm4jc5mtvbrnnkn8h2evhtv', '41.190.14.149', 1599057730, '__ci_last_regenerate|i:1599057730;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('heme8j2gmcm97cfkvr1lphee08jfrl7a', '41.190.14.105', 1594838325, '__ci_last_regenerate|i:1594838325;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hev3r3sjijlcoimda21ri1qbeblidrgc', '41.73.1.75', 1601123559, '__ci_last_regenerate|i:1601123404;redirect_url|s:65:\"http://admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hkkv35t33qvrfpgaqt9la6rn50nkbp4f', '41.190.14.129', 1594895483, '__ci_last_regenerate|i:1594895191;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hq3d2e7gu3rq9erdkfe2lcpta8nf81ss', '41.73.1.75', 1601891189, '__ci_last_regenerate|i:1601890811;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hq6ldvhv57b5894v99rr5k0pilkq7mqc', '197.210.52.172', 1595514363, '__ci_last_regenerate|i:1595514259;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hq6ppo7fe8etgkjrs37tflp9pvdv1a0t', '129.56.61.207', 1597220531, '__ci_last_regenerate|i:1597220233;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hv1qhpi50uje7e15en78eot18ggf6ef8', '59.179.18.6', 1601369761, '__ci_last_regenerate|i:1601369757;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i07cg26im5hm3313lbqp1nrho20mr93t', '66.102.9.83', 1601378574, '__ci_last_regenerate|i:1601378566;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i2vas3mgiet6q5u3jn5raeutdikqhas8', '41.190.12.66', 1595378804, '__ci_last_regenerate|i:1595378780;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i9rsb5ntkmthcgc7e9depd29dfll6hog', '105.112.121.55', 1602498186, '__ci_last_regenerate|i:1602498186;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ie0qv0c84jqtv5ogouldm4rgupkog0rc', '41.190.14.129', 1594893119, '__ci_last_regenerate|i:1594893092;redirect_url|s:58:\"https://www.admin.acce-abuja.com.ng/portal/dashboard/index\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iehrj3894agteaagkg0vphvk3kes6amo', '41.73.1.75', 1601982329, '__ci_last_regenerate|i:1601981961;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ikiqtsvophh0r79sfob9i1c86lg3v5d3', '66.102.9.79', 1601378582, '__ci_last_regenerate|i:1601378575;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('il6e967hplfvgvr67fuia95snisl0iim', '197.149.127.197', 1602502795, '__ci_last_regenerate|i:1602502792;redirect_url|s:62:\"https://www.admin.acce-abuja.com.ng/portal/timetable/viewclass\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ing89pot6r61guu5m21ptcqe0rta1aoe', '41.73.1.75', 1601983826, '__ci_last_regenerate|i:1601983104;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iu24ejiteekfuauu9mfpapig0e9vcgd9', '41.73.1.65', 1601217048, '__ci_last_regenerate|i:1601217048;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j02l1t3k79l736vo907nr374d47ci56k', '105.112.113.10', 1600779635, '__ci_last_regenerate|i:1600779635;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jbpjg3hd7ig7du7ua4dv2gqc31f7nv2f', '41.73.1.71', 1601382079, '__ci_last_regenerate|i:1601381893;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jbs46q30179gtkcgugb1t3bb5bi3jckn', '41.190.14.129', 1594895165, '__ci_last_regenerate|i:1594894882;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jc3jd8fta0hu2dad4c3b7onj6q2ajjuk', '41.73.1.71', 1601378454, '__ci_last_regenerate|i:1601378452;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jd0i6kt96bnpq5eios4fnhu7n1efchgn', '41.73.1.71', 1601376203, '__ci_last_regenerate|i:1601376197;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jdg9fjb0h8qn29i6igsb11n436vi9oet', '41.190.14.117', 1599059682, '__ci_last_regenerate|i:1599059682;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jhqc4vkqci00ovg7ct5m532ojrvfci9n', '41.73.1.76', 1595946759, '__ci_last_regenerate|i:1595946759;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ji582ff15dle9ui377f3s2hrfu7haamb', '41.73.1.71', 1601370715, '__ci_last_regenerate|i:1601370689;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jtgohtsvgib7hrmhgfro0bp1po4d8t9i', '105.112.121.55', 1602498185, '__ci_last_regenerate|i:1602497885;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k24ms0nrmea597cm4vl2tiqhuoglvcqs', '41.73.1.68', 1594907218, '__ci_last_regenerate|i:1594906871;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k51mbi71gti748b8lk0u7o2cq8vgg205', '41.73.1.71', 1601382863, '__ci_last_regenerate|i:1601382256;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k9jpshjbiog3s7319a09qmjoebsn3rq0', '41.73.1.68', 1601467919, '__ci_last_regenerate|i:1601466178;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k9meqdscjcfbgp79di0e009m1mjlgdba', '41.73.1.71', 1601380904, '__ci_last_regenerate|i:1601380573;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kp5qn2e6jpbvm6s5hfo19l0aa7629u5d', '35.203.245.180', 1601688885, '__ci_last_regenerate|i:1601688885;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l02badn1495odt6fmtvtorpeq8tabrr2', '41.73.1.75', 1595857506, '__ci_last_regenerate|i:1595857144;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l04q928tcm6e3aa5tocapmvm50u4vi35', '91.106.51.5', 1595853832, '__ci_last_regenerate|i:1595853828;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l0k1h0rj23043to5qi0ee5oslqc3a3ns', '197.149.127.197', 1601980112, '__ci_last_regenerate|i:1601980110;redirect_url|s:61:\"https://www.admin.acce-abuja.com.ng/portal/settings/universal\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l12cpb32dpfo76lg6e4je70jghbtt5br', '41.73.1.75', 1601893506, '__ci_last_regenerate|i:1601893327;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l5fag8v0aglsiqq9fp80io5tgakvdmlb', '209.143.6.230', 1596032618, '__ci_last_regenerate|i:1596032617;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l8qlqecs9o4clesjlt85ml04296pmfi1', '41.73.1.68', 1594909596, '__ci_last_regenerate|i:1594909334;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lcijgag4oqpo0cjocmdd0ifid5srqudu', '41.73.1.71', 1601377227, '__ci_last_regenerate|i:1601377227;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lf57gh4549qlcbvbu7ok3tjooa5rsqm2', '41.73.1.68', 1594913316, '__ci_last_regenerate|i:1594913145;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lhva546lk6uq2m411mkdjlh7m6s4v478', '41.73.1.75', 1601979934, '__ci_last_regenerate|i:1601978892;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lidpce10i9h4l0rv4pnkvomc3q1eur4d', '107.178.238.52', 1602006859, '__ci_last_regenerate|i:1602006859;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lijc0bevqnb885imt1cte26iligrpcba', '41.73.1.68', 1594914230, '__ci_last_regenerate|i:1594914072;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lkr3ju0708hoc9bnjcqdtkpmrsmf1hoa', '41.190.12.93', 1594823314, '__ci_last_regenerate|i:1594823029;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ll97bqkqcv8n68vtanml7u1q3er93319', '129.56.34.205', 1599000740, '__ci_last_regenerate|i:1599000735;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/event/types\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lmlbdmipgugl0oo0j4holi0od6ofughi', '41.73.1.66', 1602579993, '__ci_last_regenerate|i:1602579991;redirect_url|s:53:\"https://www.admin.acce-abuja.com.ng/portal/accounting\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lo4ei7r7lk2t6plg8kugqhuv4slvnsln', '41.73.1.75', 1601114533, '__ci_last_regenerate|i:1601114361;redirect_url|s:64:\"http://admin.acce-abuja.com.ng/portal/sendsmsmail/template/email\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ltaksh9bhfon3srgd0lrntomc7d1jfdh', '41.73.1.68', 1594907650, '__ci_last_regenerate|i:1594907522;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m048bpdn336pshhk5oh360dvphudfkhc', '41.190.12.229', 1595179567, '__ci_last_regenerate|i:1595179563;redirect_url|s:69:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/sent\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m38hrhekink2lpa7ildmn3e7iih1gfo2', '41.73.1.76', 1596031575, '__ci_last_regenerate|i:1596031289;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m6eogo7964d89iktvrvt1q26fde08193', '41.190.14.19', 1600405464, '__ci_last_regenerate|i:1600405400;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m6iur5jg5t64j100v4d3013g5jig4dp0', '41.73.1.68', 1594913685, '__ci_last_regenerate|i:1594913626;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mbd5qnb66t7skcvh08l7f3rq77pc85ii', '41.73.1.68', 1594911673, '__ci_last_regenerate|i:1594911388;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mcmid8g6u6qveoenrqe1li3slkdu9bqk', '105.112.121.55', 1602503940, '__ci_last_regenerate|i:1602503940;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mf779sqkn88v9nbrg0efs1qcmpnt4ies', '41.73.1.66', 1602156480, '__ci_last_regenerate|i:1602155952;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mhesmepcoohjljoc2b0hshrsnsnq6oo2', '41.73.1.75', 1601977114, '__ci_last_regenerate|i:1601977070;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mj0i4umvii1lvb4pt267b7mph481o04l', '41.73.1.75', 1595860095, '__ci_last_regenerate|i:1595858648;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mli7hij5vqeb9r8m3ksb60uf6pchh0c4', '41.190.14.51', 1595185680, '__ci_last_regenerate|i:1595185672;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mp9vb4eobnb66jp4hjtq93cve02dk15f', '41.73.1.71', 1601378456, '__ci_last_regenerate|i:1601378454;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mt34c05kcvbbq2l0dgn7lim9o2bh8amn', '41.73.1.72', 1602166057, '__ci_last_regenerate|i:1602165329;name|s:16:\"Abdulmalik Kyari\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"6\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"6\";loggedin_type|s:6:\"parent\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;myChildren_id|s:1:\"2\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mto7hqd2i4827fbbemnbeb5atdfn2870', '105.112.114.93', 1600181135, '__ci_last_regenerate|i:1600181134;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mu1fs0intve6tt9un25es2v561hb663r', '41.190.14.105', 1594835515, '__ci_last_regenerate|i:1594835514;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mui8rb54rviat6jkfsqfl9203k4gnt7a', '37.170.83.176', 1597171097, '__ci_last_regenerate|i:1597171097;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n091gpb78sqs7se948tpq86ga0e1m28s', '41.190.12.220', 1594818660, '__ci_last_regenerate|i:1594818370;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nf0hi3bklh4o4vf3pbb551pgmfl67opn', '41.190.14.117', 1599060532, '__ci_last_regenerate|i:1599060532;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ngkundmtvgssn727m2skur253vtqh6f6', '41.73.1.75', 1597491264, '__ci_last_regenerate|i:1597491263;redirect_url|s:54:\"https://www.admin.acce-abuja.com.ng/portal/student/add\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nju1lc8890npi4b1br1psbu1ngo23j9a', '196.49.26.134', 1602155364, '__ci_last_regenerate|i:1602155336;redirect_url|s:53:\"https://www.admin.acce-abuja.com.ng/portal/live_class\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nmf6jpvtr3nrapq1mtolvbkq01iot5tb', '35.203.245.120', 1602327153, '__ci_last_regenerate|i:1602327153;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o3448mldct6cmeaer73kmm5nioefpksg', '41.73.1.71', 1601380564, '__ci_last_regenerate|i:1601380264;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o48c907on0dsbvi1qfd23kr6rumanre5', '41.73.1.71', 1601380263, '__ci_last_regenerate|i:1601379963;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o8cjdrn8oj5hbib173qm6tv9coq0qpvr', '41.190.12.83', 1598155969, '__ci_last_regenerate|i:1598155721;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oai9lncbi6fpp2a8h8ose4mj7hmq07r6', '41.190.12.229', 1595180491, '__ci_last_regenerate|i:1595180454;redirect_url|s:52:\"https://www.admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oapb7u4hf6aqlsni98vb9600fvtl735h', '41.73.1.66', 1602158878, '__ci_last_regenerate|i:1602158338;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oc1ttq142u3o26g7qkvocfokdqcsljmi', '41.190.12.220', 1594819994, '__ci_last_regenerate|i:1594819994;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('octdudk1qmkotbq7d7gpsc1p4f7ad00c', '41.73.1.68', 1602514719, '__ci_last_regenerate|i:1602514403;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ofmbfdmviapu5bmg2ckraksdcui9icuq', '41.73.1.68', 1601469247, '__ci_last_regenerate|i:1601468542;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oi7pjot6c8lqcg9ga2unjvcngmtmmli9', '41.190.12.93', 1594824066, '__ci_last_regenerate|i:1594823771;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ol8aru7l89ilngf2il41ub6e9cbahmsr', '41.190.14.105', 1594834038, '__ci_last_regenerate|i:1594833831;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oojd35jtjg8nns2gt67h8fm49sk6of1b', '41.73.1.66', 1602161809, '__ci_last_regenerate|i:1602161809;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oq8bnrpa9397mtrlqtphjneg6rbtqqrr', '41.190.12.93', 1594822893, '__ci_last_regenerate|i:1594822623;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('os2dlcpurvq9f3nddqenre10f2jlsqhm', '41.73.1.75', 1601985738, '__ci_last_regenerate|i:1601984728;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ouhgkq4sek4i5p1n2798n168e9am2i9m', '41.190.12.66', 1595377052, '__ci_last_regenerate|i:1595376838;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ovplcdhl3bberuu74s0a9jubntgjq7mk', '105.112.112.224', 1601325273, '__ci_last_regenerate|i:1601325081;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p09jo2i9kmo4cfk0r0gvn13v5dvkne9c', '41.73.1.66', 1602151990, '__ci_last_regenerate|i:1602151699;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p2s0tcnnrlea00mhcf4evrdlrdsme1gn', '41.190.12.227', 1601301294, '__ci_last_regenerate|i:1601301179;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p3jncncuk7o2qg01p0mjh02e4hqmal15', '41.73.1.75', 1601986220, '__ci_last_regenerate|i:1601985739;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pa3319oa016ecc6k1o8jse2nvdo62n0h', '41.73.1.68', 1594905568, '__ci_last_regenerate|i:1594905566;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pe1lva8v9igj4g2cqlqab812pqkv09s5', '41.190.12.93', 1594824461, '__ci_last_regenerate|i:1594824170;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('phsm3dt0uc0hhp373pup87afj4jd53to', '41.73.1.75', 1595426131, '__ci_last_regenerate|i:1595426072;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pi6qn5or21e0bhascfutiusd41plm8og', '41.190.14.129', 1594897052, '__ci_last_regenerate|i:1594897017;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pjfm6qdldq0ssgiprv3ttc3j9undkkp9', '197.242.125.206', 1595913323, '__ci_last_regenerate|i:1595913322;redirect_url|s:50:\"http://admin.acce-abuja.com.ng/portal/parents/view\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pl3av365laquesfm63jtmgqek7odelu7', '41.73.1.68', 1602514719, '__ci_last_regenerate|i:1602514719;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('prc70o7tpn34f98bno5kdcqhsfo50d3t', '105.112.121.55', 1602503595, '__ci_last_regenerate|i:1602503280;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q2sthcj8rpgi79fmfuer4e21utt0k1d7', '41.190.12.248', 1594918579, '__ci_last_regenerate|i:1594918579;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q35n1cu79ldln5jee670hp2nunc3cjdk', '41.190.12.66', 1595375336, '__ci_last_regenerate|i:1595375045;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q98t5ro5d4sk33hmhf4o0fvborocudre', '196.49.26.134', 1602152472, '__ci_last_regenerate|i:1602152450;redirect_url|s:56:\"https://www.admin.acce-abuja.com.ng/portal/system_update\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q9nfcd0k30ev3kr787ivu7c1i9cgk8jb', '41.73.1.68', 1601469531, '__ci_last_regenerate|i:1601469247;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q9sffvdocrl6t9kdfh6a1ueovmjc6ec6', '41.190.14.202', 1599071337, '__ci_last_regenerate|i:1599071037;redirect_url|s:49:\"http://admin.acce-abuja.com.ng/portal/event/types\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qen5jkgacpdmc2l7b3pv74c0nnsb2adn', '41.73.1.75', 1601895855, '__ci_last_regenerate|i:1601894215;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qevhvi1rcuq3ulika6eu37dnbd1nmt9f', '41.73.1.68', 1594914058, '__ci_last_regenerate|i:1594914031;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qicm60sgq8j1uu974cd7rign3fc8g2jt', '41.73.1.75', 1601980191, '__ci_last_regenerate|i:1601979936;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qkc8qrmgvtbasa3qekev3frg20i8e8a6', '197.210.52.172', 1595515714, '__ci_last_regenerate|i:1595515483;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qmtfffeta47o3i3pjo83s8ibofnnmh4a', '41.73.1.71', 1601370063, '__ci_last_regenerate|i:1601369890;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpq8aqtlsfc98btvp8db93eqp1f0vtdr', '41.73.1.71', 1601372602, '__ci_last_regenerate|i:1601372543;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qsfh4otpdt5ltb8m4n4i4dj9mqec6saj', '41.73.1.68', 1601468516, '__ci_last_regenerate|i:1601468220;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qughhv55snbra8s4k9q9e7e2g82r4nmo', '41.190.14.149', 1599062800, '__ci_last_regenerate|i:1599062800;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r0g5dv0hr8104hu1b9hhmqcs86oddhke', '41.190.14.178', 1597163760, '__ci_last_regenerate|i:1597163756;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r3uh1qqho6q0rfqu4oiuf50t6brvjpuo', '105.112.114.93', 1600177612, '__ci_last_regenerate|i:1600177611;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r5425u8034rmnpo5fpmomvbbm8u4jorp', '41.73.1.68', 1594912151, '__ci_last_regenerate|i:1594912001;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rb5tb4gh45j0gne4gg9gbler0sj480p2', '5.186.12.38', 1601380086, '__ci_last_regenerate|i:1601380085;redirect_url|s:50:\"https://www.admin.acce-abuja.com.ng/portal/classes\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rbts9ivm2k11s2sf5urk4nf2b5bo7j6f', '41.73.1.71', 1601376198, '__ci_last_regenerate|i:1601376196;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rgpk6ttgu7944q9r317ieonmoc4aioiu', '41.190.12.83', 1598155598, '__ci_last_regenerate|i:1598155381;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rimo9ovm529otj0bgg1sdutr6tn5f4ls', '41.73.1.68', 1594913652, '__ci_last_regenerate|i:1594913652;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rkghvs6o7ci6mqhd7223fbasck9a72ft', '35.203.245.120', 1602327155, '__ci_last_regenerate|i:1602327154;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s2l7b0vrj1vk6j1nrec5g15g12gs8jha', '41.73.1.68', 1594912918, '__ci_last_regenerate|i:1594912757;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s3p75mehaas683oj5v57oj2j87f61fnp', '41.190.14.105', 1594838575, '__ci_last_regenerate|i:1594838417;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s4k2bpbgq5nl42sp492qhlr7ufdgq349', '41.73.1.66', 1602154577, '__ci_last_regenerate|i:1602153765;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('se58gt3cf5ai4don6vpsnkhp9tvpe9hj', '41.73.1.71', 1601375186, '__ci_last_regenerate|i:1601372886;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('skh2lpapp5nref14d48rvqut4djinu9a', '66.102.8.15', 1601374899, '__ci_last_regenerate|i:1601374896;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t8fpn8ae4sjt0ard3ossd3kk06k98r3u', '41.190.12.220', 1594818364, '__ci_last_regenerate|i:1594818057;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:36:\"You Are Now Using The Latest Version\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tsdebip4qh42q4ga83g6om1qh58qicln', '193.189.184.198', 1601466333, '__ci_last_regenerate|i:1601466331;redirect_url|s:70:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/inbox\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u33dt3l9losq7o9cg6mno0aorikl25cs', '41.73.1.71', 1601378456, '__ci_last_regenerate|i:1601378454;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u4sbqdkmlj2en88ngohgb1aij37abfo9', '41.190.12.223', 1598076965, '__ci_last_regenerate|i:1598076961;redirect_url|s:72:\"https://www.admin.acce-abuja.com.ng/portal/communication/mailbox/compose\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u6a2o7iuuuc9g8g62k6mdujh33ql1a3v', '41.190.12.93', 1594825919, '__ci_last_regenerate|i:1594825868;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u93v93711v1lcmeuj34u9il5c8ff08um', '41.190.12.83', 1598149727, '__ci_last_regenerate|i:1598149724;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ua34nfo0vu8c7kg2lr78ta9pukc6lgbv', '41.190.14.129', 1594894514, '__ci_last_regenerate|i:1594894494;redirect_url|s:58:\"https://www.admin.acce-abuja.com.ng/portal/employee/view/3\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uac8hoc41t4oe93tai420ji12pb8oefk', '152.89.163.34', 1594910640, '__ci_last_regenerate|i:1594910027;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"bd9a4f666a4410da2d12717dd2a34c1f.JPG\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"3\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"2\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uf67qn2acr43k4i9cr8ma2ita628sq3v', '41.73.1.75', 1601894215, '__ci_last_regenerate|i:1601894214;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('un75h96kgt1809h7cfbh4mv67petkqdb', '41.73.1.66', 1602160450, '__ci_last_regenerate|i:1602160152;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uuqvv0vkucna1gtlhi1loctdth1ukjsq', '105.112.113.52', 1600682477, '__ci_last_regenerate|i:1600682229;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uvnhq76dg0itr5cg5hsho9fhisat56pu', '129.205.113.231', 1601298454, '__ci_last_regenerate|i:1601298451;redirect_url|s:44:\"http://admin.acce-abuja.com.ng/portal/branch\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v2g9kbvtmtigrt363k5o4qahj8mnoo40', '41.190.14.57', 1596655490, '__ci_last_regenerate|i:1596655411;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v4hhb1i36ddekjqbft9eeu1d2gea1fnc', '105.112.121.55', 1602502769, '__ci_last_regenerate|i:1602502737;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v4uob14mi4i2mh4k66qri64401bblo6p', '41.190.14.246', 1600683400, '__ci_last_regenerate|i:1600683400;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v6e03k6jd3g4m7ktb855tiphtgqftlq1', '41.73.1.66', 1602158879, '__ci_last_regenerate|i:1602158878;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v6jdgnnoltks8dg2phoksenju9u08js3', '197.149.127.197', 1602155523, '__ci_last_regenerate|i:1602155522;redirect_url|s:53:\"https://www.admin.acce-abuja.com.ng/portal/live_class\";');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v6v7qujdic3r13ubqkfuf827gdpumf4m', '41.73.1.71', 1601376089, '__ci_last_regenerate|i:1601375877;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v7auhrotci7qo9dt0kdi0v9hf2ho82k0', '41.73.1.68', 1602514403, '__ci_last_regenerate|i:1602514079;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vbartl0aaq4c32tcjhrrm4fsvmtvjatg', '41.73.1.75', 1601980547, '__ci_last_regenerate|i:1601980263;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('veiapju71dt155pmpgg3vi1rjum6djud', '41.190.12.66', 1595376282, '__ci_last_regenerate|i:1595376095;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vm5me0lev8i8avbpvshusfe5ncco3q4k', '41.73.1.75', 1601892276, '__ci_last_regenerate|i:1601891908;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vmpcsi3m113j52jh7kql0nn8cp2usfqs', '41.73.1.75', 1601894216, '__ci_last_regenerate|i:1601894215;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vo2m9i7m8shn9hg42ie7dd5r8nh1vmcc', '41.73.1.72', 1601112080, '__ci_last_regenerate|i:1601111915;name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vt6nvvtmsdcnnjj2shakd6ftmpf8tm6u', '41.190.14.105', 1594836596, '__ci_last_regenerate|i:1594836594;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vu2v5dluh5c19ald0s4t98efc27vf308', '41.190.14.7', 1599421662, '__ci_last_regenerate|i:1599421502;redirect_url|s:47:\"http://admin.acce-abuja.com.ng/portal/dashboard\";name|s:16:\"Adnan Baba-Ahmed\";logger_photo|s:36:\"5a4c4849c863c4e9d19350ddef2edded.PNG\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vv7nq2e53r0ka0cuvjm0mf22d4prgrvd', '105.112.113.10', 1600779884, '__ci_last_regenerate|i:1600779635;name|s:10:\"Abba Sanda\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:1:\"4\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"4\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"3\";loggedin|b:1;');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `is_system` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (1, 'Super Admin', 'superadmin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (2, 'Admin', 'admin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (3, 'Teacher', 'teacher', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (4, 'Accountant', 'accountant', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (5, 'Librarian', 'librarian', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (6, 'Parent', 'parent', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (7, 'Student', 'student', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (9, 'Founder/President', 'founder/president', '0');


#
# TABLE STRUCTURE FOR: salary_template
#

DROP TABLE IF EXISTS `salary_template`;

CREATE TABLE `salary_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL,
  `overtime_salary` varchar(100) NOT NULL DEFAULT '0',
  `branch_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `salary_template` (`id`, `name`, `basic_salary`, `overtime_salary`, `branch_id`) VALUES (1, 'Grade 4', '70000.00', '0', 1);


#
# TABLE STRUCTURE FOR: salary_template_details
#

DROP TABLE IF EXISTS `salary_template_details`;

CREATE TABLE `salary_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_template_id` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT '0.00',
  `type` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `salary_template_details` (`id`, `salary_template_id`, `name`, `amount`, `type`) VALUES (1, '1', 'Transport', '50000.00', 1);
INSERT INTO `salary_template_details` (`id`, `salary_template_id`, `name`, `amount`, `type`) VALUES (2, '1', 'Food', '15000.00', 1);


#
# TABLE STRUCTURE FOR: schoolyear
#

DROP TABLE IF EXISTS `schoolyear`;

CREATE TABLE `schoolyear` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_year` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (1, '2019-2020', 1, '2020-02-25 20:35:41', '2020-02-26 16:54:49');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (3, '2020-2021', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (4, '2021-2022', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (5, '2022-2023', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (6, '2023-2024', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (7, '2024-2025', 1, '2020-02-25 20:35:41', '2020-02-26 01:20:04');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (9, '2025-2026', 1, '2020-02-26 08:00:10', '2020-02-26 13:00:24');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (10, '2026-2027', 1, '2021-01-13 11:41:36', NULL);
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (11, '2027-2028', 1, '2021-01-13 11:41:48', NULL);
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (12, '2028-2029', 1, '2021-01-13 11:42:05', NULL);
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (13, '2029-2030', 1, '2021-01-13 11:42:21', NULL);


#
# TABLE STRUCTURE FOR: section
#

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `capacity` varchar(20) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (1, 'Arts', '500', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (2, 'Science & Tech', '500', 1);


#
# TABLE STRUCTURE FOR: sections_allocation
#

DROP TABLE IF EXISTS `sections_allocation`;

CREATE TABLE `sections_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (1, 1, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (2, 2, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (4, 4, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (5, 5, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (7, 7, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (8, 8, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (13, 13, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (14, 14, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (19, 13, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (20, 14, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (21, 1, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (22, 2, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (23, 4, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (24, 5, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (25, 7, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (26, 8, 1);


#
# TABLE STRUCTURE FOR: sms_api
#

DROP TABLE IF EXISTS `sms_api`;

CREATE TABLE `sms_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `sms_api` (`id`, `name`) VALUES (1, 'twilio');
INSERT INTO `sms_api` (`id`, `name`) VALUES (2, 'clickatell');
INSERT INTO `sms_api` (`id`, `name`) VALUES (3, 'msg91');
INSERT INTO `sms_api` (`id`, `name`) VALUES (4, 'bulksms');
INSERT INTO `sms_api` (`id`, `name`) VALUES (5, 'textlocal');


#
# TABLE STRUCTURE FOR: sms_credential
#

DROP TABLE IF EXISTS `sms_credential`;

CREATE TABLE `sms_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_api_id` int(11) NOT NULL,
  `field_one` varchar(300) NOT NULL,
  `field_two` varchar(300) NOT NULL,
  `field_three` varchar(300) NOT NULL,
  `field_four` varchar(300) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: sms_template
#

DROP TABLE IF EXISTS `sms_template`;

CREATE TABLE `sms_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (1, 'admission', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (2, 'fee_collection', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {paid_amount}, {paid_date} ');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (3, 'attendance', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (4, 'exam_attendance', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_name}, {term_name}, {subject}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (5, 'exam_results', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_name}, {term_name}, {subject}, {marks}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (6, 'homework', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {subject}, {date_of_homework}, {date_of_submission}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (7, 'live_class', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {date_of_live_class}, {start_time}, {end_time}, {host_by}');


#
# TABLE STRUCTURE FOR: sms_template_details
#

DROP TABLE IF EXISTS `sms_template_details`;

CREATE TABLE `sms_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `notify_student` tinyint(3) NOT NULL DEFAULT '1',
  `notify_parent` tinyint(3) NOT NULL DEFAULT '1',
  `template_body` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `sms_template_details` (`id`, `template_id`, `notify_student`, `notify_parent`, `template_body`, `branch_id`, `created_at`) VALUES (1, 1, 1, 1, 'Hello {name},\r\nYour admission to ACCE-Abuja has been accepted to Class : {class}.\r\nThe Admission Date is {admission_date} and your student registration number is {register_no}', 1, '2021-01-13 13:50:16');


#
# TABLE STRUCTURE FOR: staff
#

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` int(11) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `experience_details` varchar(255) DEFAULT NULL,
  `total_experience` varchar(255) DEFAULT NULL,
  `designation` int(11) NOT NULL,
  `joining_date` varchar(100) NOT NULL,
  `birthday` varchar(100) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `present_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `salary_template_id` int(11) DEFAULT '0',
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (1, '3bf62b8', 'Adnan Baba-Ahmed', 0, '', NULL, NULL, 0, '2020-07-15', '', 'male', 'Islam', 'O+', 'No. 11 Chuba Okagdibo Street Apo', '', '+2348092406828', 'babaahmedadnan@gmail.com', 0, NULL, '5a4c4849c863c4e9d19350ddef2edded.PNG', 'https://www.facebook.com/adnanbabaahmed', 'https://ng.linkedin.com/in/adnan-baba-ahmed-31a44872', 'twitter.com/adnanu_', '2020-07-15 13:44:05', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (2, 'b1b4698', 'Alfaky Bello', 1, 'Msc Biology', '', '', 2, '2020-07-15', '', 'male', '', 'O+', 'Abuja', '', '09092082082080', 'alfakybello@gmail.com', 1, 1, 'd2716a265b93ba536f2cc3bf9a176141.JPG', '', '', '', '2020-07-15 15:44:50', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (3, 'f77e5fb', 'Adnan Baba-Ahmed', 1, 'BSc. Software Engineering', '', '', 2, '2020-07-16', '', 'male', '', '', 'No. 11 Chuba Okagdibo Street Apo', '', '+2348092406828', 'babaahmedadnan@gmail.com', 0, 1, 'bd9a4f666a4410da2d12717dd2a34c1f.JPG', '', '', '', '2020-07-16 11:40:31', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (4, 'a215dce', 'Abba Sanda', 2, 'MSc. Financial Accounting', '', '', 3, '2020-07-16', '1999-09-20', 'male', 'Islam', 'B+', 'Wuse 2, Abuja', '', '080820837823', 'abbasanda@gmail.com', 1, 1, 'defualt.png', '', '', '', '2020-07-16 15:10:09', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (5, 'fe029a4', 'Umar Sanda', 3, 'Msc. Library Management', '', '', 4, '2020-07-16', '1990-05-24', 'male', 'Islam', 'A+', 'Games Village, Abuja', '', '09075654563', 'umarsanda@gmail.com', 0, 1, 'b7c3a3cbccb9215506163355c4e086fb.png', '', '', '', '2020-07-16 15:17:30', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (6, 'af20aaa', 'Dr. Mohammad Kyari Dikwa, mni', 4, 'Founder', '', '', 6, '2020-11-11', '', 'male', 'Islam', '', '28 TY Danjuma Crescent, Asokoro Abuja', '', '00000', 'founder@acce-abuja.com.ng', 0, 1, 'bc7ea18eba0efea4df0ea9f469120f1c.jpg', '', '', '', '2020-11-06 09:47:01', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (7, 'eb8af3c', 'Maryam Magaji Muhammad', 4, '---', '---', '---', 2, '2021-01-13', '', 'female', '', '', '--', '', '08037012331', 'fyne262000@yahoo.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 10:49:50', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (8, '1d3e89b', 'Odachi Cosmas Ejiofor', 1, 'B.sc in Education', '', '15years', 9, '2021-01-01', '', 'male', 'Christian', '', 'opposite immigration headquarters sauka Abuja', 'opposite immigration headquarters sauka Abuja', '07039735748', 'odachicosmas@gmail.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 12:48:52', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (9, '14aaa53', 'Nwosu Osinachi Victor', 1, 'BA. Education M.ED (english language education)', '', '21 years ', 8, '2021-01-01', '', 'male', 'Christian ', '', '30 yaradua close federal housing estate, Nyanya Abuja', '30 yaradua close federal housing estate, Nyanya Abuja', '08036056987', 'osinachinwosu79@gmail.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 12:58:36', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (10, '1fdd48e', 'Faridah Yussuff Avosuahi', 1, 'B. TECH FOOD SCIENCE AND NUTRITION', '', '2 YEARS', 14, '2021-01-01', '1989-07-12', 'female', 'Islam', 'O+', '173, BAKORI STREET,PW, KUBWA ABUJA', '173, BAKORI STREET,PW, KUBWA ABUJA', '08031550920', 'fareedaryousoof@gmail.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:11:52', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (11, '76f3a83', 'Abdulkadir rafiyat Abduljelil', 1, 'B.A English', '', '9 years', 16, '2021-01-01', '29-01-09', 'female', 'islam', 'A+', 'no 18,usman dam road behind poltery ushafa F.C.T abuja', 'no 18,usman dam road behind poltery ushafa F.C.T abuja', '08092884796', 'rafiyatabduljelil@gmail.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:16:53', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (12, '1421c3f', 'sherifat aliya keshinro', 1, 'b.ed', '', '3 years', 15, '2021-01-01', '', 'female', 'islam', '', 'no 17, dutse baupma, fct abuja', 'no 17, dutse baupma, fct abuja', '08065577639', 'aleesh05@gmail.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:18:49', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (13, '48b06b1', 'emuejeraye mefogune okponafagha', 1, 'HND Higher Nat.Dip', '', '7 years', 18, '2021-01-01', '', 'male', 'Christian', '', 'block 22 kukawa close area 10', 'block 22 kukawa close area 10', '08131070195', 'e.mefo@yahoo.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:26:15', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (14, '03190a5', 'Yusuf Muhyideen Abolaji', 1, 'b.tech,pgd.ed', '', '10years', 11, '2021-01-01', '', 'male', 'Islam', 'O+', '12, Harmony Close, Rafinsenyin, Suleja, Niger State.', '12, Harmony Close, Rafinsenyin, Suleja, Niger State.', '08140001799', 'gentybee4u@gmail.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:27:22', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (15, 'cd020ae', 'Oduola bashirat temitope', 1, 'B.TECH/PGDE', '', '11 years', 13, '2021-01-01', '1976-03-14', 'female', 'Islam', '', '12 akoshi- kabula street yaro college road,second gate,suleja', '', '07039861688/08072103055', 'oduolatemitope@yahoo.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:36:03', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (16, 'f248424', 'ibrahim ahmed kayode', 1, 'NCE,BSC', '', '14years', 10, '2021-01-01', '', 'male', 'islam', '', 'c/o learnite international academy, maje suleja niger state', 'c/o learnite international academy, maje suleja niger state', '08030514069', 'mail4kayodeahmad@gmail.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:40:51', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (17, 'ea3f71a', 'Oladebo Abduljelil Taiwo', 1, 'B.ENGR/PGDE', '', '8 YEARS', 11, '2021-01-01', '', 'male', 'Islam', '', 'no 18p usman dam road behind pottery, ushafa, buariga fct abuja', '', '08183750675\\09061535220', 'abduljeliloladebo@gmail.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:42:47', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (18, 'ada289b', 'muhammad muhammad nasir', 1, 'bsc mathmatics', '', '5years', 12, '2021-01-01', '', 'male', 'islam', '', 'flat 3, opp house no 14 fakai street dakwa, dei dei, abuja.', 'flat 3, opp house no 14 fakai street dakwa dei dei, abuja.', '08160211444', 'muhammad.nasrm@yahoo.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:46:24', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (19, '1babfcd', 'mukhtar asiya', 1, 'BA', '', '', 17, '2021-01-01', '', 'female', 'islam', '', '392, efire deogun street,lifecamp,abuja', '', '08163245687', 'asiyamukhtar@icloud.com', 0, 1, 'defualt.png', '', '', '', '2021-01-13 13:47:40', NULL);


#
# TABLE STRUCTURE FOR: staff_attendance
#

DROP TABLE IF EXISTS `staff_attendance`;

CREATE TABLE `staff_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `status` varchar(11) DEFAULT NULL COMMENT 'P=Present, A=Absent, H=Holiday, L=Late',
  `remark` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `staff_attendance` (`id`, `staff_id`, `status`, `remark`, `date`, `branch_id`) VALUES (1, 2, 'H', 'On Vacation', '2020-07-27', 1);
INSERT INTO `staff_attendance` (`id`, `staff_id`, `status`, `remark`, `date`, `branch_id`) VALUES (2, 2, 'A', '', '2020-09-21', 1);


#
# TABLE STRUCTURE FOR: staff_bank_account
#

DROP TABLE IF EXISTS `staff_bank_account`;

CREATE TABLE `staff_bank_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `holder_name` varchar(255) NOT NULL,
  `bank_branch` varchar(255) NOT NULL,
  `bank_address` varchar(255) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: staff_department
#

DROP TABLE IF EXISTS `staff_department`;

CREATE TABLE `staff_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'Science', 1, '2020-07-15 15:39:10', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'Finance', 1, '2020-07-16 15:05:39', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 'Library', 1, '2020-07-16 15:11:20', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (4, 'Admin', 1, '2020-10-29 12:35:11', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (5, 'Assistant Head of School English', 1, '2021-01-15 13:57:53', NULL);


#
# TABLE STRUCTURE FOR: staff_designation
#

DROP TABLE IF EXISTS `staff_designation`;

CREATE TABLE `staff_designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'Head Teacher', 1, '2020-07-16 11:32:49', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 'Bursar', 1, '2020-07-16 15:04:43', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (4, 'Head Librarian', 1, '2020-07-16 15:11:32', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (5, 'Network Officer', 1, '2020-10-26 14:20:53', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (6, 'Founder', 1, '2020-10-29 12:11:19', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (7, 'Admin Secretary', 1, '2021-01-13 10:41:50', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (8, 'English Teacher', 1, '2021-01-13 11:23:27', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (9, 'Computing Teacher', 1, '2021-01-13 11:23:40', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (10, 'Social Studies Teacher', 1, '2021-01-13 11:24:00', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (11, 'Science +  Tech Teacher', 1, '2021-01-13 11:24:40', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (12, 'Mathematics Teacher', 1, '2021-01-13 11:25:00', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (13, 'Agric Teacher', 1, '2021-01-13 11:25:38', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (14, 'Home Economics Teacher', 1, '2021-01-13 11:25:55', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (15, 'Reception', 1, '2021-01-13 11:26:10', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (16, 'Nursery 2 Teacher', 1, '2021-01-13 11:26:21', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (17, 'Nursery 1 Teacher', 1, '2021-01-13 11:26:50', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (18, 'Arts Teacher', 1, '2021-01-13 11:27:32', NULL);


#
# TABLE STRUCTURE FOR: staff_documents
#

DROP TABLE IF EXISTS `staff_documents`;

CREATE TABLE `staff_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: staff_privileges
#

DROP TABLE IF EXISTS `staff_privileges`;

CREATE TABLE `staff_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `is_add` tinyint(1) NOT NULL,
  `is_edit` tinyint(1) NOT NULL,
  `is_view` tinyint(1) NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=829 DEFAULT CHARSET=utf8;

INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (1, 3, 1, 0, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (2, 3, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (3, 3, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (4, 3, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (5, 3, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (6, 3, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (7, 3, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (8, 3, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (9, 3, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (10, 3, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (11, 3, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (12, 3, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (13, 3, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (14, 3, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (15, 3, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (16, 3, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (17, 3, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (18, 3, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (20, 3, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (21, 3, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (22, 3, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (23, 3, 22, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (24, 3, 23, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (25, 3, 24, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (26, 3, 25, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (27, 3, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (28, 3, 27, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (29, 3, 28, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (30, 3, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (31, 3, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (32, 3, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (33, 3, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (34, 3, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (35, 3, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (36, 3, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (37, 3, 37, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (38, 3, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (39, 3, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (40, 3, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (41, 3, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (42, 3, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (43, 3, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (44, 3, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (45, 3, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (46, 3, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (47, 3, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (48, 3, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (49, 3, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (50, 3, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (51, 3, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (52, 3, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (53, 3, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (54, 3, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (55, 3, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (56, 3, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (57, 3, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (58, 3, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (59, 3, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (60, 3, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (61, 3, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (62, 3, 59, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (63, 3, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (64, 3, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (65, 3, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (66, 3, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (67, 3, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (68, 3, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (69, 3, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (70, 3, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (71, 3, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (72, 3, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (73, 3, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (74, 3, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (75, 3, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (76, 3, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (77, 3, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (78, 3, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (79, 3, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (80, 3, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (81, 3, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (82, 3, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (83, 3, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (84, 3, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (85, 3, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (86, 3, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (87, 3, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (88, 2, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (89, 2, 2, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (90, 2, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (91, 2, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (92, 2, 5, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (93, 2, 30, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (94, 2, 7, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (95, 2, 8, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (96, 2, 6, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (97, 2, 9, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (98, 2, 10, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (99, 2, 11, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (100, 2, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (101, 2, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (102, 2, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (103, 2, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (104, 2, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (105, 2, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (107, 2, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (108, 2, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (109, 2, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (110, 2, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (111, 2, 23, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (112, 2, 24, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (113, 2, 25, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (114, 2, 26, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (115, 2, 27, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (116, 2, 28, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (117, 2, 29, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (118, 2, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (119, 2, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (120, 2, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (121, 2, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (122, 2, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (123, 2, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (124, 2, 37, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (125, 2, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (126, 2, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (127, 2, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (128, 2, 78, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (129, 2, 79, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (130, 2, 40, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (131, 2, 41, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (132, 2, 42, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (133, 2, 43, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (134, 2, 44, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (135, 2, 45, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (136, 2, 46, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (137, 2, 47, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (138, 2, 48, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (139, 2, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (140, 2, 50, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (141, 2, 51, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (142, 2, 52, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (143, 2, 53, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (144, 2, 54, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (145, 2, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (146, 2, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (147, 2, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (148, 2, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (149, 2, 59, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (150, 2, 60, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (151, 2, 61, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (152, 2, 62, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (153, 2, 80, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (154, 2, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (155, 2, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (156, 2, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (157, 2, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (158, 2, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (159, 2, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (160, 2, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (161, 2, 76, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (162, 2, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (163, 2, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (164, 2, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (165, 2, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (166, 2, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (167, 2, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (168, 2, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (169, 2, 82, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (170, 2, 83, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (171, 2, 84, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (172, 2, 85, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (173, 2, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (174, 2, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (175, 7, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (176, 7, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (177, 7, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (178, 7, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (179, 7, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (180, 7, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (181, 7, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (182, 7, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (183, 7, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (184, 7, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (185, 7, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (186, 7, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (187, 7, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (188, 7, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (189, 7, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (190, 7, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (191, 7, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (192, 7, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (194, 7, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (195, 7, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (196, 7, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (197, 7, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (198, 7, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (199, 7, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (200, 7, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (201, 7, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (202, 7, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (203, 7, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (204, 7, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (205, 7, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (206, 7, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (207, 7, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (208, 7, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (209, 7, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (210, 7, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (211, 7, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (212, 7, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (213, 7, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (214, 7, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (215, 7, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (216, 7, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (217, 7, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (218, 7, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (219, 7, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (220, 7, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (221, 7, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (222, 7, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (223, 7, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (224, 7, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (225, 7, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (226, 7, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (227, 7, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (228, 7, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (229, 7, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (230, 7, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (231, 7, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (232, 7, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (233, 7, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (234, 7, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (235, 7, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (236, 7, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (237, 7, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (238, 7, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (239, 7, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (240, 7, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (241, 7, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (242, 7, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (243, 7, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (244, 7, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (245, 7, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (246, 7, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (247, 7, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (248, 7, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (249, 7, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (250, 7, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (251, 7, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (252, 7, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (253, 7, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (254, 7, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (255, 7, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (256, 7, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (257, 7, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (258, 7, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (259, 7, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (260, 7, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (261, 7, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (262, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (263, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (264, 89, 89, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (265, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (266, 2, 88, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (267, 2, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (268, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (269, 2, 90, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (270, 91, 91, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (271, 92, 92, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (272, 2, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (273, 2, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (274, 93, 93, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (275, 94, 94, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (276, 95, 95, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (277, 96, 96, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (278, 2, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (279, 2, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (280, 2, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (281, 2, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (282, 97, 97, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (283, 98, 98, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (284, 2, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (285, 2, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (286, 99, 99, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (287, 100, 100, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (288, 101, 101, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (289, 102, 102, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (290, 2, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (291, 2, 100, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (292, 2, 101, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (293, 2, 102, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (294, 103, 103, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (295, 2, 103, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (296, 3, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (297, 3, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (298, 3, 93, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (299, 3, 94, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (300, 3, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (301, 3, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (302, 3, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (303, 3, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (304, 3, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (305, 3, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (306, 3, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (307, 3, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (308, 3, 88, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (309, 3, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (310, 3, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (311, 3, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (312, 4, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (313, 4, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (314, 4, 93, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (315, 4, 94, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (316, 4, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (317, 4, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (318, 4, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (319, 4, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (320, 4, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (321, 4, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (322, 4, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (323, 4, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (324, 4, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (325, 4, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (326, 4, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (327, 4, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (328, 4, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (329, 4, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (330, 4, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (331, 4, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (332, 4, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (333, 4, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (334, 4, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (335, 4, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (336, 4, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (337, 4, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (338, 4, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (339, 4, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (340, 4, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (341, 4, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (343, 4, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (344, 4, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (345, 4, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (346, 4, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (347, 4, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (348, 4, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (349, 4, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (350, 4, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (351, 4, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (352, 4, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (353, 4, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (354, 4, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (355, 4, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (356, 4, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (357, 4, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (358, 4, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (359, 4, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (360, 4, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (361, 4, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (362, 4, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (363, 4, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (364, 4, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (365, 4, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (366, 4, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (367, 4, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (368, 4, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (369, 4, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (370, 4, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (371, 4, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (372, 4, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (373, 4, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (374, 4, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (375, 4, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (376, 4, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (377, 4, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (378, 4, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (379, 4, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (380, 4, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (381, 4, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (382, 4, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (383, 4, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (384, 4, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (385, 4, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (386, 4, 58, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (387, 4, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (388, 4, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (389, 4, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (390, 4, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (391, 4, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (392, 4, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (393, 4, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (394, 4, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (395, 4, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (396, 4, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (397, 4, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (398, 4, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (399, 4, 76, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (400, 4, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (401, 4, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (402, 4, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (403, 4, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (404, 4, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (405, 4, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (406, 4, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (407, 4, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (408, 4, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (409, 4, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (410, 4, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (411, 4, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (412, 4, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (413, 4, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (414, 4, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (415, 5, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (416, 5, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (417, 5, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (418, 5, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (419, 5, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (420, 5, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (421, 5, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (422, 5, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (423, 5, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (424, 5, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (425, 5, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (426, 5, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (427, 5, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (428, 5, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (429, 5, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (430, 5, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (431, 5, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (432, 5, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (433, 5, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (434, 5, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (435, 5, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (436, 5, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (437, 5, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (438, 5, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (439, 5, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (440, 5, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (441, 5, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (442, 5, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (443, 5, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (444, 5, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (446, 5, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (447, 5, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (448, 5, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (449, 5, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (450, 5, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (451, 5, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (452, 5, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (453, 5, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (454, 5, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (455, 5, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (456, 5, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (457, 5, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (458, 5, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (459, 5, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (460, 5, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (461, 5, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (462, 5, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (463, 5, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (464, 5, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (465, 5, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (466, 5, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (467, 5, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (468, 5, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (469, 5, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (470, 5, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (471, 5, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (472, 5, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (473, 5, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (474, 5, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (475, 5, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (476, 5, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (477, 5, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (478, 5, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (479, 5, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (480, 5, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (481, 5, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (482, 5, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (483, 5, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (484, 5, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (485, 5, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (486, 5, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (487, 5, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (488, 5, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (489, 5, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (490, 5, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (491, 5, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (492, 5, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (493, 5, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (494, 5, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (495, 5, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (496, 5, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (497, 5, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (498, 5, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (499, 5, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (500, 5, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (501, 5, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (502, 5, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (503, 5, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (504, 5, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (505, 5, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (506, 5, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (507, 5, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (508, 5, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (509, 5, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (510, 5, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (511, 5, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (512, 5, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (513, 5, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (514, 5, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (515, 5, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (516, 5, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (517, 5, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (518, 104, 104, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (519, 2, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (520, 4, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (521, 2, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (522, 2, 105, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (523, 2, 106, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (524, 2, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (525, 2, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (526, 2, 108, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (527, 3, 18, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (528, 3, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (529, 3, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (530, 3, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (531, 3, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (532, 3, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (533, 3, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (534, 2, 110, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (535, 2, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (536, 2, 112, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (537, 2, 113, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (538, 2, 114, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (539, 2, 115, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (540, 2, 116, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (541, 2, 117, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (542, 3, 110, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (543, 3, 111, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (544, 3, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (545, 3, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (546, 3, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (547, 3, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (548, 3, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (549, 3, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (550, 2, 127, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (551, 2, 118, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (552, 2, 119, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (553, 2, 120, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (554, 2, 121, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (555, 2, 122, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (556, 2, 123, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (557, 2, 124, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (558, 2, 125, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (559, 2, 126, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (560, 8, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (561, 8, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (562, 8, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (563, 8, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (564, 8, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (565, 8, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (566, 8, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (567, 8, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (568, 8, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (569, 8, 100, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (570, 8, 101, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (571, 8, 102, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (572, 8, 118, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (573, 8, 119, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (574, 8, 120, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (575, 8, 121, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (576, 8, 122, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (577, 8, 123, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (578, 8, 124, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (579, 8, 125, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (580, 8, 126, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (581, 8, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (582, 8, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (583, 8, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (584, 8, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (585, 8, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (586, 8, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (587, 8, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (588, 8, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (589, 8, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (590, 8, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (591, 8, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (592, 8, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (593, 8, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (594, 8, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (595, 8, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (596, 8, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (597, 8, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (598, 8, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (599, 8, 110, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (600, 8, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (601, 8, 112, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (602, 8, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (603, 8, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (604, 8, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (605, 8, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (606, 8, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (607, 8, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (608, 8, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (609, 8, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (610, 8, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (611, 8, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (612, 8, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (613, 8, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (614, 8, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (615, 8, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (616, 8, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (617, 8, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (618, 8, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (619, 8, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (620, 8, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (621, 8, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (622, 8, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (623, 8, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (624, 8, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (625, 8, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (626, 8, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (627, 8, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (628, 8, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (629, 8, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (630, 8, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (631, 8, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (632, 8, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (633, 8, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (634, 8, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (635, 8, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (636, 8, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (637, 8, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (638, 8, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (639, 8, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (640, 8, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (641, 8, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (642, 8, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (643, 8, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (644, 8, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (645, 8, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (646, 8, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (647, 8, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (648, 8, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (649, 8, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (650, 8, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (651, 8, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (652, 8, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (653, 8, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (654, 8, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (655, 8, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (656, 8, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (657, 8, 61, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (658, 8, 62, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (659, 8, 80, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (660, 8, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (661, 8, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (662, 8, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (663, 8, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (664, 8, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (665, 8, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (666, 8, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (667, 8, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (668, 8, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (669, 8, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (670, 8, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (671, 8, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (672, 8, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (673, 8, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (674, 8, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (675, 8, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (676, 8, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (677, 8, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (678, 8, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (679, 8, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (680, 8, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (681, 8, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (682, 8, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (683, 8, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (684, 8, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (685, 8, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (686, 8, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (687, 8, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (688, 9, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (689, 9, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (690, 9, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (691, 9, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (692, 9, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (693, 9, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (694, 9, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (695, 9, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (696, 9, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (697, 9, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (698, 9, 101, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (699, 9, 102, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (700, 9, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (701, 9, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (702, 9, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (703, 9, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (704, 9, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (705, 9, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (706, 9, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (707, 9, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (708, 9, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (709, 9, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (710, 9, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (711, 9, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (712, 9, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (713, 9, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (714, 9, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (715, 9, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (716, 9, 7, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (717, 9, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (718, 9, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (719, 9, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (720, 9, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (721, 9, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (722, 9, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (723, 9, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (724, 9, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (725, 9, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (726, 9, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (727, 9, 110, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (728, 9, 111, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (729, 9, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (730, 9, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (731, 9, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (732, 9, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (733, 9, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (734, 9, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (735, 9, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (736, 9, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (737, 9, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (738, 9, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (739, 9, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (740, 9, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (741, 9, 107, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (742, 9, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (743, 9, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (744, 9, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (745, 9, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (746, 9, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (747, 9, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (748, 9, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (749, 9, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (750, 9, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (751, 9, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (752, 9, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (753, 9, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (754, 9, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (755, 9, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (756, 9, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (757, 9, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (758, 9, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (759, 9, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (760, 9, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (761, 9, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (762, 9, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (763, 9, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (764, 9, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (765, 9, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (766, 9, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (767, 9, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (768, 9, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (769, 9, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (770, 9, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (771, 9, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (772, 9, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (773, 9, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (774, 9, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (775, 9, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (776, 9, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (777, 9, 52, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (778, 9, 53, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (779, 9, 54, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (780, 9, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (781, 9, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (782, 9, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (783, 9, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (784, 9, 59, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (785, 9, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (786, 9, 61, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (787, 9, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (788, 9, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (789, 9, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (790, 9, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (791, 9, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (792, 9, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (793, 9, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (794, 9, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (795, 9, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (796, 9, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (797, 9, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (798, 9, 63, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (799, 9, 64, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (800, 9, 65, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (801, 9, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (802, 9, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (803, 9, 68, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (804, 9, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (805, 9, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (806, 9, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (807, 9, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (808, 9, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (809, 9, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (810, 9, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (811, 9, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (812, 9, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (813, 9, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (814, 9, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (815, 9, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (816, 9, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (817, 3, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (818, 3, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (819, 3, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (820, 3, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (821, 3, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (822, 3, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (823, 3, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (824, 3, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (825, 3, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (826, 3, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (827, 3, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (828, 3, 128, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: student
#

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `register_no` varchar(100) NOT NULL,
  `admission_date` varchar(100) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `birthday` varchar(100) DEFAULT NULL,
  `religion` varchar(100) NOT NULL,
  `caste` varchar(100) NOT NULL,
  `blood_group` varchar(100) NOT NULL,
  `mother_tongue` varchar(100) DEFAULT NULL,
  `current_address` text,
  `permanent_address` text,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL DEFAULT '0',
  `vehicle_id` int(11) NOT NULL DEFAULT '0',
  `hostel_id` int(11) NOT NULL DEFAULT '0',
  `room_id` int(11) NOT NULL DEFAULT '0',
  `previous_details` text NOT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `student` (`id`, `register_no`, `admission_date`, `first_name`, `last_name`, `gender`, `birthday`, `religion`, `caste`, `blood_group`, `mother_tongue`, `current_address`, `permanent_address`, `city`, `state`, `mobileno`, `category_id`, `email`, `parent_id`, `route_id`, `vehicle_id`, `hostel_id`, `room_id`, `previous_details`, `photo`, `created_at`, `updated_at`) VALUES (3, 'ACCE-00003', '2020-11-14', 'a', 'b', 'male', '2010-02-02', '', '', 'A+', '', 'Apo', 'Apo', 'Abuja', 'Fct', '08036381474', 2, 'Alfaqsbello@gmail.com', 1, 0, 0, 0, 0, '{\"school_name\":\"Ruby \",\"qualification\":\"Jss2\",\"remarks\":\"Good \"}', 'defualt.png', '2020-11-14 15:21:22', '2021-01-25 11:28:33');


#
# TABLE STRUCTURE FOR: student_attendance
#

DROP TABLE IF EXISTS `student_attendance`;

CREATE TABLE `student_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(4) DEFAULT NULL COMMENT 'P=Present, A=Absent, H=Holiday, L=Late',
  `remark` text,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `student_attendance` (`id`, `student_id`, `date`, `status`, `remark`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 1, '2020-07-27', 'H', '', 1, '2020-07-27 15:42:35', NULL);
INSERT INTO `student_attendance` (`id`, `student_id`, `date`, `status`, `remark`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 1, '2020-09-30', 'A', '', 1, '2020-09-30 13:36:40', NULL);
INSERT INTO `student_attendance` (`id`, `student_id`, `date`, `status`, `remark`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 1, '2020-10-08', 'P', '', 1, '2020-10-08 14:51:34', NULL);


#
# TABLE STRUCTURE FOR: student_category
#

DROP TABLE IF EXISTS `student_category`;

CREATE TABLE `student_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `student_category` (`id`, `branch_id`, `name`) VALUES (1, 1, 'Senior');
INSERT INTO `student_category` (`id`, `branch_id`, `name`) VALUES (2, 1, 'Junior');


#
# TABLE STRUCTURE FOR: student_documents
#

DROP TABLE IF EXISTS `student_documents`;

CREATE TABLE `student_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: subject
#

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject_code` varchar(200) NOT NULL,
  `subject_type` varchar(255) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `subject_author` varchar(255) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (1, 'Mathematics', 'MTH', 'Mandatory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (2, 'English', 'ENG', 'Mandatory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (3, 'Computing', 'COM', 'Practical', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (4, 'Home Economics', 'HomeEcon', 'Mandatory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (5, 'Agricultural Science', 'AgricSci', 'Mandatory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (6, 'Social Studies', 'SocialStd', 'Mandatory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (7, 'Arabic', 'Arabic', 'Practical', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (8, 'Qur\'an', 'Quran', 'Practical', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (9, 'Science & Tech', 'SciTech', 'Mandatory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (10, 'Arts', 'Arts', 'Mandatory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (11, 'STEM', 'STEM', 'Practical', '', 1);


#
# TABLE STRUCTURE FOR: subject_assign
#

DROP TABLE IF EXISTS `subject_assign`;

CREATE TABLE `subject_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` longtext NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (4, 4, 2, '2', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (5, 4, 2, '3', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (6, 4, 2, '4', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (7, 4, 2, '5', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (8, 4, 2, '6', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (9, 4, 2, '7', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (10, 4, 2, '8', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (11, 4, 2, '9', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (12, 4, 2, '10', 0, 1, 3, '2021-01-15 14:10:47', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (13, 2, 2, '2', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (14, 2, 2, '3', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (15, 2, 2, '4', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (16, 2, 2, '5', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (17, 2, 2, '6', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (18, 2, 2, '7', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (19, 2, 2, '8', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (20, 2, 2, '9', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (21, 2, 2, '10', 0, 1, 3, '2021-01-15 14:21:53', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (22, 4, 2, '1', 0, 1, 3, '2021-01-15 14:26:33', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (23, 2, 2, '1', 0, 1, 3, '2021-01-15 14:26:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (24, 1, 2, '1', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (25, 1, 2, '2', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (26, 1, 2, '3', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (27, 1, 2, '4', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (28, 1, 2, '5', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (29, 1, 2, '6', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (30, 1, 2, '7', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (31, 1, 2, '8', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (32, 1, 2, '9', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (33, 1, 2, '10', 2, 1, 3, '2021-01-15 14:28:54', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (34, 1, 2, '11', 2, 1, 3, '2021-01-15 14:28:54', NULL);


#
# TABLE STRUCTURE FOR: teacher_allocation
#

DROP TABLE IF EXISTS `teacher_allocation`;

CREATE TABLE `teacher_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (1, 3, 3, 2, 3, 1);
INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (2, 1, 2, 2, 3, 1);


#
# TABLE STRUCTURE FOR: teacher_note
#

DROP TABLE IF EXISTS `teacher_note`;

CREATE TABLE `teacher_note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` longtext NOT NULL,
  `file_name` longtext NOT NULL,
  `enc_name` longtext NOT NULL,
  `type_id` int(11) NOT NULL,
  `class_id` longtext NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: theme_settings
#

DROP TABLE IF EXISTS `theme_settings`;

CREATE TABLE `theme_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `border_mode` varchar(200) NOT NULL,
  `dark_skin` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `theme_settings` (`id`, `border_mode`, `dark_skin`, `created_at`, `updated_at`) VALUES (1, 'true', 'false', '2018-10-23 17:59:38', '2020-05-10 14:08:47');


#
# TABLE STRUCTURE FOR: timetable_class
#

DROP TABLE IF EXISTS `timetable_class`;

CREATE TABLE `timetable_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `break` varchar(11) DEFAULT 'false',
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_room` varchar(100) DEFAULT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `day` varchar(20) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (1, 1, 1, '0', 1, 2, 'SS1 A Classroom', '09:00:00', '11:00:00', 'monday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (2, 1, 1, '0', 2, 2, 'SS1 A Classroom', '11:00:00', '12:00:00', 'monday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (3, 1, 1, '0', 3, 2, 'SS1 A Classroom', '12:30:00', '15:00:00', 'monday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (4, 1, 1, '0', 1, 2, '', '11:15:00', '13:15:00', 'tuesday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (5, 1, 1, '1', 0, 0, '', '13:15:00', '14:00:00', 'tuesday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (6, 1, 1, '0', 3, 2, '', '14:15:00', '16:00:00', 'tuesday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (7, 1, 2, '0', 1, 18, 'YEAR 3', '08:00:00', '08:45:00', 'monday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (8, 2, 2, '0', 1, 18, 'YEAR 2', '08:45:00', '21:30:00', 'monday', 3, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (9, 4, 2, '0', 1, 18, '', '10:45:00', '23:30:00', 'monday', 3, 1);


#
# TABLE STRUCTURE FOR: timetable_exam
#

DROP TABLE IF EXISTS `timetable_exam`;

CREATE TABLE `timetable_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `time_start` varchar(20) NOT NULL,
  `time_end` varchar(20) NOT NULL,
  `mark_distribution` text NOT NULL,
  `hall_id` int(11) NOT NULL,
  `exam_date` date NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transactions
#

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) NOT NULL,
  `voucher_head_id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT '0.00',
  `dr` decimal(18,2) NOT NULL DEFAULT '0.00',
  `cr` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bal` decimal(18,2) NOT NULL DEFAULT '0.00',
  `date` date NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `attachments` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `transactions` (`id`, `account_id`, `voucher_head_id`, `type`, `category`, `ref`, `amount`, `dr`, `cr`, `bal`, `date`, `pay_via`, `description`, `attachments`, `branch_id`, `system`, `created_at`, `updated_at`) VALUES (1, '1', 0, 'deposit', '', '', '800000.00', '0.00', '800000.00', '800000.00', '2020-10-12', '', 'Opening Balance', '', 1, 0, '2020-10-12 15:46:47', NULL);
INSERT INTO `transactions` (`id`, `account_id`, `voucher_head_id`, `type`, `category`, `ref`, `amount`, `dr`, `cr`, `bal`, `date`, `pay_via`, `description`, `attachments`, `branch_id`, `system`, `created_at`, `updated_at`) VALUES (2, '2', 0, 'deposit', '', '', '5000000.00', '0.00', '5000000.00', '5000000.00', '2020-10-12', '', 'Opening Balance', '', 0, 0, '2020-10-12 15:47:59', NULL);
INSERT INTO `transactions` (`id`, `account_id`, `voucher_head_id`, `type`, `category`, `ref`, `amount`, `dr`, `cr`, `bal`, `date`, `pay_via`, `description`, `attachments`, `branch_id`, `system`, `created_at`, `updated_at`) VALUES (3, '2', 1, 'expense', '', 'Adsvjkn-37492389489', '10000.00', '10000.00', '0.00', '4990000.00', '2020-10-12', '2', 'October Salary for StaffID - 1092ifs03', '3.htaccess', 1, 0, '2020-10-12 15:49:39', NULL);
INSERT INTO `transactions` (`id`, `account_id`, `voucher_head_id`, `type`, `category`, `ref`, `amount`, `dr`, `cr`, `bal`, `date`, `pay_via`, `description`, `attachments`, `branch_id`, `system`, `created_at`, `updated_at`) VALUES (4, '1', 2, 'deposit', '', 'SCF-12Prioty', '45000.00', '0.00', '45000.00', '845000.00', '2020-10-12', '4', 'Bank Transfer Tuition Fees for Student ID : ACCE-003', '4.htaccess', 1, 0, '2020-10-12 15:53:23', NULL);
INSERT INTO `transactions` (`id`, `account_id`, `voucher_head_id`, `type`, `category`, `ref`, `amount`, `dr`, `cr`, `bal`, `date`, `pay_via`, `description`, `attachments`, `branch_id`, `system`, `created_at`, `updated_at`) VALUES (5, '1', 4, 'expense', '', 'SCF-12Prioty', '50000.00', '50000.00', '0.00', '795000.00', '2020-12-21', '4', '', '', 1, 0, '2020-12-21 12:55:54', NULL);
INSERT INTO `transactions` (`id`, `account_id`, `voucher_head_id`, `type`, `category`, `ref`, `amount`, `dr`, `cr`, `bal`, `date`, `pay_via`, `description`, `attachments`, `branch_id`, `system`, `created_at`, `updated_at`) VALUES (6, '1', 6, 'expense', '', '', '135000.00', '135000.00', '0.00', '660000.00', '2020-12-21', '5', 'Dec-2020 Paying Employees Salaries', '', 1, 1, '2020-12-21 19:10:21', NULL);


#
# TABLE STRUCTURE FOR: transactions_links
#

DROP TABLE IF EXISTS `transactions_links`;

CREATE TABLE `transactions_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) DEFAULT NULL,
  `deposit` tinyint(3) DEFAULT NULL,
  `expense` tinyint(3) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `transactions_links` (`id`, `status`, `deposit`, `expense`, `branch_id`) VALUES (1, 1, 1, 2, 1);


#
# TABLE STRUCTURE FOR: transport_assign
#

DROP TABLE IF EXISTS `transport_assign`;

CREATE TABLE `transport_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `stoppage_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `transport_assign` (`id`, `route_id`, `stoppage_id`, `vehicle_id`, `branch_id`, `created_at`) VALUES (1, 1, 1, 1, 1, '2020-09-30 13:35:37');
INSERT INTO `transport_assign` (`id`, `route_id`, `stoppage_id`, `vehicle_id`, `branch_id`, `created_at`) VALUES (2, 1, 1, 2, 1, '2020-09-30 13:35:37');
INSERT INTO `transport_assign` (`id`, `route_id`, `stoppage_id`, `vehicle_id`, `branch_id`, `created_at`) VALUES (3, 2, 1, 2, 1, '2020-09-30 13:35:54');


#
# TABLE STRUCTURE FOR: transport_route
#

DROP TABLE IF EXISTS `transport_route`;

CREATE TABLE `transport_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `start_place` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `stop_place` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `transport_route` (`id`, `name`, `start_place`, `remarks`, `stop_place`, `branch_id`) VALUES (1, 'Maitama Route', 'Nile Street', '', 'Gana Street', 1);
INSERT INTO `transport_route` (`id`, `name`, `start_place`, `remarks`, `stop_place`, `branch_id`) VALUES (2, 'Utako Route', 'Shettima Monguno St.', '', 'IBM Haruna St', 1);


#
# TABLE STRUCTURE FOR: transport_stoppage
#

DROP TABLE IF EXISTS `transport_stoppage`;

CREATE TABLE `transport_stoppage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stop_position` varchar(255) NOT NULL,
  `stop_time` time NOT NULL,
  `route_fare` decimal(18,2) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `transport_stoppage` (`id`, `stop_position`, `stop_time`, `route_fare`, `branch_id`, `created_at`) VALUES (1, 'Hostel Pickup', '13:30:00', '500.00', 1, '2020-09-30 13:35:21');


#
# TABLE STRUCTURE FOR: transport_vehicle
#

DROP TABLE IF EXISTS `transport_vehicle`;

CREATE TABLE `transport_vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_no` longtext NOT NULL,
  `capacity` longtext NOT NULL,
  `insurance_renewal` longtext NOT NULL,
  `driver_name` longtext NOT NULL,
  `driver_phone` longtext NOT NULL,
  `driver_license` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `transport_vehicle` (`id`, `vehicle_no`, `capacity`, `insurance_renewal`, `driver_name`, `driver_phone`, `driver_license`, `branch_id`, `created_at`, `updated_at`) VALUES (1, '8923h32jk', '8', '2021-01-09', 'Musa Isa', '09290180380', 'Njk9y8yf7y923f', 1, '2020-09-30 13:34:07', NULL);
INSERT INTO `transport_vehicle` (`id`, `vehicle_no`, `capacity`, `insurance_renewal`, `driver_name`, `driver_phone`, `driver_license`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'k89ausdn9uasf9', '20', '2022-06-08', 'Isa Musa', '0802808216', 'Modh932rnjiw', 1, '2020-09-30 13:34:38', NULL);


#
# TABLE STRUCTURE FOR: voucher_head
#

DROP TABLE IF EXISTS `voucher_head`;

CREATE TABLE `voucher_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `system` tinyint(1) DEFAULT '0',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `voucher_head` (`id`, `name`, `type`, `system`, `branch_id`) VALUES (1, 'Salary Payment', 'expense', 0, 1);
INSERT INTO `voucher_head` (`id`, `name`, `type`, `system`, `branch_id`) VALUES (2, 'Tuition Fees Payment', 'income', 0, 1);
INSERT INTO `voucher_head` (`id`, `name`, `type`, `system`, `branch_id`) VALUES (3, 'alfaky', 'expense', 0, 1);
INSERT INTO `voucher_head` (`id`, `name`, `type`, `system`, `branch_id`) VALUES (4, 'Nepa Bill', 'expense', 0, 1);
INSERT INTO `voucher_head` (`id`, `name`, `type`, `system`, `branch_id`) VALUES (5, 'DSTV Payment', 'expense', 0, 1);
INSERT INTO `voucher_head` (`id`, `name`, `type`, `system`, `branch_id`) VALUES (6, 'Employees Salary Payment', 'expense', 1, 1);


#
# TABLE STRUCTURE FOR: zoom_own_api
#

DROP TABLE IF EXISTS `zoom_own_api`;

CREATE TABLE `zoom_own_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `zoom_api_key` varchar(255) NOT NULL,
  `zoom_api_secret` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `zoom_own_api` (`id`, `user_type`, `user_id`, `zoom_api_key`, `zoom_api_secret`) VALUES (1, 1, 18, 'Muhammad Nasir is inviting you to a scheduled Zoom meeting.  Topic: Muhammad Nasir\'s Zoom Meeting Time: This is a recurring meeting Meet anytime  Join Zoom Meeting https://us05web.zoom.us/j/82761230889?pwd=bktMSTh0VnRrWDV1LzBML2F5Y0RRUT09  Meeting ID: 827', 'Muhammad Nasir is inviting you to a scheduled Zoom meeting.  Topic: Muhammad Nasir\'s Zoom Meeting Time: This is a recurring meeting Meet anytime  Join Zoom Meeting https://us05web.zoom.us/j/82761230889?pwd=bktMSTh0VnRrWDV1LzBML2F5Y0RRUT09  Meeting ID: 827');


